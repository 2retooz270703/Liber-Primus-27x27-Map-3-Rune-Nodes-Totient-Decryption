#pragma once

#include "english.hpp"

#include <atomic>
#include <iostream>
#include <limits>
#include <variant>

namespace lp {

struct Step {
    KeyPosition node;
    Span cells;
    PackedKey key;
};

using WordList = std::shared_ptr<const Words>;

struct Choice {
    double score;
    WordList words;
    Step step;
};

struct BlockReading {
    WordList words;
    Step step;
};

// Readings that extend the same history share their prefix, including its witness.
struct Path {
    std::shared_ptr<const Path> previous;
    BlockReading last;
    std::size_t size;
};

struct Reading {
    double score = 0;
    std::shared_ptr<const Path> path;
};

struct OpeningReadings {
    std::shared_ptr<const WordReadings> words;
    PackedKey key;
};

// Keep a single established reading inline. Openings can also keep their
// shared dictionary results until one needs a path for ranking or expansion.
class Ranking {
    using Many = std::vector<Reading>;
    std::variant<Reading, Many, OpeningReadings> entries_;

public:
    Ranking() = default;
    explicit Ranking(OpeningReadings opening) : entries_(std::move(opening)) {}

    const OpeningReadings* opening() const { return std::get_if<OpeningReadings>(&entries_); }

    std::size_t size() const {
        if (const auto* single = std::get_if<Reading>(&entries_)) return single->path ? 1 : 0;
        return std::get<Many>(entries_).size();
    }

    bool empty() const { return size() == 0; }

    Reading* begin() {
        if (auto* single = std::get_if<Reading>(&entries_)) return single;
        return std::get<Many>(entries_).data();
    }

    const Reading* begin() const {
        if (const auto* single = std::get_if<Reading>(&entries_)) return single;
        return std::get<Many>(entries_).data();
    }

    Reading* end() { return begin() + size(); }
    const Reading* end() const { return begin() + size(); }
    const Reading& front() const { return *begin(); }
    const Reading& back() const { return *(end() - 1); }
    const Reading& operator[](std::size_t i) const { return begin()[i]; }

    void reserve(std::size_t n) {
        if (n <= 1) return;
        if (auto* single = std::get_if<Reading>(&entries_)) {
            Many many;
            many.reserve(n);
            if (single->path) many.push_back(std::move(*single));
            entries_ = std::move(many);
        } else {
            std::get<Many>(entries_).reserve(n);
        }
    }

    void insert(Reading* position, Reading reading) {
        auto offset = position - begin();
        if (auto* single = std::get_if<Reading>(&entries_)) {
            if (!single->path) {
                *single = std::move(reading);
                return;
            }
            reserve(2);
        }
        auto& many = std::get<Many>(entries_);
        many.insert(many.begin() + offset, std::move(reading));
    }

    void push_back(Reading reading) { insert(end(), std::move(reading)); }

    void pop_back() {
        if (auto* single = std::get_if<Reading>(&entries_)) *single = {};
        else std::get<Many>(entries_).pop_back();
    }

    void swap(Ranking& other) { entries_.swap(other.entries_); }
};

inline Reading extend(const std::shared_ptr<const Path>& prefix, double score, const Choice& choice) {
    return {score, std::make_shared<Path>(Path{prefix, {choice.words, choice.step}, prefix ? prefix->size + 1 : 1})};
}

inline int compare_text(const Path* a, const Path* b) {
    if (a == b) return 0;
    if (!a || !b) return a ? 1 : -1;
    int order = (a->size > b->size) - (a->size < b->size);
    while (a->size > b->size) a = a->previous.get();
    while (b->size > a->size) b = b->previous.get();
    // Walking backward lets a difference earlier in the text take precedence.
    while (a != b) {
        auto comparison = *a->last.words <=> *b->last.words;
        if (comparison != 0) order = comparison < 0 ? -1 : 1;
        a = a->previous.get();
        b = b->previous.get();
    }
    return order;
}

inline bool reading_less(const Reading& a, const Reading& b) {
    if (a.score != b.score) return a.score > b.score;
    return compare_text(a.path.get(), b.path.get()) < 0;
}

template<class Candidate>
inline void admit(Ranking& target, Candidate&& reading, std::size_t top) {
    if (target.size() == top && reading.score < target.back().score) return;
    auto pos = std::lower_bound(target.begin(), target.end(), reading, reading_less);
    if (pos == target.end() && target.size() == top) return;
    if (pos != target.end() && pos->score == reading.score &&
        compare_text(pos->path.get(), reading.path.get()) == 0) return;
    target.insert(pos, std::forward<Candidate>(reading));
    if (target.size() > top) target.pop_back();
}

inline void admit_step(Ranking& target, const std::shared_ptr<const Path>& prefix,
                       double score, const Choice& choice, std::size_t top) {
    if (target.size() == top && score < target.back().score) return;
    auto compare = [&](const Reading& item) {
        if (item.score != score) return item.score > score ? -1 : 1;
        int order = compare_text(item.path->previous.get(), prefix.get());
        if (order) return order;
        auto word_order = *item.path->last.words <=> *choice.words;
        return (word_order > 0) - (word_order < 0);
    };
    auto pos = std::lower_bound(target.begin(), target.end(), score,
        [&](const Reading& item, double) { return compare(item) < 0; });
    if ((pos == target.end() && target.size() == top) ||
        (pos != target.end() && compare(*pos) == 0)) return;
    target.insert(pos, extend(prefix, score, choice));
    if (target.size() > top) target.pop_back();
}

struct RankedState {
    State state;
    Ranking readings;
};

class StateEntries {
    using Block = std::vector<RankedState>;
    static constexpr std::size_t block_size = 4096;
    Block first_;
    std::vector<Block> rest_;
    std::size_t size_ = 0;

    Block& block(std::size_t index) {
        return index < block_size ? first_ : rest_[index / block_size - 1];
    }

public:
    std::size_t size() const { return size_; }
    bool empty() const { return size_ == 0; }
    RankedState& operator[](std::size_t index) { return block(index)[index % block_size]; }

    void reserve(std::size_t size) {
        first_.reserve(std::min(size, block_size));
        if (size > block_size) rest_.reserve((size - 1) / block_size);
    }

    void push_back(RankedState&& entry) {
        if (size_ && size_ % block_size == 0) {
            rest_.emplace_back();
            rest_.back().reserve(block_size);
        }
        block(size_).push_back(std::move(entry));
        ++size_;
    }

    // The caller completes states in order. Leave offsets intact for workers
    // running later states while releasing completed storage.
    void release_through(std::size_t index) {
        if ((index + 1) % block_size == 0 || index + 1 == size_) Block{}.swap(block(index));
    }
};

class Layer {
    // Entries stay in discovery order regardless of probing or resizing.
    using Narrow = std::vector<std::uint32_t>;
    using Wide = std::vector<std::uint64_t>;
    std::variant<Narrow, Wide> index_;

    template<class Index>
    std::size_t slot(const Index& index, const State& state) {
        auto mask = index.size() - 1;
        auto i = StateHash{}(state) & mask;
        while (index[i] && !(entries[index[i] - 1].state == state)) i = (i + 1) & mask;
        return i;
    }

    void reindex(std::size_t capacity) {
        if (capacity > UINT32_MAX && std::holds_alternative<Narrow>(index_)) index_.emplace<Wide>();
        std::visit([&](auto& index) {
            index.assign(capacity, 0);
            for (std::size_t i = 0; i < entries.size(); ++i) index[slot(index, entries[i].state)] = i + 1;
        }, index_);
    }

public:
    StateEntries entries;

    void reserve(std::size_t size) {
        entries.reserve(size);
        reindex(std::bit_ceil(std::max(std::size_t{8}, size + size / 2 + 1)));
    }

    Ranking& at(const State& state) {
        auto capacity = std::visit([](const auto& index) { return index.size(); }, index_);
        if (!capacity || entries.size() + 1 > capacity * 2 / 3)
            reindex(std::max(std::size_t{8}, capacity * 2));
        return std::visit([&](auto& index) -> Ranking& {
            auto i = slot(index, state);
            if (!index[i]) {
                entries.push_back({state, {}});
                index[i] = entries.size();
            }
            return entries[index[i] - 1].readings;
        }, index_);
    }

    void release_index() { index_.emplace<Narrow>(); }
};

class Search {
    struct OpeningBlock {
        Span cells;
        std::shared_ptr<const WordReadings> readings;
    };
    struct Successors {
        bool terminal = false;
        bool continues = false;
        StateEntries states;
    };
    struct OpeningScratch {
        struct WordEnds {
            Cell start = -1;
            std::uint64_t lengths = 0;
        };
        std::string stream;
        std::vector<std::uint8_t> reachable;
        std::vector<WordEnds> word_ends;
    };
    struct RuneRun {
        int begin, end;
        Rune rune;
    };
    enum class Expansion { terminal, detect, collect };

    const Geometry& geo_;
    const English& english_;
    const Workers& workers_;
    std::vector<ReadingCache>& cache_;

    static constexpr int ray_probe = 96;
    std::array<std::vector<PackedKey>, 12> key_domains_;
    std::array<std::uint32_t, rune_count> middle_sources_{};

    void build_key_domains() {
        std::array<int, rune_count> signature{};
        for (int r = 1; r < rune_count; ++r) {
            signature[r] = geo_.mu(geo_.phi(r));
            middle_sources_[r] |= std::uint32_t{1} << r;
            middle_sources_[geo_.phi(r)] |= std::uint32_t{1} << r;
        }
        for (int a = 1; a < rune_count; ++a) {
            int outer = signature[a];
            if (outer < 0) continue;
            for (int b = 1; b < rune_count; ++b) {
                int middle = signature[b];
                for (int c = 1; c < rune_count; ++c) {
                    if (signature[c] != outer) continue;
                    bool mirror = a == c;
                    Key original{a, b, c};
                    int phase = mod3(outer * 2 + middle);
                    int domain = (outer * 3 + middle + 1) * 2 + mirror;
                    key_domains_[domain].push_back(pack_key(
                        {original[phase], original[(phase + 1) % 3], original[(phase + 2) % 3]}));
                }
            }
        }
    }

    static int key_id(const Key& key) {
        return (key[0] * rune_count + key[1]) * rune_count + key[2];
    }

    static WordList alias_words(const std::shared_ptr<const WordReadings>& readings, const WordReading& entry) {
        return WordList(readings, &entry.words);
    }

    template<class Emit>
    void free_openings(const Key& key, ReadingCache& cache, OpeningScratch& scratch,
                       int first, int last, Emit&& emit) const {
        int size = geo_.size();
        last = std::min(last, size - 1);
        if (first >= last) return;
        if (english_.longest_word() > 64) {
            for (int start = first; start < last; ++start) offset_openings(start, key, cache, scratch, emit);
            return;
        }
        std::array<std::array<char, rune_count>, 3> decoded;
        for (int phase = 0; phase < 3; ++phase)
            for (int rune = 0; rune < rune_count; ++rune)
                decoded[phase][rune] = static_cast<char>(mod29(rune - key[phase]));
        auto& words = scratch.word_ends;
        words.resize(std::bit_ceil(static_cast<unsigned>(std::min(size, 4096))));
        std::uint32_t first_runes = 0;
        for (int rune = 0; rune < rune_count; ++rune)
            if (english_.can_start(decoded[0][rune])) first_runes |= std::uint32_t{1} << rune;
        for (int residue = 0; residue < 3; ++residue) {
            std::fill(words.begin(), words.end(), OpeningScratch::WordEnds{});
            auto rune_at = [&](int pos) { return decoded[(pos + 3 - residue) % 3][geo_.rune(pos)]; };
            auto word_ends = [&](int pos) {
                auto& slot = words[static_cast<std::size_t>(pos) & (words.size() - 1)];
                if (slot.start != pos) {
                    slot = {pos, 0};
                    english_.matches(size, pos, rune_at, [&](int end, int) {
                        slot.lengths |= std::uint64_t{1} << (end - pos - 1);
                    });
                }
                return slot.lengths;
            };
            for (int start = first + (residue + 3 - first % 3) % 3; start < last; start += 3) {
                if (!(first_runes & (std::uint32_t{1} << geo_.rune(start)))) continue;
                // The pending bits describe the next 64 endpoints relative to
                // the current position. A dictionary edge spans at most 64 runes.
                auto pending = word_ends(start);
                if (!pending) continue;
                int pos = start + 1;
                auto& stream = scratch.stream;
                stream.clear();
                while (pending) {
                    int advance = std::countr_zero(pending);
                    pending >>= advance;
                    pos += advance;
                    auto length = pos - start;
                    if (length >= 2) {
                        Span cells{start, 1, length};
                        if (geo_.quarter_sign(geo_.leftmost(cells)) >= 0) {
                            for (int i = static_cast<int>(stream.size()); i < length; ++i)
                                stream.push_back(rune_at(start + i));
                            auto readings = cache.get(stream);
                            if (readings) emit(OpeningBlock{cells, std::move(readings)});
                        }
                    }
                    if (pos == size) break;
                    pending = (pending >> 1) | word_ends(pos);
                    ++pos;
                }
            }
        }
    }

    template<class Emit>
    void offset_openings(int start, const Key& key, ReadingCache& cache, OpeningScratch& scratch,
                         Emit&& emit) const {
        int size = geo_.size() - start;
        if (size < 2 || !english_.can_start(mod29(geo_.rune(start) - key[0]))) return;
        auto& stream = scratch.stream;
        auto& reachable = scratch.reachable;
        int farthest = english_.decode_reachable(size, [&](int i) {
            return static_cast<char>(mod29(geo_.rune(start + i) - key[i % 3]));
        }, stream, reachable);
        for (int length = 2; length <= farthest; ++length) {
            Span cells{start, 1, length};
            if (!reachable[length] || geo_.quarter_sign(geo_.leftmost(cells)) < 0) continue;
            auto readings = cache.get(std::string_view(stream).substr(0, length));
            if (readings) emit(OpeningBlock{cells, std::move(readings)});
        }
    }

    template<class Emit>
    void offset_candidates(Opening mode, const OpeningKey& node, ReadingCache& cache,
                           OpeningScratch& scratch, Emit&& emit) const {
        int single = node.node[0] + node.center_totient;
        if (mode == Opening::short_search) offset_openings(single, node.key, cache, scratch, emit);
        offset_openings(single + geo_.phi(node.center_totient), node.key, cache, scratch, emit);
    }

    std::vector<RuneRun> repeated_runs() const {
        std::vector<RuneRun> runs;
        int required = english_.longest_word() + 1;
        int reusable = 0;
        for (int begin = 0; begin < geo_.size();) {
            Rune rune = geo_.rune(begin);
            int end = begin + 1;
            while (end < geo_.size() && geo_.rune(end) == rune) ++end;
            if (end - begin >= 2 * std::int64_t(required)) {
                runs.push_back({begin, end, rune});
                reusable += end - begin - required + 1;
            }
            begin = end;
        }
        if (reusable < geo_.size() / 4) runs.clear();
        return runs;
    }

    template<class Emit>
    void free_repeated(const Key& key, ReadingCache& cache, OpeningScratch& scratch,
                       const std::vector<RuneRun>& runs, Emit&& emit) const {
        int required = english_.longest_word() + 1;
        std::array<std::int8_t, rune_count> discard;
        discard.fill(-1);
        int skipped = 0;
        for (const auto& run : runs) {
            auto& skip = discard[run.rune];
            if (skip < 0) {
                int farthest = english_.decode_reachable(required, [&](int i) {
                    return static_cast<char>(mod29(run.rune - key[i % 3]));
                }, scratch.stream, scratch.reachable);
                skip = farthest < 2;
            }
            if (skip) skipped += run.end - run.begin - required + 1;
        }
        if (skipped < geo_.size() / 4) {
            free_openings(key, cache, scratch, 0, geo_.size(), emit);
            return;
        }
        // No candidate can start at least 'required' cells before the end of
        // a rejected run. The extra cell accounts for a one-rune first word.
        int start = 0;
        for (const auto& run : runs) {
            if (!discard[run.rune]) continue;
            for (; start < run.begin; ++start) offset_openings(start, key, cache, scratch, emit);
            start = run.end - required + 1;
        }
        for (; start < geo_.size() - 1; ++start) offset_openings(start, key, cache, scratch, emit);
    }

    template<class Emit>
    void each_free_opening(const Key& key, ReadingCache& cache, OpeningScratch& scratch,
                           const std::vector<RuneRun>& runs, std::size_t part, std::size_t parts,
                           Emit&& emit) const {
        if (runs.empty()) {
            auto size = static_cast<std::uint64_t>(geo_.size());
            int first = static_cast<int>(size * part / parts);
            int last = static_cast<int>(size * (part + 1) / parts);
            free_openings(key, cache, scratch, first, last, emit);
        }
        else free_repeated(key, cache, scratch, runs, emit);
    }

    std::size_t free_parts(std::size_t keys, const std::vector<RuneRun>& runs) const {
        auto threads = static_cast<std::size_t>(workers_.count());
        if (!keys || threads == 1 || !runs.empty()) return 1;
        auto wanted = (threads * 4 + keys - 1) / keys;
        return std::min(wanted, 1 + (static_cast<std::size_t>(geo_.size()) - 1) / 65536);
    }

    Layer openings(Opening mode) {
        std::vector<OpeningScratch> scratch(workers_.count());
        Layer frontier;
        auto append = [&](auto& entries, const OpeningKey& node, const OpeningBlock& block) {
            // Each node has one opening key and each start and length occurs
            // once for that key. Its readings are already ranked.
            State state{node.node, block.cells, block.cells.start, node.phase, node.outer, node.phase};
            entries.push_back({state, Ranking(OpeningReadings{block.readings, pack_key(node.key)})});
        };
        auto visit_offsets = [&](const OpeningKey& node, std::size_t worker, auto&& emit) {
            offset_candidates(mode, node, cache_[worker], scratch[worker], emit);
        };
        if (mode != Opening::free && mode != Opening::heading && geo_.size() >= 65536) {
            // Select nodes, decode their offsets and build rankings in one pass.
            constexpr std::size_t cells_per_task = 512;
            auto tasks = (geo_.size() + cells_per_task - 1) / cells_per_task;
            auto window = std::size_t(workers_.count()) * 4;
            workers_.ordered(tasks, window, [&](std::size_t task, std::size_t worker) {
                std::vector<RankedState> entries;
                auto first = task * cells_per_task;
                auto last = std::min<std::size_t>(geo_.size(), first + cells_per_task);
                for (auto cell = first; cell < last; ++cell) {
                    if (auto node = geo_.opening_key(static_cast<Cell>(cell), mode))
                        visit_offsets(*node, worker,
                            [&](const OpeningBlock& block) { append(entries, *node, block); });
                }
                return entries;
            }, [&](std::size_t, std::vector<RankedState> entries) {
                for (auto& entry : entries) frontier.entries.push_back(std::move(entry));
            });
            return frontier;
        }
        auto add = [&](const OpeningKey& node, const std::vector<OpeningBlock>& blocks) {
            for (const auto& block : blocks) append(frontier.entries, node, block);
        };
        if (mode == Opening::free) {
            struct Group {
                Key key;
                std::size_t centers = 0;
                std::vector<std::size_t> nonempty_parts;
            };
            std::array<int, rune_count * rune_count * rune_count> by_key;
            by_key.fill(-1);
            std::vector<Group> groups;
            for (Cell center = 0; center < geo_.size(); ++center) {
                auto node = geo_.opening_key(center, mode);
                if (!node) continue;
                auto& index = by_key[key_id(node->key)];
                if (index < 0) {
                    index = static_cast<int>(groups.size());
                    groups.push_back({node->key, 0, {}});
                }
                ++groups[index].centers;
            }
            auto runs = geo_.size() > 1024 && !groups.empty() ? repeated_runs() : std::vector<RuneRun>{};
            auto parts = free_parts(groups.size(), runs);
            std::vector<std::vector<OpeningBlock>> results(groups.size() * parts);
            workers_.run(results.size(), 1, [&](std::size_t i, std::size_t worker) {
                auto& result = results[i];
                each_free_opening(groups[i / parts].key, cache_[worker], scratch[worker], runs, i % parts, parts,
                    [&](OpeningBlock block) { result.push_back(std::move(block)); });
                std::sort(result.begin(), result.end(), [](const auto& a, const auto& b) {
                    return std::tie(a.cells.start, a.cells.length) < std::tie(b.cells.start, b.cells.length);
                });
            });
            std::size_t count = 0;
            for (std::size_t i = 0; i < results.size(); ++i) {
                if (results[i].empty()) continue;
                auto& group = groups[i / parts];
                if (results[i].size() > (std::numeric_limits<std::size_t>::max() - count) / group.centers)
                    throw std::length_error("Too many opening states.");
                count += group.centers * results[i].size();
                group.nonempty_parts.push_back(i);
            }
            if (!count) return frontier;
            frontier.entries.reserve(count);
            // Revisit centers in discovery order. Keeping every opening key
            // in memory would duplicate data already present in the matrix.
            for (Cell center = 0; center < geo_.size(); ++center) {
                auto node = geo_.opening_key(center, mode);
                if (!node) continue;
                for (auto i : groups[by_key[key_id(node->key)]].nonempty_parts) add(*node, results[i]);
            }
        } else {
            auto nodes = geo_.opening_keys(mode);
            auto find_openings = [&](const OpeningKey& node, std::size_t worker,
                                     std::vector<OpeningBlock>& blocks) {
                visit_offsets(node, worker, [&](OpeningBlock block) { blocks.push_back(std::move(block)); });
            };
            if (nodes.size() < 768 || workers_.count() == 1) {
                std::vector<OpeningBlock> blocks;
                for (const auto& node : nodes) {
                    blocks.clear();
                    find_openings(node, 0, blocks);
                    add(node, blocks);
                }
            } else {
                constexpr std::size_t chunk = 16 << 10;
                std::vector<std::vector<OpeningBlock>> results(std::min(nodes.size(), chunk));
                for (std::size_t offset = 0; offset < nodes.size(); offset += chunk) {
                    auto length = std::min(nodes.size() - offset, chunk);
                    workers_.run(length, 64, [&](std::size_t i, std::size_t worker) {
                        results[i].clear();
                        find_openings(nodes[offset + i], worker, results[i]);
                    });
                    for (std::size_t i = 0; i < length; ++i) add(nodes[offset + i], results[i]);
                }
            }
        }
        return frontier;
    }

    Successors advance(const RankedState& current, ReadingCache& cache, Expansion expansion,
                       const std::atomic<bool>* shared_continuation = nullptr, const StartRows* rows = nullptr) const {
        const auto& state = current.state;
        Cell left = geo_.leftmost(state.cells);
        auto [phase, quarter_sum] = geo_.next_phase(state, left);
        bool terminal_only = expansion == Expansion::terminal;
        auto forecast = terminal_only ? Geometry::FinalForecast{} : geo_.final_forecast(state);
        Successors result;
        Ranking opening_parents;
        const Ranking* parents = nullptr;
        auto parent_readings = [&]() -> const Ranking& {
            if (parents) return *parents;
            if (const auto* opening = current.readings.opening()) {
                Step step{state.node, state.cells, opening->key};
                opening_parents.reserve(opening->words->size());
                for (const auto& entry : *opening->words)
                    opening_parents.push_back(extend({}, 0.0 + entry.score,
                        {entry.score, alias_words(opening->words, entry), step}));
                parents = &opening_parents;
            } else {
                parents = &current.readings;
            }
            return *parents;
        };
        Span cached_span{-1, 0, 0};
        std::optional<KeyPairs> possible_keys;
        auto select_segment = [&](Span cells) {
            if (cached_span == cells) return;
            cached_span = cells;
            cache.next_segment();
        };
        auto get_readings = [&](Span cells, PackedKey packed, bool by_segment) {
            auto read_key = [&]() -> std::shared_ptr<const WordReadings> {
                auto key = unpack_key(packed);
                if (!geo_.final_alignment(forecast, cells, key)) return {};
                char buffer[64];
                if (cells.length <= static_cast<int>(sizeof buffer)) {
                    geo_.decrypt(cells, key, buffer);
                    return cache.get(std::string_view(buffer, cells.length));
                }
                return cache.read_long(cells.length, [&](int i) {
                    return static_cast<char>(mod29(geo_.rune(cells.start + i * cells.stride) - key[i % 3]));
                });
            };
            auto lookup = cells.length == 2 ? static_cast<PackedKey>(packed >> 5) : packed;
            return by_segment ? cache.segment_reading(lookup, read_key) : read_key();
        };
        auto prepare_segment = [&](Span cells, int outer, int middle, bool mirror) -> const KeyPairs* {
            if (geo_.size() < (1 << 20)) return nullptr;
            bool short_block = cells.length <= 32;
            if (short_block) select_segment(cells);
            auto& possible = possible_keys.emplace();
            int domain = (outer * 3 + middle + 1) * 2 + mirror;
            int first = (3 - phase.phase) % 3;
            int center = (first + 1) % 3, last = (first + 2) % 3;
            // Store allowed endpoints for keys with a complete reading.
            // On long spans, test reachability without scoring unused readings.
            for (auto packed : key_domains_[domain]) {
                auto key = unpack_key(packed);
                if (short_block) {
                    if (!get_readings(cells, packed, true)) continue;
                } else {
                    if (!geo_.final_alignment(forecast, cells, key)) continue;
                    if (!cache.can_read(cells.length, [&](int i) {
                            return static_cast<char>(mod29(geo_.rune(cells.start + i * cells.stride) - key[i % 3]));
                        })) continue;
                }
                auto middle_runes = middle_sources_[key[center]];
                while (middle_runes) {
                    int raw = std::countr_zero(middle_runes);
                    middle_runes &= middle_runes - 1;
                    possible.allow(raw, key[first], key[last]);
                }
            }
            return &possible;
        };
        auto limit_ray = [&](Span cells, int outer, int middle, bool mirror) {
            if (cells.length < ray_probe || terminal_only ||
                (expansion == Expansion::detect && geo_.size() < (1 << 20))) return cells.length;
            int domain = (outer * 3 + middle + 1) * 2 + mirror;
            std::string cipher(ray_probe, '\0');
            for (int i = 0; i < ray_probe; ++i)
                cipher[i] = static_cast<char>(geo_.rune(cells.start + i * cells.stride));
            int cap = cache.ray_limit(std::move(cipher), key_domains_[domain], domain);
            return cap < 0 ? cells.length : cap;
        };
        result.terminal = !geo_.through25(state, left, quarter_sum, phase, forecast.mod_seven,
            expansion == Expansion::collect, terminal_only, rows, shared_continuation, limit_ray, prepare_segment,
            [&](const Node& node, Span cells, const auto& keys, int count) {
                // At a capped depth we need one verified continuation globally.
                // A worker already inside this state can stop at its first geometric
                // successor if another worker has supplied the lexical witness.
                if (expansion == Expansion::terminal ||
                    (shared_continuation && shared_continuation->load(std::memory_order_relaxed))) return true;
                if (!geo_.final_geometry(forecast, node, cells)) return false;
                Ranking next;
                int last_prefix = -1;
                bool by_segment = geo_.size() > 1024 && (expansion == Expansion::collect || cells.length > 12);
                if (by_segment) select_segment(cells);
                for (int i = 0; i < count; ++i) {
                    if (cells.length == 2) {
                        // Sorted keys with equal first two runes decrypt the same two cells.
                        int prefix = keys[i] >> 5;
                        if (prefix == last_prefix) continue;
                        last_prefix = prefix;
                    }
                    auto readings = get_readings(cells, keys[i], by_segment);
                    if (!readings) continue;
                    result.continues = true;
                    if (expansion == Expansion::detect) return true;
                    const auto& prefix = parent_readings();
                    for (const auto& entry : *readings) {
                        Choice choice{entry.score, alias_words(readings, entry), {node, cells, keys[i]}};
                        for (const auto& parent : prefix) {
                            double score = parent.score + choice.score;
                            admit_step(next, parent.path, score, choice, english_.top());
                        }
                    }
                }
                if (!next.empty())
                    result.states.push_back({{node, cells, state.cells.start, phase.total, phase.outer, phase.phase},
                                             std::move(next)});
                return false;
            });
        return result;
    }

public:
    Search(const Geometry& geo, const English& english, const Workers& workers,
           std::vector<ReadingCache>& cache)
        : geo_(geo), english_(english), workers_(workers), cache_(cache) {}

    struct Result {
        Ranking readings;
        std::vector<std::pair<std::int64_t, std::size_t>> terminal_counts;
        std::int64_t depth = 0;
        bool exhausted = true;
        std::size_t seeds = 0;
    };

private:
    struct FirstLayerSummary {
        std::size_t seeds = 0, terminals = 0;
        Ranking all, terminal;
    };

    class OpeningCenters {
        // A center is followed by a negative end marker when the same key
        // occurs at consecutive cells. Isolated centers still use one Cell.
        std::vector<Cell> positions_;
        Cell last_ = -2;
        std::size_t count_ = 0;

    public:
        void push_back(Cell center) {
            if (center == last_ + 1) {
                if (positions_.back() < 0) positions_.back() = -1 - center;
                else positions_.push_back(-1 - center);
            } else {
                positions_.push_back(center);
            }
            last_ = center;
            ++count_;
        }

        std::size_t size() const { return count_; }

        template<class Visit>
        void each(Visit&& visit) const {
            for (std::size_t i = 0; i < positions_.size();) {
                Cell first = positions_[i++];
                Cell last = i < positions_.size() && positions_[i] < 0 ? -1 - positions_[i++] : first;
                for (Cell center = first; center <= last; ++center) visit(center);
            }
        }
    };

    static auto opening_order(const Step& step) {
        return std::tie(step.node.center, step.cells.start, step.cells.length);
    }

    static void admit_first_opening(Ranking& target, Reading reading, std::size_t top) {
        if (target.size() == top && reading.score < target.back().score) return;
        auto pos = std::lower_bound(target.begin(), target.end(), reading, reading_less);
        if (pos == target.end() && target.size() == top) return;
        if (pos != target.end() && !reading_less(reading, *pos)) {
            const auto& a = reading.path->last.step;
            const auto& b = pos->path->last.step;
            // The ordinary search sees nodes in row order, then start/length.
            if (opening_order(a) < opening_order(b)) *pos = std::move(reading);
            return;
        }
        target.insert(pos, std::move(reading));
        if (target.size() > top) target.pop_back();
    }

    void rank_opening(Ranking& target, const std::shared_ptr<const WordReadings>& readings,
                      const Step& step, bool order_ties) const {
        auto top = english_.top();
        for (const auto& entry : *readings) {
            double score = 0.0 + entry.score;
            if (target.size() == top && score < target.back().score) break;
            auto pos = std::lower_bound(target.begin(), target.end(), entry,
                [&](const Reading& existing, const WordReading&) {
                    if (existing.score != score) return existing.score > score;
                    return *existing.path->last.words < entry.words;
                });
            if (pos == target.end() && target.size() == top) continue;
            bool duplicate = pos != target.end() && pos->score == score && *pos->path->last.words == entry.words;
            if (duplicate && (!order_ties || opening_order(pos->path->last.step) <= opening_order(step))) continue;
            auto reading = extend({}, score, {entry.score, alias_words(readings, entry), step});
            if (duplicate) *pos = std::move(reading);
            else target.insert(pos, std::move(reading));
            if (target.size() > top) target.pop_back();
        }
    }

    void rank_first_opening(Ranking& target, const OpeningBlock& block, const OpeningKey& node) const {
        rank_opening(target, block.readings, {node.node, block.cells, pack_key(node.key)}, true);
    }

    void rank_state(Ranking& target, const RankedState& entry, std::size_t top) const {
        if (const auto* opening = entry.readings.opening()) {
            rank_opening(target, opening->words, {entry.state.node, entry.state.cells, opening->key}, false);
        } else {
            for (const auto& reading : entry.readings) admit(target, reading, top);
        }
    }

    void merge_first_layer(FirstLayerSummary& total, FirstLayerSummary&& part) const {
        total.seeds += part.seeds;
        total.terminals += part.terminals;
        auto top = english_.top();
        for (auto& reading : part.all) admit_first_opening(total.all, std::move(reading), top);
        for (auto& reading : part.terminal) admit_first_opening(total.terminal, std::move(reading), top);
    }

    template<class ShowDepth>
    Result first_layer_result(FirstLayerSummary&& summary, bool exhausted, std::ostream* progress,
                              bool by_depth, ShowDepth&& show_depth) {
        Result answer;
        if (!summary.seeds) return answer;
        answer.seeds = summary.seeds;
        answer.depth = 1;
        answer.exhausted = exhausted;
        answer.readings = std::move(summary.terminal);
        if (summary.terminals) answer.terminal_counts.emplace_back(1, summary.terminals);
        if (progress) *progress << "Block 1: " << answer.seeds << " states.\n";
        if (by_depth) show_depth(1, summary.all);
        return answer;
    }

    template<class ShowDepth>
    Result solve_first_offsets(Opening mode, std::int64_t blocks, std::ostream* progress,
                               bool by_depth, ShowDepth&& show_depth) {
        const Workers single(1);
        std::atomic<bool> continuation{false};
        std::vector<OpeningScratch> scratch(workers_.count());
        std::vector<FirstLayerSummary> summaries(workers_.count());
        constexpr std::size_t cells_per_task = 1024;
        auto size = static_cast<std::size_t>(geo_.size());
        auto tasks = (size + cells_per_task - 1) / cells_per_task;
        workers_.run(tasks, 1, [&](std::size_t task, std::size_t worker) {
            auto& part = summaries[worker];
            auto first = task * cells_per_task;
            auto last = std::min(size, first + cells_per_task);
            for (auto cell = first; cell < last; ++cell) {
                auto node = geo_.opening_key(static_cast<Cell>(cell), mode);
                if (!node) continue;
                offset_candidates(mode, *node, cache_[worker], scratch[worker], [&](OpeningBlock block) {
                    if (!part.seeds) geo_.prepare_transitions(single);
                    ++part.seeds;
                    if (by_depth) rank_first_opening(part.all, block, *node);
                    RankedState state{{node->node, block.cells, block.cells.start, node->phase, node->outer, node->phase}, {}};
                    auto needed = blocks == 1 || continuation.load(std::memory_order_relaxed)
                        ? Expansion::terminal : Expansion::detect;
                    auto result = advance(state, cache_[worker], needed,
                                          needed == Expansion::detect ? &continuation : nullptr);
                    if (result.continues) continuation.store(true, std::memory_order_relaxed);
                    if (result.terminal) {
                        ++part.terminals;
                        rank_first_opening(part.terminal, block, *node);
                    }
                });
            }
        });
        FirstLayerSummary total;
        for (auto& summary : summaries) merge_first_layer(total, std::move(summary));
        return first_layer_result(std::move(total), blocks == 1 || !continuation.load(std::memory_order_relaxed),
                                  progress, by_depth, std::forward<ShowDepth>(show_depth));
    }

    template<class ShowDepth>
    Result solve_first_free(std::int64_t blocks, std::ostream* progress,
                            bool by_depth, ShowDepth&& show_depth) {
        struct Group {
            OpeningKey first;
            OpeningCenters centers;
        };
        std::array<int, rune_count * rune_count * rune_count> ids;
        ids.fill(-1);
        std::vector<Group> groups;
        for (Cell center = 0; center < geo_.size(); ++center) {
            auto node = geo_.opening_key(center, Opening::free);
            if (!node) continue;
            auto& id = ids[key_id(node->key)];
            if (id < 0) {
                id = static_cast<int>(groups.size());
                groups.push_back({*node, {}});
            }
            groups[id].centers.push_back(center);
        }
        if (groups.empty()) return {};
        auto runs = repeated_runs();
        auto parts = free_parts(groups.size(), runs);
        std::vector<OpeningScratch> scratch(workers_.count());
        std::vector<FirstLayerSummary> summaries(workers_.count());
        std::atomic<bool> continuation{false};
        const Workers single(1);
        workers_.run(groups.size() * parts, 1, [&](std::size_t index, std::size_t worker) {
            const auto& group = groups[index / parts];
            auto& summary = summaries[worker];
            auto emit = [&](const OpeningBlock& block) {
                if (!summary.seeds) geo_.prepare_transitions(single);
                summary.seeds += group.centers.size();
                if (by_depth) rank_first_opening(summary.all, block, group.first);
                Cell first_terminal = -1;
                // The common outer sign and phase are fixed by the multiset
                // of key signatures. The horizontal node needs only its center.
                auto [phase, outer] = std::pair{group.first.phase, group.first.outer};
                group.centers.each([&](Cell center) {
                    RankedState state{{{center - 1, center, center + 1}, block.cells,
                                       block.cells.start, phase, outer, phase}, {}};
                    auto needed = blocks == 1 || continuation.load(std::memory_order_relaxed)
                        ? Expansion::terminal : Expansion::detect;
                    auto result = advance(state, cache_[worker], needed,
                                          needed == Expansion::detect ? &continuation : nullptr);
                    if (result.continues) continuation.store(true, std::memory_order_relaxed);
                    if (result.terminal) {
                        ++summary.terminals;
                        if (first_terminal < 0) first_terminal = center;
                    }
                });
                if (first_terminal >= 0 && (!blocks || blocks == 1)) {
                    auto node = group.first;
                    node.node = {first_terminal - 1, first_terminal, first_terminal + 1};
                    rank_first_opening(summary.terminal, block, node);
                }
            };
            each_free_opening(group.first.key, cache_[worker], scratch[worker], runs, index % parts, parts, emit);
        });
        FirstLayerSummary total;
        for (auto& summary : summaries) merge_first_layer(total, std::move(summary));
        return first_layer_result(std::move(total), blocks == 1 || !continuation.load(std::memory_order_relaxed),
                                  progress, by_depth, std::forward<ShowDepth>(show_depth));
    }

public:
    template<class ShowDepth>
    Result solve(Opening mode, std::int64_t max_depth, std::int64_t blocks, bool all_lengths,
                 std::ostream* progress, bool by_depth, ShowDepth&& show_depth) {
        if (geo_.size() > 1024 && blocks != 1 && (max_depth > 1 || geo_.size() >= (1 << 20)))
            build_key_domains();
        if (mode == Opening::free && geo_.size() >= 65536 && (max_depth == 1 || blocks == 1))
            return solve_first_free(blocks, progress, by_depth, std::forward<ShowDepth>(show_depth));
        if ((mode == Opening::scan || mode == Opening::short_search) && geo_.size() >= 65536 &&
            (max_depth == 1 || blocks == 1))
            return solve_first_offsets(mode, blocks, progress, by_depth, std::forward<ShowDepth>(show_depth));
        auto frontier = openings(mode);
        Result answer;
        answer.seeds = frontier.entries.size();
        auto top = english_.top();
        if (!frontier.entries.empty()) {
            geo_.prepare_transitions(workers_);
        }
        while (!frontier.entries.empty()) {
            frontier.release_index();
            auto depth = ++answer.depth;
            if (progress) *progress << "Block " << depth << ": " << frontier.entries.size() << " states.\n";
            if (by_depth) {
                Ranking ranking;
                auto rank_states = [&](Ranking& target, std::size_t begin, std::size_t end) {
                    for (auto i = begin; i < end; ++i)
                        rank_state(target, frontier.entries[i], top);
                };
                auto count = frontier.entries.size();
                if (count >= 16384 && workers_.count() > 1) {
                    constexpr std::size_t grain = 4096;
                    std::vector<Ranking> ranks((count + grain - 1) / grain);
                    workers_.run(ranks.size(), 1, [&](std::size_t i, std::size_t) {
                        rank_states(ranks[i], i * grain, std::min(count, (i + 1) * grain));
                    });
                    for (auto& rank : ranks)
                        for (auto& reading : rank) admit(ranking, std::move(reading), top);
                } else {
                    rank_states(ranking, 0, count);
                }
                show_depth(depth, ranking);
            }
            Layer following;
            std::size_t terminals = 0;
            bool has_successor = false;
            bool terminal_only = blocks == depth;
            auto expansion = terminal_only ? Expansion::terminal :
                             depth == max_depth ? Expansion::detect : Expansion::collect;
            auto finish_state = [&](std::size_t i, bool terminal) {
                if (terminal) {
                    ++terminals;
                    if (!blocks || blocks == depth)
                        rank_state(answer.readings, frontier.entries[i], top);
                }
                // No later task reads rankings from this processed state.
                Ranking{}.swap(frontier.entries[i].readings);
                frontier.entries.release_through(i);
            };
            auto merge_successors = [&](Successors successors) {
                has_successor |= successors.continues;
                for (std::size_t j = 0; j < successors.states.size(); ++j) {
                    auto& successor = successors.states[j];
                    auto& target = following.at(successor.state);
                    if (target.empty()) {
                        target = std::move(successor.readings);
                    } else {
                        for (auto& reading : successor.readings) admit(target, std::move(reading), top);
                    }
                    successors.states.release_through(j);
                }
            };
            auto merge = [&](std::size_t i, Successors successors) {
                finish_state(i, successors.terminal);
                merge_successors(std::move(successors));
            };

            Ranking previous;
            if (!all_lengths && (!blocks || blocks == depth)) previous.swap(answer.readings);
            const auto size = frontier.entries.size();
            bool costly = geo_.size() >= 65536 && size > 1;
            auto threads = std::size_t(workers_.count());
            if (expansion == Expansion::collect && threads > 1 && size < threads * 2 &&
                geo_.size() >= (1 << 20) && geo_.height() >= 128 && geo_.streams_keys()) {
                // Classify terminal states first. For the others, expand contiguous
                // start-row ranges in parallel and merge them in discovery order.
                struct Task { std::size_t source; StartRows rows; };
                std::vector<std::uint8_t> terminal(size);
                workers_.run(size, 1, [&](std::size_t i, std::size_t worker) {
                    terminal[i] = advance(frontier.entries[i], cache_[worker], Expansion::terminal).terminal;
                });
                std::vector<Task> tasks;
                auto shared_centers = std::make_unique<KeyCentersForState[]>(size);
                auto active = std::max<std::size_t>(1, std::count(terminal.begin(), terminal.end(), 0));
                int parts = static_cast<int>(std::min<std::size_t>(geo_.height(), threads * 12 / active));
                int step = std::max(16, (geo_.height() + parts - 1) / parts);
                for (std::size_t i = 0; i < size; ++i) {
                    if (terminal[i]) continue;
                    for (int row = 1; row <= geo_.height(); row += step)
                        tasks.push_back({i, {row, std::min(row + step - 1, geo_.height()), &shared_centers[i]}});
                }
                workers_.ordered(tasks.size(), threads * 2, [&](std::size_t i, std::size_t worker) {
                    const auto& task = tasks[i];
                    return advance(frontier.entries[task.source], cache_[worker], Expansion::collect, nullptr, &task.rows);
                }, [&](std::size_t, Successors result) { merge_successors(std::move(result)); });
                for (std::size_t i = 0; i < size; ++i) finish_state(i, terminal[i]);
            } else if ((size <= 512 && !costly) || threads == 1) {
                for (std::size_t i = 0; i < size; ++i) {
                    auto needed = has_successor && expansion == Expansion::detect ? Expansion::terminal : expansion;
                    merge(i, advance(frontier.entries[i], cache_[0], needed));
                }
            } else if (costly && expansion == Expansion::collect) {
                // Cost per state varies greatly on large maps. Let the workers
                // move ahead while the consumer merges earlier results.
                auto window = std::max<std::size_t>(32, std::size_t(workers_.count()) * 4);
                bool reserved = false;
                workers_.ordered(size, window, [&](std::size_t i, std::size_t worker) {
                    return advance(frontier.entries[i], cache_[worker], Expansion::collect);
                }, [&](std::size_t i, Successors result) {
                    if (!reserved && result.states.size()) {
                        following.reserve(result.states.size());
                        reserved = true;
                    }
                    merge(i, std::move(result));
                });
            } else if (expansion != Expansion::collect) {
                constexpr std::size_t chunk = 96 << 10;
                std::vector<std::uint8_t> terminal(std::min(size, chunk));
                for (std::size_t offset = 0; offset < size; offset += chunk) {
                    auto length = std::min(chunk, size - offset);
                    auto needed = has_successor && expansion == Expansion::detect ? Expansion::terminal : expansion;
                    std::atomic<bool> continuation{has_successor};
                    auto grain = costly ? workers_.grain(length) : 64;
                    workers_.run(length, grain, [&](std::size_t i, std::size_t worker) {
                        auto requested = needed;
                        if (requested == Expansion::detect && continuation.load(std::memory_order_relaxed))
                            requested = Expansion::terminal;
                        auto result = advance(frontier.entries[offset + i], cache_[worker], requested,
                                              requested == Expansion::detect ? &continuation : nullptr);
                        terminal[i] = result.terminal;
                        if (result.continues)
                            continuation.store(true, std::memory_order_relaxed);
                    });
                    has_successor = continuation.load(std::memory_order_relaxed);
                    for (std::size_t i = 0; i < length; ++i) finish_state(offset + i, terminal[i]);
                }
            } else {
                constexpr std::size_t chunk = 96 << 10;
                std::vector<Successors> computed(std::min(size, chunk));
                for (std::size_t offset = 0; offset < size; offset += chunk) {
                    auto length = std::min(size - offset, chunk);
                    workers_.run(length, 64, [&](std::size_t i, std::size_t worker) {
                        computed[i] = advance(frontier.entries[offset + i], cache_[worker], Expansion::collect);
                    });
                    if (offset == 0) {
                        std::size_t candidates = 0;
                        for (const auto& result : computed) candidates += result.states.size();
                        if (candidates) following.reserve(candidates);
                    }
                    for (std::size_t i = 0; i < length; ++i) merge(offset + i, std::move(computed[i]));
                }
            }
            if (answer.readings.empty() && !previous.empty()) answer.readings.swap(previous);
            if (terminals) answer.terminal_counts.emplace_back(depth, terminals);
            if (expansion == Expansion::detect) answer.exhausted = !has_successor;
            if (following.entries.empty()) break;
            frontier = std::move(following);
        }
        return answer;
    }
};

} // namespace lp
