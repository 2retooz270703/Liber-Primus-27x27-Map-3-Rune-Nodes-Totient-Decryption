#pragma once

#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <exception>
#include <mutex>
#include <system_error>
#include <thread>
#include <memory>
#include <optional>
#include <vector>

namespace lp {

// The caller participates as worker zero. Other workers sleep between jobs.
class Workers {
    struct Job {
        std::size_t size, grain, workers;
        const void* task;
        void (*invoke)(const void*, std::size_t, std::size_t);
        std::atomic<std::size_t> next{0};
        std::mutex error_mutex;
        std::exception_ptr error;

        Job(std::size_t size, std::size_t grain, std::size_t workers, const void* task,
            void (*invoke)(const void*, std::size_t, std::size_t))
            : size(size), grain(grain), workers(workers), task(task), invoke(invoke) {}

        void run(std::size_t worker) {
            try {
                for (;;) {
                    auto first = next.fetch_add(grain, std::memory_order_relaxed);
                    if (first >= size) break;
                    for (auto i = first, end = first + std::min(grain, size - first); i < end; ++i)
                        invoke(task, i, worker);
                }
            } catch (...) {
                next.store(size, std::memory_order_relaxed);
                std::lock_guard lock(error_mutex);
                if (!error) error = std::current_exception();
            }
        }
    };

    unsigned count_;
    mutable std::mutex submit_, mutex_;
    mutable std::condition_variable available_, completed_;
    mutable std::vector<std::thread> threads_;
    mutable Job* job_ = nullptr;
    mutable std::size_t generation_ = 0, pending_ = 0;
    mutable bool resource_limited_ = false;
    bool stopping_ = false;

    void worker_loop(std::size_t id, std::size_t seen) const {
        std::unique_lock lock(mutex_);
        for (;;) {
            available_.wait(lock, [&] {
                return stopping_ || (job_ && seen != generation_ && id < job_->workers);
            });
            if (stopping_) return;
            auto* job = job_;
            seen = generation_;
            lock.unlock();
            job->run(id);
            lock.lock();
            if (--pending_ == 0) completed_.notify_one();
        }
    }

public:
    explicit Workers(unsigned count) : count_(std::max(1u, count)) {}
    Workers(const Workers&) = delete;
    Workers& operator=(const Workers&) = delete;

    ~Workers() {
        {
            std::lock_guard lock(mutex_);
            stopping_ = true;
        }
        available_.notify_all();
        for (auto& worker : threads_) worker.join();
    }

    template<class Task>
    void run(std::size_t size, std::size_t grain, Task&& task) const {
        if (!size) return;
        auto active = std::min<std::size_t>(count_, 1 + (size - 1) / grain);
        if (active == 1) {
            for (std::size_t i = 0; i < size; ++i) task(i, 0);
            return;
        }

        std::lock_guard submission(submit_);
        std::unique_lock lock(mutex_);
        while (!resource_limited_ && threads_.size() + 1 < active) {
            try {
                threads_.emplace_back(&Workers::worker_loop, this, threads_.size() + 1, generation_);
            } catch (const std::system_error& error) {
                if (error.code() != std::errc::resource_unavailable_try_again) throw;
                resource_limited_ = true;
            }
        }
        active = std::min(active, threads_.size() + 1);
        // The job never outlives this stack frame. Type erase a local pointer
        // so mutable callbacks and const callables work without copying them.
        auto* callable = std::addressof(task);
        Job job(size, grain, active, &callable, [](const void* context, std::size_t i, std::size_t worker) {
            (*(*static_cast<decltype(callable) const*>(context)))(i, worker);
        });
        pending_ = active - 1;
        job_ = &job;
        ++generation_;
        lock.unlock();
        if (active > 1) available_.notify_all();
        job.run(0);
        lock.lock();
        completed_.wait(lock, [&] { return pending_ == 0; });
        job_ = nullptr;
        if (job.error) std::rethrow_exception(job.error);
    }

    // Permit several producers to keep computing while one thread merges in
    // input order. The consumer can compute too when the next slot is pending.
    template<class Compute, class Consume>
    void ordered(std::size_t size, std::size_t window, Compute&& compute, Consume&& consume) const {
        if (!size) return;
        using Result = decltype(compute(std::size_t{}, std::size_t{}));
        window = std::min(window, size);
        std::vector<std::optional<Result>> slots(window);
        std::mutex queue;
        std::condition_variable changed;
        std::size_t next = 0, consumed = 0;
        bool cancelled = false;
        std::exception_ptr failure;
        run(std::min<std::size_t>(size, count_), 1, [&](std::size_t role, std::size_t worker) {
            auto can_compute = [&] { return next < size && next - consumed < window; };
            std::unique_lock lock(queue);
            try {
                for (;;) {
                    changed.wait(lock, [&] {
                        return cancelled || consumed == size ||
                            (role == 0 && slots[consumed % window]) || can_compute() ||
                            (role != 0 && next == size);
                    });
                    if (cancelled || consumed == size) return;
                    if (role == 0 && slots[consumed % window]) {
                        auto index = consumed++;
                        auto& slot = slots[index % window];
                        auto result = std::move(*slot);
                        slot.reset();
                        lock.unlock();
                        changed.notify_all();
                        consume(index, std::move(result));
                        lock.lock();
                    } else if (can_compute()) {
                        auto index = next++;
                        lock.unlock();
                        auto result = compute(index, worker);
                        lock.lock();
                        slots[index % window].emplace(std::move(result));
                        changed.notify_all();
                    } else {
                        return;
                    }
                }
            } catch (...) {
                if (!lock.owns_lock()) lock.lock();
                if (!failure) failure = std::current_exception();
                cancelled = true;
                changed.notify_all();
            }
        });
        if (failure) std::rethrow_exception(failure);
    }

    unsigned count() const { return count_; }

    // Create several independent chunks per worker to absorb unequal work.
    std::size_t grain(std::size_t items, std::size_t maximum = 64) const {
        auto chunks = std::size_t(count_) * 4;
        return std::clamp(items / chunks, std::size_t{1}, maximum);
    }
};

} // namespace lp
