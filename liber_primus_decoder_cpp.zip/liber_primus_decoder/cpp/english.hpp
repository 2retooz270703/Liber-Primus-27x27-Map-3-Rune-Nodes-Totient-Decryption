#pragma once

#include "input.hpp"

#include <charconv>
#include <memory>
#include <unordered_set>

namespace lp {

using Words = std::vector<int>;

struct WordReading {
    double score;
    Words words;
};

using WordReadings = std::vector<WordReading>;

struct WordScratch {
    struct Match { int end, word; };
    struct Suffix {
        double score;
        std::size_t tail;
        int word, length;
    };
    std::vector<Match> matches;
    std::vector<std::size_t> offsets;
    std::vector<std::uint8_t> reachable;
    std::vector<Suffix> suffixes, candidates;
};

// Base 10^9 keeps parsing inexpensive and allows custom dictionaries to use
// Python's range of integer counts. Division rounds the exact ratio to double.
class Count {
    static constexpr std::uint64_t base = 1'000'000'000;
    std::vector<std::uint32_t> digits_;

public:
    explicit Count(unsigned value = 0) : digits_{value} {}
    explicit Count(std::string_view digits) {
        while (digits.size() > 1 && digits.front() == '0') digits.remove_prefix(1);
        for (std::size_t end = digits.size(); end > 0;) {
            std::size_t start = end > 9 ? end - 9 : 0;
            std::uint32_t value = 0;
            for (std::size_t i = start; i < end; ++i) value = value * 10 + digits[i] - '0';
            digits_.push_back(value);
            end = start;
        }
    }

    void add(const Count& other) {
        digits_.resize(std::max(digits_.size(), other.digits_.size()));
        unsigned carry = 0;
        for (std::size_t i = 0; i < digits_.size(); ++i) {
            unsigned value = digits_[i] + carry + (i < other.digits_.size() ? other.digits_[i] : 0);
            carry = value >= base;
            digits_[i] = value - carry * base;
        }
        if (carry) digits_.push_back(carry);
    }

    void increment() {
        for (auto& d : digits_) {
            if (++d < base) return;
            d = 0;
        }
        digits_.push_back(1);
    }

    bool zero() const { return digits_.size() == 1 && digits_[0] == 0; }

    std::uint64_t small() const {
        return digits_.size() > 2 ? std::numeric_limits<std::uint64_t>::max() :
            digits_[0] + (digits_.size() == 2 ? digits_[1] * base : 0);
    }

    bool operator<(const Count& other) const {
        if (digits_.size() != other.digits_.size()) return digits_.size() < other.digits_.size();
        return std::lexicographical_compare(digits_.rbegin(), digits_.rend(),
                                            other.digits_.rbegin(), other.digits_.rend());
    }

    void twice() {
        unsigned carry = 0;
        for (auto& digit : digits_) {
            unsigned d = 2 * digit + carry;
            carry = d >= base;
            digit = d - carry * base;
        }
        if (carry) digits_.push_back(carry);
    }

    void subtract(const Count& other) {
        int borrow = 0;
        for (std::size_t i = 0; i < digits_.size(); ++i) {
            int d = static_cast<int>(digits_[i]) - borrow;
            if (i < other.digits_.size()) d -= static_cast<int>(other.digits_[i]);
            borrow = d < 0;
            digits_[i] = d + borrow * static_cast<int>(base);
        }
        while (digits_.size() > 1 && digits_.back() == 0) digits_.pop_back();
    }

    double ratio(const Count& denominator) const {
        auto norm = denominator.small();
        if (norm <= (std::uint64_t{1} << 53)) return double(small()) / double(norm);
        Count remainder = *this;
        int exponent = 0;
        while (remainder < denominator) {
            if (--exponent < -1075) return 0.0;
            remainder.twice();
        }
        remainder.subtract(denominator);
        if (exponent == -1075) return remainder.zero() ? 0.0 : std::ldexp(1.0, -1074);
        int bits = std::min(52, exponent + 1074);
        std::uint64_t significand = 1;
        for (int bit = 0; bit < bits; ++bit) {
            remainder.twice();
            significand *= 2;
            if (!(remainder < denominator)) { remainder.subtract(denominator); ++significand; }
        }
        remainder.twice();
        if (!(remainder < denominator)) {
            remainder.subtract(denominator);
            if (!remainder.zero() || (significand & 1)) ++significand;
        }
        return std::ldexp(double(significand), exponent - bits);
    }
};

inline int decimal_digit(char32_t c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c < 128) return -1;
    constexpr std::array<char32_t, 67> starts{
        0x660, 0x6f0, 0x7c0, 0x966, 0x9e6, 0xa66, 0xae6, 0xb66, 0xbe6, 0xc66, 0xce6,
        0xd66, 0xde6, 0xe50, 0xed0, 0xf20, 0x1040, 0x1090, 0x17e0, 0x1810, 0x1946,
        0x19d0, 0x1a80, 0x1a90, 0x1b50, 0x1bb0, 0x1c40, 0x1c50, 0xa620, 0xa8d0, 0xa900,
        0xa9d0, 0xa9f0, 0xaa50, 0xabf0, 0xff10, 0x104a0, 0x10d30, 0x11066, 0x110f0,
        0x11136, 0x111d0, 0x112f0, 0x11450, 0x114d0, 0x11650, 0x116c0, 0x11730, 0x118e0,
        0x11950, 0x11c50, 0x11d50, 0x11da0, 0x11f50, 0x16a60, 0x16ac0, 0x16b50,
        0x1d7ce, 0x1d7d8, 0x1d7e2, 0x1d7ec, 0x1d7f6, 0x1e140, 0x1e2f0, 0x1e4f0,
        0x1e950, 0x1fbf0
    };
    auto pos = std::upper_bound(starts.begin(), starts.end(), c);
    if (pos == starts.begin() || c - pos[-1] > 9) return -1;
    return c - pos[-1];
}

inline bool integer_digits(std::string_view value, std::string& digits, bool& negative) {
    negative = value.starts_with('-');
    if (negative || value.starts_with('+')) value.remove_prefix(1);
    bool need_digit = true;
    for (std::size_t pos = 0; pos < value.size();) {
        auto c = utf8_char(value, pos);
        if (c == '_' && !need_digit) { need_digit = true; continue; }
        int n = decimal_digit(c);
        if (n < 0) return false;
        digits += static_cast<char>('0' + n);
        need_digit = false;
    }
    return !need_digit && digits.size() <= 4300;
}

class English {
    struct Word {
        std::string text;
        double score;
    };
    struct TrieNode {
        unsigned letters = 0;
        int first_child = 0;
        int word = -1;
        int fast = -1;
        int qu = 0;

        int child(char c) const {
            unsigned bit = 1u << (c - 'a');
            return (letters & bit) ? first_child + std::popcount(letters & (bit - 1)) : 0;
        }
    };
    using RuneEdges = std::array<std::array<int, 2>, rune_count>;

    std::vector<Word> words_;
    std::vector<TrieNode> trie_{1};
    std::vector<RuneEdges> fast_;
    std::array<std::array<std::string_view, 2>, rune_count> labels_{};
    std::size_t top_;
    int longest_word_ = 0;
    std::uint32_t initial_runes_ = 0;

    int follow(int trie, std::string_view label) const {
        if (label.empty()) return 0;
        for (char c : label) {
            trie = trie_[trie].child(c);
            if (!trie) break;
        }
        return trie;
    }

    void build_trie() {
        std::array<std::string, rune_count> labels;
        for (int rune = 0; rune < rune_count; ++rune) {
            labels[rune] = rune_labels[rune];
            for (auto& c : labels[rune]) if (c >= 'A' && c <= 'Z') c += 'a' - 'A';
            auto label = std::string_view(labels[rune]);
            auto slash = label.find('/');
            labels_[rune][0] = label.substr(0, slash);
            if (slash != label.npos) labels_[rune][1] = label.substr(slash + 1);
        }
        // Retain the backing label storage after the trie is built.
        for (int rune = 0; rune < rune_count; ++rune) {
            label_storage_[rune][0] = labels_[rune][0];
            label_storage_[rune][1] = labels_[rune][1];
            labels_[rune] = {label_storage_[rune][0], label_storage_[rune][1]};
        }
        std::size_t estimate = 1;
        std::string_view previous;
        for (const auto& word : words_) {
            estimate += word.text.size() - std::distance(word.text.begin(),
                std::mismatch(word.text.begin(), word.text.end(), previous.begin(), previous.end()).first);
            longest_word_ = std::max(longest_word_, static_cast<int>(word.text.size()));
            previous = word.text;
        }
        trie_.reserve(estimate);
        std::vector<int> fast_nodes{0};
        struct Range { int begin, end, depth, node; };
        std::vector<Range> pending{{0, static_cast<int>(words_.size()), 0, 0}};
        while (!pending.empty()) {
            auto [begin, end, depth, node] = pending.back();
            pending.pop_back();
            if (words_[begin].text.size() == static_cast<std::size_t>(depth))
                trie_[node].word = begin++;

            trie_[node].first_child = static_cast<int>(trie_.size());
            while (begin < end) {
                char letter = words_[begin].text[depth];
                int stop = begin + 1;
                while (stop < end && words_[stop].text[depth] == letter) ++stop;
                trie_[node].letters |= 1u << (letter - 'a');
                int child = static_cast<int>(trie_.size());
                trie_.emplace_back();
                if (depth < 4) fast_nodes.push_back(child);
                pending.push_back({begin, stop, depth + 1, child});
                begin = stop;
            }
        }
        fast_.reserve(fast_nodes.size());
        for (int node : fast_nodes) {
            trie_[node].fast = static_cast<int>(fast_.size());
            auto& edges = fast_.emplace_back();
            for (int rune = 0; rune < rune_count; ++rune)
                edges[rune] = {follow(node, labels_[rune][0]), follow(node, labels_[rune][1])};
        }
        for (int node = 0; node < static_cast<int>(trie_.size()); ++node)
            trie_[node].qu = follow(node, "qu");
        for (int rune = 0; rune < rune_count; ++rune) {
            const auto& edges = fast_.front()[rune];
            if (edges[0] || edges[1] || (rune == 5 && trie_.front().qu))
                initial_runes_ |= std::uint32_t{1} << rune;
        }
    }

    std::array<std::array<std::string, 2>, rune_count> label_storage_{};

    template<class RuneAt, class Match>
    void walk(int size, int pos, int node, RuneAt& rune_at, Match& match) const {
        const TrieNode& current = trie_[node];
        if (current.word >= 0) match(pos, current.word);
        if (pos == size) return;
        int rune = rune_at(pos);
        auto edges = current.fast >= 0 ? fast_[current.fast][rune] :
            std::array{follow(node, labels_[rune][0]), follow(node, labels_[rune][1])};
        if (edges[0]) walk(size, pos + 1, edges[0], rune_at, match);
        if (edges[1]) walk(size, pos + 1, edges[1], rune_at, match);
        if (rune == 5 && current.qu && pos + 1 < size && rune_at(pos + 1) == 7)
            walk(size, pos + 2, current.qu, rune_at, match);
    }

    bool load_sorted_counts(std::string_view data) {
        std::vector<std::pair<std::string_view, std::uint64_t>> counts;
        constexpr std::uint64_t exact_max = std::uint64_t{1} << 53;
        std::uint64_t total = 0;
        std::string_view previous;
        while (!data.empty()) {
            auto end = data.find('\n');
            auto line = data.substr(0, end);
            data.remove_prefix(end == data.npos ? data.size() : end + 1);
            auto separator = line.find('\t');
            if (separator == line.npos) return false;
            auto word = line.substr(0, separator);
            if (word.empty() || word <= previous ||
                !std::all_of(word.begin(), word.end(), [](char c) { return c >= 'a' && c <= 'z'; }))
                return false;
            previous = word;
            if (line.size() - separator - 1 > 4300) return false;
            std::uint64_t count = 0;
            auto last = line.data() + line.size();
            auto parsed = std::from_chars(line.data() + separator + 1, last, count);
            if (parsed.ec != std::errc{} || parsed.ptr != last) return false;
            if (word.size() == 1 && word != "a" && word != "i") continue;
            if (count >= exact_max - total) return false;
            total += ++count;
            counts.emplace_back(word, count);
        }
        if (counts.empty()) return false;
        words_.reserve(counts.size());
        for (auto [word, count] : counts)
            words_.push_back({std::string(word), std::log10(double(count) / double(total))});
        return true;
    }

public:
    English(const std::filesystem::path& filename, std::size_t top) : top_(top) {
        auto bytes = read_file(filename);
        if (filename.extension() == ".gz") bytes = inflate_gzip(bytes);
        universal_newlines(bytes);
        if (load_sorted_counts(bytes)) {
            build_trie();
            return;
        }
        std::vector<std::pair<std::string_view, Count>> frequencies;
        Count norm;
        std::unordered_set<std::string_view> seen;
        for (std::size_t pos = 0, line = 1; pos < bytes.size(); ++line) {
            auto end = bytes.find('\n', pos);
            if (end == bytes.npos) end = bytes.size();
            auto data = strip(std::string_view(bytes).substr(pos, end - pos));
            pos = end + 1;
            auto invalid = [line] {
                throw std::runtime_error("Invalid frequency dictionary entry on line " + std::to_string(line) + ".");
            };
            auto split = data.find_first_not_of("abcdefghijklmnopqrstuvwxyz");
            if (split == 0 || split == data.npos) invalid();
            auto word = data.substr(0, split);
            auto cursor = split;
            if (!unicode_space(utf8_char(data, cursor))) invalid();
            auto number = strip(data.substr(cursor));
            std::string digits;
            bool negative = false;
            if (!integer_digits(number, digits, negative) || !seen.emplace(word).second) invalid();
            Count count(digits);
            if (negative && !count.zero()) invalid();
            if (word.size() == 1 && word != "a" && word != "i") continue;
            count.increment();
            norm.add(count);
            frequencies.emplace_back(word, std::move(count));
        }
        if (frequencies.empty()) throw std::runtime_error("The dictionary must be nonempty and top must be positive.");
        std::sort(frequencies.begin(), frequencies.end(), [](const auto& a, const auto& b) { return a.first < b.first; });
        words_.reserve(frequencies.size());
        for (auto& [word, count] : frequencies) {
            double ratio = count.ratio(norm);
            if (ratio == 0.0) throw std::runtime_error("math domain error");
            words_.push_back({std::string(word), std::log10(ratio)});
        }
        build_trie();
    }

    English(const English&) = delete;
    English& operator=(const English&) = delete;

    const std::string& word(int i) const { return words_[i].text; }
    std::size_t top() const { return top_; }
    int longest_word() const { return longest_word_; }
    bool can_start(int rune) const { return initial_runes_ & (std::uint32_t{1} << rune); }

    template<class Match>
    void matches(std::string_view code, int start, Match&& match) const {
        auto rune_at = [&](int pos) { return code[pos]; };
        walk(static_cast<int>(code.size()), start, 0, rune_at, match);
    }

    template<class RuneAt, class Match>
    void matches(int size, int start, RuneAt&& rune_at, Match&& match) const {
        walk(size, start, 0, rune_at, match);
    }

    template<class Decrypt>
    int decode_reachable(int size, Decrypt&& decrypt, std::string& stream,
                         std::vector<std::uint8_t>& reachable) const {
        stream.clear();
        reachable.assign(1, 1);
        int farthest = 0;
        // A failing trie branch need not decrypt the rest of the lookahead.
        auto rune_at = [&](int pos) {
            while (static_cast<int>(stream.size()) <= pos)
                stream.push_back(decrypt(static_cast<int>(stream.size())));
            return stream[pos];
        };
        auto match = [&](int end, int) {
            if (end > farthest) {
                reachable.resize(end + 1);
                farthest = end;
            }
            reachable[end] = 1;
        };
        for (int pos = 0; pos < size && pos <= farthest; ++pos) {
            if (!reachable[pos]) continue;
            walk(size, pos, 0, rune_at, match);
        }
        return farthest;
    }

    WordReadings readings(std::string_view code, WordScratch& scratch) const {
        int n = static_cast<int>(code.size());
        // A complete reading can use only word starts reachable from rune 0.
        // Reject incomplete blocks before allocating or scoring any rankings.
        scratch.matches.clear();
        scratch.offsets.resize(static_cast<std::size_t>(n) + 2);
        scratch.reachable.assign(n + 1, 0);
        scratch.reachable[0] = 1;
        int farthest = 0;
        for (int start = 0; start < n && start <= farthest; ++start) {
            scratch.offsets[start] = scratch.matches.size();
            if (!scratch.reachable[start]) continue;
            matches(code, start, [&](int end, int word) {
                scratch.reachable[end] = 1;
                farthest = std::max(farthest, end);
                scratch.matches.push_back({end, word});
            });
        }
        if (farthest != n) return {};
        auto match_end = scratch.matches.size();
        auto& suffixes = scratch.suffixes;
        auto& candidates = scratch.candidates;
        suffixes.assign(1, {0.0, 0, -1, 0});
        scratch.offsets[n + 1] = 0;
        scratch.offsets[n] = suffixes.size();
        auto word_order = [&](const WordScratch::Suffix& a, const WordScratch::Suffix& b) {
            auto first = &a, second = &b;
            for (;;) {
                if (first->word != second->word) return first->word < second->word ? -1 : 1;
                if (first->tail == second->tail) return 0;
                first = &suffixes[first->tail];
                second = &suffixes[second->tail];
            }
        };
        auto less = [&](const WordScratch::Suffix& a, const WordScratch::Suffix& b) {
            if (a.score != b.score) return a.score > b.score;
            return word_order(a, b) < 0;
        };
        for (int start = n - 1; start >= 0; --start) {
            candidates.clear();
            auto match_begin = scratch.offsets[start];
            for (auto i = match_begin; i < match_end; ++i) {
                auto [end, word] = scratch.matches[i];
                for (auto j = scratch.offsets[end + 1]; j < scratch.offsets[end]; ++j) {
                    const auto& tail = suffixes[j];
                    double score = words_[word].score + tail.score;
                    if (candidates.size() == top_ && score < candidates.back().score) break;
                    WordScratch::Suffix candidate{score, j, word, tail.length + 1};
                    auto target = std::lower_bound(candidates.begin(), candidates.end(), candidate, less);
                    if (target != candidates.end() && word_order(candidate, *target) == 0) continue;
                    if (target == candidates.end() && candidates.size() == top_) continue;
                    candidates.insert(target, std::move(candidate));
                    if (candidates.size() > top_) candidates.pop_back();
                }
            }
            // Reuse the match offsets after consuming their edges. The suffix
            // rank at this position occupies [offsets[start+1], offsets[start]).
            suffixes.insert(suffixes.end(), candidates.begin(), candidates.end());
            scratch.offsets[start] = suffixes.size();
            match_end = match_begin;
        }
        WordReadings result;
        result.reserve(scratch.offsets[0] - scratch.offsets[1]);
        for (auto i = scratch.offsets[1]; i < scratch.offsets[0]; ++i) {
            const auto& reading = suffixes[i];
            auto& entry = result.emplace_back(WordReading{reading.score, {}});
            entry.words.reserve(reading.length);
            for (auto j = i; j; j = suffixes[j].tail) entry.words.push_back(suffixes[j].word);
        }
        return result;
    }
};

class ReadingCache {
    using Result = std::shared_ptr<const WordReadings>;

    struct Entry {
        std::uint64_t code = 0;
        Result readings;
    };

    static constexpr int rejected_bits = 15, reading_bits = 12;
    const English& english_;
    WordScratch scratch_;
    std::string partial_;
    std::vector<std::uint8_t> reachable_;
    std::vector<std::uint64_t> rejected_;
    std::vector<Entry> cache_;

    struct SegmentEntry {
        unsigned generation = 0;
        PackedKey key = 0;
        Result readings;
    };
    static constexpr int segment_bits = 13;
    std::vector<SegmentEntry> segment_cache_;
    unsigned segment_generation_ = 0;
    std::unordered_map<std::string, int> ray_limits_;

    Result read(std::string_view code) {
        auto readings = english_.readings(code, scratch_);
        if (readings.empty()) return {};
        return std::make_shared<const WordReadings>(std::move(readings));
    }

public:
    explicit ReadingCache(const English& english) : english_(english) {}

    // A result of -1 means that at least one key could reach beyond the probe.
    int ray_limit(std::string ciphertext, const std::vector<PackedKey>& keys, int domain) {
        const int length = static_cast<int>(ciphertext.size());
        if (english_.longest_word() >= length) return -1;
        ciphertext.push_back(static_cast<char>(domain));
        auto found = ray_limits_.find(ciphertext);
        if (found != ray_limits_.end()) return found->second;
        int maximum = 0;
        for (auto packed : keys) {
            auto key = unpack_key(packed);
            int farthest = english_.decode_reachable(length, [&](int i) {
                return static_cast<char>(mod29(ciphertext[i] - key[i % 3]));
            }, partial_, reachable_);
            if (farthest > length - english_.longest_word()) {
                maximum = -1;
                break;
            }
            maximum = std::max(maximum, farthest);
        }
        if (ray_limits_.size() >= 4096) ray_limits_.clear();
        ray_limits_.emplace(std::move(ciphertext), maximum);
        return maximum;
    }

    void next_segment() {
        if (++segment_generation_ == 0) {
            for (auto& entry : segment_cache_) entry.generation = 0;
            segment_generation_ = 1;
        }
    }

    template<class Read>
    Result segment_reading(PackedKey key, Read&& read) {
        if (segment_cache_.empty()) segment_cache_.resize(1 << segment_bits);
        auto slot = (std::uint32_t{key} * 0x9e3779b9U) >> (32 - segment_bits);
        auto& entry = segment_cache_[slot];
        if (entry.generation != segment_generation_ || entry.key != key) {
            entry.readings = read();
            entry.generation = segment_generation_;
            entry.key = key;
        }
        return entry.readings;
    }

    template<class Decrypt>
    bool can_read(int length, Decrypt&& decrypt) {
        return english_.decode_reachable(length, std::forward<Decrypt>(decrypt), partial_, reachable_) == length;
    }

    template<class Decrypt>
    Result read_long(int length, Decrypt&& decrypt) {
        if (!can_read(length, std::forward<Decrypt>(decrypt))) return {};
        return read(partial_);
    }

    Result get(std::string_view code) {
        // Each rune fits in five bits. A leading marker distinguishes lengths.
        // Replacements affect reuse only. Each miss is recomputed exactly.
        if (code.size() > 12) return read(code);
        std::uint64_t packed = 1;
        for (unsigned char rune : code) packed = (packed << 5) | rune;
        auto hash = (packed ^ (packed >> 29)) * 0x9e3779b97f4a7c15ULL;
        auto rejected_slot = hash >> (64 - rejected_bits);
        if (!rejected_.empty() && rejected_[rejected_slot] == packed) return {};
        auto reading_slot = hash >> (64 - reading_bits);
        if (!cache_.empty() && cache_[reading_slot].code == packed) return cache_[reading_slot].readings;
        auto readings = read(code);
        if (readings) {
            if (cache_.empty()) cache_.resize(std::size_t{1} << reading_bits);
            cache_[reading_slot] = {packed, readings};
        } else {
            if (rejected_.empty()) rejected_.resize(std::size_t{1} << rejected_bits);
            rejected_[rejected_slot] = packed;
        }
        return readings;
    }

};

} // namespace lp
