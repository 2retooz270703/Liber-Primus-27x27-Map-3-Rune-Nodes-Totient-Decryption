#pragma once

#include "geometry.hpp"

#include <cerrno>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <istream>
#include <iterator>
#include <limits>
#include <optional>
#include <sstream>
#include <string_view>
#include <unordered_map>
#include <zlib.h>

namespace lp {

inline constexpr std::array<std::string_view, rune_count> rune_labels{
    "F", "U/V", "TH", "O", "R", "C/K", "G", "W", "H", "N", "I", "J", "EO", "P", "X",
    "S/Z", "T", "B", "E", "M", "L", "NG/ING", "OE", "D", "A", "AE", "Y", "IA/IO", "EA"
};
inline constexpr std::u32string_view glyphs = U"ᚠᚢᚦᚩᚱᚳᚷᚹᚻᚾᛁᛄᛇᛈᛉᛋᛏᛒᛖᛗᛚᛝᛟᛞᚪᚫᚣᛡᛠ";

inline char32_t utf8_char(std::string_view s, std::size_t& p) {
    auto lead = static_cast<unsigned char>(s[p++]);
    if (lead < 128) return lead;
    int bytes = lead >= 0xc2 && lead < 0xe0 ? 2 : lead >= 0xe0 && lead < 0xf0 ? 3 :
                lead >= 0xf0 && lead < 0xf5 ? 4 : 0;
    if (!bytes || p + bytes - 1 > s.size()) throw std::runtime_error("Invalid UTF-8 input.");
    char32_t cp = lead & (0x7f >> bytes);
    for (int i = 1; i < bytes; ++i) {
        auto next = static_cast<unsigned char>(s[p++]);
        if ((next & 0xc0) != 0x80) throw std::runtime_error("Invalid UTF-8 input.");
        cp = (cp << 6) | (next & 0x3f);
    }
    if ((bytes == 3 && cp < 0x800) || (bytes == 4 && cp < 0x10000) ||
        (cp >= 0xd800 && cp <= 0xdfff) || cp > 0x10ffff)
        throw std::runtime_error("Invalid UTF-8 input.");
    return cp;
}

inline void append_utf8(std::string& s, char32_t cp) {
    if (cp < 0x80) {
        s += static_cast<char>(cp);
        return;
    }
    int bytes = cp < 0x800 ? 2 : cp < 0x10000 ? 3 : 4;
    s += static_cast<char>((0xff << (8 - bytes)) | (cp >> (6 * (bytes - 1))));
    for (int i = bytes - 2; i >= 0; --i)
        s += static_cast<char>(0x80 | ((cp >> (6 * i)) & 0x3f));
}

inline bool unicode_space(char32_t c) {
    return (c >= 9 && c <= 13) || (c >= 28 && c <= 32) || c == 0x85 || c == 0xa0 ||
        c == 0x1680 || (c >= 0x2000 && c <= 0x200a) || c == 0x2028 || c == 0x2029 ||
        c == 0x202f || c == 0x205f || c == 0x3000;
}

inline bool line_break(char32_t c) {
    return (c >= 10 && c <= 13) || (c >= 28 && c <= 30) || c == 0x85 ||
        c == 0x2028 || c == 0x2029;
}

inline std::string_view strip(std::string_view s) {
    std::size_t start = 0, stop = 0, p = 0;
    while (p < s.size()) {
        auto before = p;
        auto c = utf8_char(s, p);
        if (!unicode_space(c)) {
            if (!stop) start = before;
            stop = p;
        }
    }
    return stop > start ? s.substr(start, stop - start) : std::string_view{};
}

inline std::string repr(std::string_view s) {
    char quote = s.find('\'') != s.npos && s.find('"') == s.npos ? '"' : '\'';
    std::string result(1, quote);
    constexpr char hex[] = "0123456789abcdef";
    for (unsigned char c : s) {
        if (c == '\\' || c == quote) { result += '\\'; result += static_cast<char>(c); }
        else if (c == '\n') result += "\\n";
        else if (c == '\r') result += "\\r";
        else if (c == '\t') result += "\\t";
        else if (c < 32 || c == 127) { result += "\\x"; result += hex[c >> 4]; result += hex[c & 15]; }
        else result += static_cast<char>(c);
    }
    return result + quote;
}

inline int glyph_index(char32_t cp) {
    if (cp == U'ᛃ' || cp == U'ᛂ') return 11;
    if (cp == U'ᛊ') return 15;
    if (cp == U'ᛜ') return 21;
    auto p = glyphs.find(cp);
    return p == glyphs.npos ? -1 : static_cast<int>(p);
}

inline int rune_index(std::string_view token) {
    if (!token.empty() && token.front() >= '0' && token.front() <= '9') {
        if (token.size() == 1) return token.front() - '0';
        if (token.size() == 2 && token.front() != '0' && token[1] >= '0' && token[1] <= '9') {
            int number = 10 * (token.front() - '0') + token[1] - '0';
            return number < rune_count ? number : -1;
        }
    }
    static const auto index = [] {
        std::unordered_map<std::string, int> map;
        for (int i = 0; i < rune_count; ++i) {
            auto label = rune_labels[i];
            map.emplace(std::to_string(i), i);
            map.emplace(label, i);
            auto slash = label.find('/');
            if (slash != label.npos) {
                map.emplace(label.substr(0, slash), i);
                map.emplace(label.substr(slash + 1), i);
            }
        }
        return map;
    }();
    std::string name;
    std::size_t p = 0;
    while (p < token.size()) {
        auto c = utf8_char(token, p);
        if (c >= U'a' && c <= U'z') c -= 32;
        if (c == U'ſ') c = U'S';
        if (c == U'ı') c = U'I';
        if (c >= 128) return name.empty() && p == token.size() ? glyph_index(c) : -1;
        name += static_cast<char>(c);
    }
    auto it = index.find(name);
    return it == index.end() ? -1 : it->second;
}

struct MatrixEntry {
    std::string token;
    bool quoted;
    bool eligible = true;
};

inline void add_row(Matrix& matrix, const std::vector<MatrixEntry>& row, bool is_array = true) {
    int number = matrix.height + 1;
    if (number == 1) {
        if (!is_array || row.empty())
            throw std::runtime_error("Row 1 must be a nonempty list of rune cells.");
        matrix.width = static_cast<int>(row.size());
    }
    if (!is_array || row.size() != static_cast<std::size_t>(matrix.width))
        throw std::runtime_error("Row " + std::to_string(number) + " must contain " +
                                 std::to_string(matrix.width) + " cells, like row 1.");
    if (matrix.runes.size() + row.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max() / 2))
        throw std::runtime_error("The matrix is too large.");
    for (std::size_t col = 0; col < row.size(); ++col) {
        auto& entry = row[col];
        int rune = entry.eligible ? rune_index(strip(entry.token)) : -1;
        if (rune < 0)
            throw std::runtime_error("Cell (" + std::to_string(number) + "," + std::to_string(col + 1) +
                                     ") contains an unknown rune " +
                                     (entry.quoted ? repr(entry.token) : entry.token) + ".");
        matrix.runes.push_back(static_cast<Rune>(rune));
    }
    ++matrix.height;
}

// Only an array of arrays is a matrix. The parser still consumes other JSON
// values so that invalid cells and malformed JSON are diagnosed separately.
class JsonMatrix {
    std::string_view s_;
    std::size_t pos_ = 0;

    [[noreturn]] void error(std::string_view message, std::size_t at) const {
        std::size_t line = 1, col = 1, offset = 0, p = 0;
        while (p < at) {
            if (utf8_char(s_, p) == U'\n') { ++line; col = 1; }
            else ++col;
            ++offset;
        }
        throw std::runtime_error(std::string(message) + ": line " + std::to_string(line) +
                                 " column " + std::to_string(col) + " (char " + std::to_string(offset) + ")");
    }

    void whitespace() {
        while (pos_ < s_.size() && std::string_view(" \n\r\t").find(s_[pos_]) != s_.npos) ++pos_;
    }

    bool take(char c) {
        if (pos_ == s_.size() || s_[pos_] != c) return false;
        ++pos_;
        return true;
    }

    bool take(std::string_view token) {
        if (!s_.substr(pos_).starts_with(token)) return false;
        pos_ += token.size();
        return true;
    }

    bool digit() const { return pos_ < s_.size() && s_[pos_] >= '0' && s_[pos_] <= '9'; }

    char32_t hex4() {
        auto start = pos_;
        char32_t value = 0;
        for (int i = 0; i < 4; ++i) {
            if (pos_ == s_.size()) error("Invalid \\uXXXX escape", start - 1);
            char c = s_[pos_++];
            int digit = c >= '0' && c <= '9' ? c - '0' : (c | 32) >= 'a' && (c | 32) <= 'f' ?
                        (c | 32) - 'a' + 10 : -1;
            if (digit < 0) error("Invalid \\uXXXX escape", start - 1);
            value = 16 * value + digit;
        }
        return value;
    }

    std::string string() {
        auto start = pos_++;
        std::string value;
        while (pos_ < s_.size()) {
            if (take('"')) return value;
            if (!take('\\')) {
                auto p = pos_;
                auto cp = utf8_char(s_, pos_);
                if (cp < 32) error("Invalid control character at", p);
                value += s_.substr(p, pos_ - p);
                continue;
            }
            if (pos_ == s_.size()) break;
            char escaped = s_[pos_++];
            constexpr std::string_view escapes = "\"\\/bfnrt", decoded = "\"\\/\b\f\n\r\t";
            auto found = escapes.find(escaped);
            if (found != escapes.npos) { value += decoded[found]; continue; }
            if (escaped != 'u') error("Invalid \\escape", pos_ - 2);
            auto cp = hex4();
            if (cp >= 0xd800 && cp <= 0xdbff && s_.substr(pos_).starts_with("\\u")) {
                auto next = pos_;
                pos_ += 2;
                auto low = hex4();
                if (low >= 0xdc00 && low <= 0xdfff) cp = 0x10000 + ((cp - 0xd800) << 10) + (low - 0xdc00);
                else pos_ = next;
            }
            if (cp >= 0xd800 && cp <= 0xdfff) {
                // Surrogates are accepted by Python JSON and can never name a rune.
                std::ostringstream escaped_surrogate;
                escaped_surrogate << "\\u" << std::hex << cp_as_int(cp);
                value += escaped_surrogate.str();
            } else append_utf8(value, cp);
        }
        error("Unterminated string starting at", start);
    }

    static std::uint32_t cp_as_int(char32_t value) { return static_cast<std::uint32_t>(value); }

    template<class Item>
    void sequence(char end, Item&& item) {
        whitespace();
        if (take(end)) return;
        do {
            whitespace();
            item();
            whitespace();
            if (take(end)) return;
        } while (take(','));
        error("Expecting ',' delimiter", pos_);
    }

    MatrixEntry value(int depth) {
        if (depth > 900) throw std::runtime_error("JSON nesting is too deep.");
        if (pos_ < s_.size() && s_[pos_] == '"') return {string(), true};
        if (take('[')) {
            std::string items = "[";
            sequence(']', [&] {
                if (items.size() > 1) items += ", ";
                auto v = value(depth + 1);
                items += v.quoted ? repr(v.token) : v.token;
            });
            return {items + ']', false, false};
        }
        if (take('{')) {
            std::string items = "{";
            sequence('}', [&] {
                if (pos_ == s_.size() || s_[pos_] != '"')
                    error("Expecting property name enclosed in double quotes", pos_);
                if (items.size() > 1) items += ", ";
                items += repr(string()) + ": ";
                whitespace();
                if (!take(':')) error("Expecting ':' delimiter", pos_);
                whitespace();
                auto v = value(depth + 1);
                items += v.quoted ? repr(v.token) : v.token;
            });
            return {items + '}', false, false};
        }
        if (take("true")) return {"True", false, false};
        if (take("false")) return {"False", false, false};
        if (take("null")) return {"None", false, false};
        if (take("NaN")) return {"nan", false, false};
        if (take("Infinity")) return {"inf", false, false};
        if (take("-Infinity")) return {"-inf", false, false};
        auto start = pos_;
        take('-');
        if (!digit()) error("Expecting value", start);
        if (!take('0')) while (digit()) ++pos_;
        bool integer = true;
        if (take('.')) {
            if (!digit()) { --pos_; }
            else { integer = false; while (digit()) ++pos_; }
        }
        if (pos_ < s_.size() && (s_[pos_] == 'e' || s_[pos_] == 'E')) {
            auto exponent = pos_++;
            if (!take('+')) take('-');
            if (!digit()) pos_ = exponent;
            else { integer = false; while (digit()) ++pos_; }
        }
        auto n = s_.substr(start, pos_ - start);
        return {std::string(n == "-0" ? "0" : n), false, integer};
    }

public:
    explicit JsonMatrix(std::string_view data) : s_(data) {}
    Matrix read() {
        Matrix matrix;
        std::vector<MatrixEntry> row;
        std::exception_ptr invalid_row;
        ++pos_; // Opening bracket already identified by read_matrix.
        sequence(']', [&] {
            bool array = take('[');
            row.clear();
            if (array) sequence(']', [&] {
                auto entry = value(0);
                if (!invalid_row) row.push_back(std::move(entry));
            });
            else value(0);
            // Syntax errors later in the file still take precedence over invalid cells.
            if (!invalid_row) {
                try {
                    add_row(matrix, row, array);
                } catch (const std::runtime_error&) {
                    invalid_row = std::current_exception();
                }
            }
        });
        whitespace();
        if (pos_ != s_.size()) error("Extra data", pos_);
        if (invalid_row) std::rethrow_exception(invalid_row);
        return matrix;
    }
};

inline bool numeric_whitespace(int c) {
    return c == ' ' || c == '\n' || c == '\r' || c == '\t';
}

template<class Peek, class Advance, class Whitespace>
std::optional<Matrix> read_numeric_matrix(Peek&& peek, Advance&& advance, Whitespace&& whitespace) {
    int token = peek();
    while (token == 0xef) {
        advance();
        if (peek() != 0xbb) return {};
        advance();
        if (peek() != 0xbf) return {};
        advance();
        token = peek();
    }
    if (numeric_whitespace(token)) token = whitespace();
    if (token != '[') return {};
    advance();
    Matrix matrix;
    constexpr auto max_cells = static_cast<std::size_t>(std::numeric_limits<int>::max() / 2);
    for (;;) {
        if (whitespace() != '[') return {};
        advance();
        auto first = matrix.runes.size();
        for (;;) {
            auto rune = static_cast<unsigned>(whitespace() - '0');
            if (rune > 9) return {};
            advance();
            token = peek();
            auto units = static_cast<unsigned>(token - '0');
            if (units <= 9) {
                if (!rune) return {};
                rune = rune * 10 + units;
                advance();
                token = peek();
            }
            if (rune >= rune_count || matrix.runes.size() + 1 >= max_cells) return {};
            matrix.runes.push_back(static_cast<Rune>(rune));
            if (numeric_whitespace(token)) token = whitespace();
            if (token != ']' && token != ',') return {};
            advance();
            if (token == ']') break;
        }
        auto width = static_cast<int>(matrix.runes.size() - first);
        if (!matrix.height) matrix.width = width;
        else if (matrix.width != width) return {};
        ++matrix.height;
        token = whitespace();
        if (token != ']' && token != ',') return {};
        advance();
        if (token == ']') break;
    }
    if (whitespace() != -1) return {};
    return matrix;
}

inline std::optional<Matrix> read_numeric_matrix(std::string_view data) {
    std::size_t pos = 0;
    auto peek = [&] { return pos < data.size() ? static_cast<unsigned char>(data[pos]) : -1; };
    auto whitespace = [&] {
        while (pos < data.size() && numeric_whitespace(data[pos])) ++pos;
        return peek();
    };
    return read_numeric_matrix(peek, [&] { ++pos; }, whitespace);
}

inline std::optional<Matrix> read_numeric_matrix_file(const std::filesystem::path& path) {
    std::error_code error;
    if (!std::filesystem::is_regular_file(path, error) || error) return {};
    auto length = std::filesystem::file_size(path, error);
    if (error || length < (1 << 20)) return {};
    std::ifstream file(path, std::ios::binary);
    if (!file) return {};
    std::array<char, 65536> buffer;
    auto pos = buffer.data(), end = pos;
    auto refill = [&] {
        if (!file.good()) return false;
        file.read(buffer.data(), buffer.size());
        pos = buffer.data();
        end = pos + file.gcount();
        return pos != end;
    };
    auto peek = [&]() -> int {
        return pos != end || refill() ? static_cast<unsigned char>(*pos) : -1;
    };
    auto whitespace = [&]() -> int {
        for (;;) {
            while (pos != end && numeric_whitespace(*pos)) ++pos;
            if (pos != end) return static_cast<unsigned char>(*pos);
            if (!refill()) return -1;
        }
    };
    auto matrix = read_numeric_matrix(peek, [&] { ++pos; }, whitespace);
    return file.bad() ? std::optional<Matrix>{} : std::move(matrix);
}

inline Matrix read_matrix(std::string_view data) {
    while (data.starts_with("\xef\xbb\xbf")) data.remove_prefix(3);
    // The general parser remains responsible for names, escaping, Unicode
    // whitespace, and the precise ordering of syntax and cell errors.
    if (auto numeric = read_numeric_matrix(data)) return std::move(*numeric);
    data = strip(data);
    Matrix matrix;
    if (data.starts_with('[')) matrix = JsonMatrix(data).read();
    else {
        std::size_t row_start = 0;
        for (std::size_t cursor = 0; cursor <= data.size();) {
            auto end = cursor;
            if (cursor < data.size() && !line_break(utf8_char(data, cursor))) continue;
            if (end == data.size()) ++cursor;
            auto line = strip(data.substr(row_start, end - row_start));
            row_start = cursor;
            if (line.empty()) continue;
            std::vector<MatrixEntry> row;
            bool pending_separator = true;
            std::size_t start = 0;
            bool in_token = false;
            auto empty = [&] {
                throw std::runtime_error("Row " + std::to_string(matrix.height + 1) + " contains an empty cell.");
            };
            for (std::size_t p = 0; p < line.size();) {
                auto before = p;
                auto c = utf8_char(line, p);
                bool separator = c == ',' || c == ';';
                if (unicode_space(c) || separator) {
                    if (in_token) row.push_back({std::string(line.substr(start, before - start)), true});
                    in_token = false;
                    if (separator) {
                        if (pending_separator) empty();
                        pending_separator = true;
                    }
                } else {
                    if (!in_token) start = before;
                    in_token = true;
                    pending_separator = false;
                }
            }
            if (pending_separator) empty();
            if (in_token) row.push_back({std::string(line.substr(start)), true});
            if (row.size() == 1) {
                std::vector<MatrixEntry> glyph_row;
                auto token = std::string_view(row[0].token);
                for (std::size_t p = 0; p < token.size();) {
                    auto before = p;
                    if (glyph_index(utf8_char(token, p)) < 0) { glyph_row.clear(); break; }
                    glyph_row.push_back({std::string(token.substr(before, p - before)), true});
                }
                if (!glyph_row.empty()) row = std::move(glyph_row);
            }
            add_row(matrix, row);
        }
    }
    if (matrix.height == 0) throw std::runtime_error("The matrix must contain at least one row.");
    return matrix;
}

inline std::string read_file(const std::filesystem::path& path) {
    std::ifstream file(path, std::ios::binary);
    if (!file || std::filesystem::is_directory(path)) {
        int err = file ? EISDIR : errno;
        throw std::runtime_error("[Errno " + std::to_string(err) + "] " +
            std::error_code(err, std::generic_category()).message() + ": " + repr(path.string()));
    }
    std::string bytes;
    std::error_code size_error;
    auto length = std::filesystem::file_size(path, size_error);
    if (!size_error && length <= bytes.max_size() &&
        length <= static_cast<std::uintmax_t>(std::numeric_limits<std::streamsize>::max())) {
        bytes.resize(static_cast<std::size_t>(length));
        if (length) {
            file.read(bytes.data(), static_cast<std::streamsize>(length));
            bytes.resize(static_cast<std::size_t>(file.gcount()));
        }
    }
    if (file.good()) bytes.append(std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>());
    if (file.bad()) throw std::runtime_error("Could not read " + repr(path.string()) + ".");
    return bytes;
}

inline void universal_newlines(std::string& bytes) {
    if (bytes.find('\r') == bytes.npos) return;
    std::size_t out = 0;
    for (std::size_t in = 0; in < bytes.size(); ++in) {
        if (bytes[in] != '\r') bytes[out++] = bytes[in];
        else {
            bytes[out++] = '\n';
            if (in + 1 < bytes.size() && bytes[in + 1] == '\n') ++in;
        }
    }
    bytes.resize(out);
}

inline std::string byte_repr(std::string_view bytes) {
    char quote = bytes.find('\'') != bytes.npos && bytes.find('"') == bytes.npos ? '"' : '\'';
    std::string out = "b";
    out += quote;
    constexpr char hex[] = "0123456789abcdef";
    for (unsigned char c : bytes) {
        if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else if (c < 32 || c >= 127) { out += "\\x"; out += hex[c >> 4]; out += hex[c & 15]; }
        else {
            if (c == quote || c == '\\') out += '\\';
            out += static_cast<char>(c);
        }
    }
    return out + quote;
}

inline std::string inflate_gzip(std::string_view compressed) {
    struct Inflater {
        z_stream stream{};
        Inflater() {
            if (inflateInit2(&stream, 16 + MAX_WBITS) != Z_OK)
                throw std::runtime_error("Could not initialize gzip.");
        }
        ~Inflater() { inflateEnd(&stream); }
    } inflater;
    auto& stream = inflater.stream;
    std::array<unsigned char, 65536> buffer;
    std::string result;
    std::size_t consumed = 0, member_start = 0, member_output = 0;
    while (consumed < compressed.size()) {
        if (consumed == member_start && !compressed.substr(consumed).starts_with("\x1f\x8b"))
            throw std::runtime_error("Not a gzipped file (" + byte_repr(compressed.substr(consumed, 2)) + ")");
        auto chunk = std::min(compressed.size() - consumed, std::size_t(std::numeric_limits<uInt>::max()));
        stream.next_in = reinterpret_cast<Bytef*>(const_cast<char*>(compressed.data() + consumed));
        stream.avail_in = static_cast<uInt>(chunk);
        stream.next_out = buffer.data();
        stream.avail_out = static_cast<uInt>(buffer.size());
        auto status = inflate(&stream, Z_NO_FLUSH);
        consumed += chunk - stream.avail_in;
        result.append(reinterpret_cast<const char*>(buffer.data()), buffer.size() - stream.avail_out);
        if (status == Z_STREAM_END) {
            while (consumed < compressed.size() && compressed[consumed] == '\0') ++consumed;
            if (consumed == compressed.size()) return result;
            member_start = consumed;
            member_output = result.size();
            if (inflateReset(&stream) != Z_OK) throw std::runtime_error("Could not initialize gzip.");
        } else if (status != Z_OK) {
            std::string_view message = stream.msg ? stream.msg : "Invalid gzip file.";
            if (message == "unknown compression method") throw std::runtime_error("Unknown compression method");
            if (message == "incorrect length check") throw std::runtime_error("Incorrect length of data produced");
            if (message == "incorrect data check" && consumed >= 4) {
                std::uint32_t expected = 0;
                for (int i = 0; i < 4; ++i)
                    expected |= std::uint32_t(static_cast<unsigned char>(compressed[consumed - 4 + i])) << (8 * i);
                auto data = std::string_view(result).substr(member_output);
                auto actual = crc32(0, Z_NULL, 0);
                while (!data.empty()) {
                    auto n = std::min(data.size(), std::size_t(std::numeric_limits<uInt>::max()));
                    actual = crc32(actual, reinterpret_cast<const Bytef*>(data.data()), static_cast<uInt>(n));
                    data.remove_prefix(n);
                }
                std::ostringstream error;
                error << std::hex << "CRC check failed 0x" << expected << " != 0x" << actual;
                throw std::runtime_error(error.str());
            }
            throw std::runtime_error("Error " + std::to_string(status) + " while decompressing data: " +
                                     std::string(message));
        }
    }
    if (!compressed.empty()) throw std::runtime_error("Compressed file ended before the end-of-stream marker was reached");
    return result;
}

} // namespace lp
