#pragma once

#include <algorithm>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <limits>
#include <sstream>
#include <string>
#include <string_view>
#include <thread>

#if defined(__linux__)
#include <cerrno>
#include <sched.h>
#endif

namespace lp {

struct CpuBudget {
    unsigned affinity;
    unsigned quota;
    unsigned available() const { return std::min(affinity, quota); }
};

#if defined(__linux__)
inline unsigned affinity_count() {
    for (unsigned slots = CPU_SETSIZE; slots <= (1u << 20); slots *= 2) {
        auto* mask = CPU_ALLOC(slots);
        if (!mask) return 0;
        auto bytes = CPU_ALLOC_SIZE(slots);
        auto status = sched_getaffinity(0, bytes, mask);
        auto error = errno;
        unsigned count = status == 0 ? CPU_COUNT_S(bytes, mask) : 0;
        CPU_FREE(mask);
        if (status == 0 || error != EINVAL) return count;
    }
    return 0;
}

inline std::string unescape_mount_path(std::string_view path) {
    std::string result;
    for (std::size_t i = 0; i < path.size(); ++i) {
        if (path[i] == '\\' && i + 3 < path.size() &&
            path[i+1] >= '0' && path[i+1] <= '7' &&
            path[i+2] >= '0' && path[i+2] <= '7' &&
            path[i+3] >= '0' && path[i+3] <= '7') {
            int byte = 64 * (path[i+1] - '0') + 8 * (path[i+2] - '0') + path[i+3] - '0';
            result += static_cast<char>(byte);
            i += 3;
        } else {
            result += path[i];
        }
    }
    return result;
}

inline bool has_controller(std::string_view controllers, std::string_view match) {
    while (!controllers.empty()) {
        auto comma = controllers.find(',');
        if (controllers.substr(0, comma) == match) return true;
        if (comma == controllers.npos) break;
        controllers.remove_prefix(comma + 1);
    }
    return false;
}

inline unsigned quota_workers(std::uint64_t quota, std::uint64_t period) {
    if (!quota || !period) return std::numeric_limits<unsigned>::max();
    return static_cast<unsigned>(std::min(quota / period + (quota % period != 0),
                                         std::uint64_t(std::numeric_limits<unsigned>::max())));
}

inline unsigned quota_at(const std::filesystem::path& path, bool unified) {
    if (unified) {
        std::ifstream file(path / "cpu.max");
        std::uint64_t quota, period;
        if (file >> quota >> period) return quota_workers(quota, period);
    } else {
        std::ifstream quota_file(path / "cpu.cfs_quota_us");
        std::ifstream period_file(path / "cpu.cfs_period_us");
        std::int64_t quota;
        std::uint64_t period;
        if ((quota_file >> quota) && quota > 0 && (period_file >> period))
            return quota_workers(static_cast<std::uint64_t>(quota), period);
    }
    return std::numeric_limits<unsigned>::max();
}

inline unsigned cgroup_quota(std::istream& memberships, std::istream& mounts) {
    unsigned limit = std::numeric_limits<unsigned>::max();
    std::string unified_path, legacy_path, line;
    while (std::getline(memberships, line)) {
        auto first = line.find(':');
        if (first == line.npos) continue;
        auto second = line.find(':', first + 1);
        if (second == line.npos) continue;
        auto controllers = std::string_view(line).substr(first + 1, second - first - 1);
        if (controllers.empty()) unified_path = line.substr(second + 1);
        else if (has_controller(controllers, "cpu")) legacy_path = line.substr(second + 1);
    }
    while (std::getline(mounts, line)) {
        auto separator = line.find(" - ");
        if (separator == line.npos) continue;
        std::istringstream fs(line.substr(separator + 3));
        std::string type, source, options;
        if (!(fs >> type >> source >> options)) continue;
        bool unified = type == "cgroup2";
        if (!unified && (type != "cgroup" || !has_controller(options, "cpu"))) continue;
        const auto& membership = unified ? unified_path : legacy_path;
        if (membership.empty()) continue;
        std::istringstream fields(line.substr(0, separator));
        std::string id, parent, device, root_field, mount_field;
        if (!(fields >> id >> parent >> device >> root_field >> mount_field)) continue;
        auto root = unescape_mount_path(root_field);
        auto mount = std::filesystem::path(unescape_mount_path(mount_field)).lexically_normal();
        std::string_view relative = membership;
        if (root != "/") {
            if (relative == root) relative = {};
            else if (relative.starts_with(root) && relative.size() > root.size() &&
                     relative[root.size()] == '/') relative.remove_prefix(root.size());
            else if (relative != "/") continue;
        }
        auto suffix = std::filesystem::path(relative).relative_path();
        if (std::any_of(suffix.begin(), suffix.end(), [](const auto& part) { return part == ".."; })) continue;
        auto path = mount;
        limit = std::min(limit, quota_at(path, unified));
        for (const auto& part : suffix) {
            if (part.empty() || part == ".") continue;
            path /= part;
            limit = std::min(limit, quota_at(path, unified));
        }
    }
    return limit;
}

inline unsigned cgroup_quota() {
    std::ifstream memberships("/proc/self/cgroup");
    std::ifstream mounts("/proc/self/mountinfo");
    return cgroup_quota(memberships, mounts);
}
#endif

inline CpuBudget cpu_budget() {
    unsigned affinity = 0;
    unsigned quota = std::numeric_limits<unsigned>::max();
#if defined(__linux__)
    affinity = affinity_count();
    quota = cgroup_quota();
#endif
    if (!affinity) affinity = std::max(1u, std::thread::hardware_concurrency());
    return {affinity, quota};
}

} // namespace lp
