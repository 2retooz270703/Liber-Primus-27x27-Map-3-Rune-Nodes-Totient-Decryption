#pragma once

#include "workers.hpp"

#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <memory>
#include <mutex>
#include <cstdint>
#include <numeric>
#include <stdexcept>
#include <string>
#include <tuple>
#include <vector>

namespace lp {

constexpr int limit = 7;
constexpr int rune_count = 29;
constexpr std::array primes{2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47,
                            53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109};
using Key = std::array<int, 3>;
using PackedKey = std::uint16_t;

inline PackedKey pack_key(const Key& key) {
    return static_cast<PackedKey>((key[0] << 10) | (key[1] << 5) | key[2]);
}

inline Key unpack_key(PackedKey key) {
    return {key >> 10, (key >> 5) & 31, key & 31};
}
using Rune = std::uint8_t;
using Cell = int;
using Node = std::array<Cell, 3>;

struct Matrix {
    int height = 0;
    int width = 0;
    std::vector<Rune> runes;
};

enum class Opening { free, short_search, scan, heading };

inline int mod3(int value) {
    return (value % 3 + 3) % 3;
}

inline int mod29(int value) {
    return value < 0 ? value + rune_count : value;
}

struct Point {
    int row;
    int col;
};

inline int distance(Point a, Point b) {
    return std::max(std::abs(a.row - b.row), std::abs(a.col - b.col));
}

inline int ray_offset(Point a, Point b) {
    int dr = std::abs(a.row - b.row), dc = std::abs(a.col - b.col);
    return std::min({dr, dc, std::abs(dr - dc)});
}

struct SpanInterval {
    int first, last;
    bool empty() const { return first > last; }

    void require_at_least(int offset, int slope, int value) {
        if (slope > 0) {
            int numerator = value - offset;
            first = std::max(first, numerator / slope + (numerator % slope > 0));
        } else if (slope < 0) {
            int numerator = offset - value;
            int divisor = -slope;
            last = std::min(last, numerator / divisor - (numerator % divisor < 0));
        } else if (offset < value) {
            last = 0;
        }
    }
};

inline std::array<SpanInterval, 2> sector_spans(Point origin, Point start, Point direction,
                                                bool vertical, int first, int last) {
    // |row| >= |col| iff (row - col) and (row + col) have the same
    // sign or one is zero. Along a ray both expressions are linear.
    int row = start.row - origin.row, col = start.col - origin.col;
    int a = row - col, b = row + col;
    int da = direction.row - direction.col, db = direction.row + direction.col;
    int strict = vertical ? 0 : 1, sign = vertical ? 1 : -1;
    SpanInterval positive{first, last}, negative{first, last};
    positive.require_at_least(a, da, strict);
    positive.require_at_least(sign * b, sign * db, strict);
    negative.require_at_least(-a, -da, strict);
    negative.require_at_least(-sign * b, -sign * db, strict);
    if (positive.empty() || (!negative.empty() && negative.first < positive.first))
        std::swap(positive, negative);
    if (!positive.empty() && !negative.empty() && negative.first <= positive.last + 1) {
        positive.last = std::max(positive.last, negative.last);
        negative = {1, 0};
    }
    return {positive, negative};
}

inline SpanInterval covered_radii(Point center, Point direction, Point start, Point left, SpanInterval radii) {
    // Rule 22 requires a node inside the intersection of the two Chebyshev squares.
    int row_min = std::max(start.row, left.row) - limit, row_max = std::min(start.row, left.row) + limit;
    int col_min = std::max(start.col, left.col) - limit, col_max = std::min(start.col, left.col) + limit;
    if (row_min > row_max || col_min > col_max) return {1, 0};
    SpanInterval signed_radius{-radii.last, radii.last};
    auto restrict_axis = [&](int origin, int step, int low, int high) {
        if (!step) return origin >= low && origin <= high;
        int first = step > 0 ? low - origin : origin - high;
        int last = step > 0 ? high - origin : origin - low;
        signed_radius.first = std::max(signed_radius.first, first);
        signed_radius.last = std::min(signed_radius.last, last);
        return !signed_radius.empty();
    };
    if (!restrict_axis(center.row, direction.row, row_min, row_max) ||
        !restrict_axis(center.col, direction.col, col_min, col_max)) return {1, 0};
    if (signed_radius.first <= 0 && signed_radius.last >= 0) return radii;
    // If the center is outside the intersection, only one endpoint direction can reach it.
    if (signed_radius.last < 0) signed_radius = {-signed_radius.last, -signed_radius.first};
    int first = std::max(radii.first, signed_radius.first);
    first += (first ^ radii.first) & 1;
    return {first, signed_radius.last};
}

// Each block is an arithmetic progression of row-major cell IDs.
// For openings the stride is 1, including across row boundaries.
struct Span {
    Cell start;
    int stride;
    int length;

    Cell end() const { return start + stride * (length - 1); }
    bool operator==(const Span&) const = default;
};

// Every key node is symmetric about its center in linear cell coordinates.
struct KeyPosition {
    Cell center, displacement;

    KeyPosition(const Node& node) : center(node[1]), displacement(node[1] - node[0]) {}

    Node cells() const { return {center - displacement, center, center + displacement}; }
    bool operator==(const KeyPosition&) const = default;
};

struct State {
    KeyPosition node;
    Span cells;
    Cell previous_start;
    int total;
    std::uint8_t outer;
    std::uint8_t phase;

    State(const Node& key_node, Span span, Cell previous, int sum, int sign, int alignment)
        : node(key_node), cells(span), previous_start(previous), total(sum),
          outer(static_cast<std::uint8_t>(sign)), phase(static_cast<std::uint8_t>(alignment)) {}
    bool operator==(const State&) const = default;
};

struct StateHash {
    std::size_t operator()(const State& s) const {
        std::uint64_t hash = 0x84222325cbf29ce4ULL;
        for (int value : {s.node.center, s.node.displacement, s.cells.start, s.cells.stride,
                          s.cells.length, s.previous_start, s.total, s.outer * 3 + s.phase}) {
            hash ^= static_cast<std::uint32_t>(value);
            hash *= 0x100000001b3ULL;
        }
        return static_cast<std::size_t>(hash ^ (hash >> 32));
    }
};

// Rule 20 caps two GCDs at seven. Along a ray their second argument is fixed.
class StartAddressFilter {
    struct Divisor {
        std::uint32_t inverse, threshold;
        int shift;

        Divisor() = default;

        explicit Divisor(std::uint32_t n) : inverse(1), threshold(UINT32_MAX / n), shift(std::countr_zero(n)) {
            auto odd = n >> shift;
            for (int i = 0; i < 5; ++i) inverse *= 2 - odd * inverse;
        }

        bool divides(std::uint32_t n) const {
            return std::rotr(n * inverse, shift) <= threshold;
        }
    };

    // Eight small exclusions and at most seven distinct primes above seven
    // fit in a positive 32-bit address.
    std::array<Divisor, 15> common_;
    std::size_t count_ = 0;
    bool forbid_four_, forbid_eight_, forbid_twelve_;

public:
    StartAddressFilter(int start_address, const std::vector<int>& primes)
        : forbid_four_(start_address % 4 == 0), forbid_eight_(start_address % 8 == 0),
          forbid_twelve_(start_address % 12 == 0) {
        // These are the minimal forbidden divisors shared by both GCD tests.
        for (int divisor : {9, 10, 14, 15, 21, 25, 35, 49})
            if (start_address % divisor == 0) common_[count_++] = Divisor(divisor);
        int remainder = start_address;
        for (int prime : {2, 3, 5, 7})
            while (remainder % prime == 0) remainder /= prime;
        for (int factor : primes) {
            if (factor <= 7) continue;
            if (factor * factor > remainder) break;
            if (remainder % factor) continue;
            common_[count_++] = Divisor(factor);
            do remainder /= factor; while (remainder % factor == 0);
        }
        if (remainder > 1) common_[count_++] = Divisor(remainder);
    }

    bool allows(int front, int back) const {
        if ((forbid_four_ && front % 4 == 0) || (forbid_eight_ && back % 8 == 0) ||
            (forbid_twelve_ && back % 12 == 0)) return false;
        for (std::size_t i = 0; i < count_; ++i) {
            const auto& divisor = common_[i];
            if (divisor.divides(front) || divisor.divides(back)) return false;
        }
        return true;
    }
};

struct Phase {
    int total, outer, phase;
};

struct KeyCentersForState {
    std::once_flag ready;
    std::vector<Cell> cells;
};

struct StartRows {
    int first, last;
    KeyCentersForState* key_centers;
};

struct KeyPairs {
    std::array<std::array<std::uint32_t, rune_count>, rune_count> ends{};
    std::array<bool, rune_count> middle{};
    bool any = false;

    void allow(int h, int a, int c) {
        ends[h][a] |= std::uint32_t{1} << c;
        ends[h][c] |= std::uint32_t{1} << a;
        middle[h] = any = true;
    }
};

struct OpeningKey {
    Node node;
    Key key;
    int outer;
    int phase;
    int center_totient;
};

class Geometry {
    struct KeyNode {
        Node node;
        std::array<PackedKey, 4> keys;
        std::uint8_t count = 0;
        int radius;
    };
    static constexpr int indexed_cells = 1024;
    static constexpr std::uint64_t indexed_key_positions = 4'000'000;

    using KeyBits = std::uint64_t;
    static constexpr std::size_t bits_per_word = 64;
    static constexpr auto center_mod_masks = [] {
        std::array<KeyBits, limit> masks{};
        for (int remainder = 0; remainder < limit; ++remainder)
            for (std::size_t bit = 0; bit < bits_per_word; ++bit)
                if ((remainder + 2 * bit) % limit == 0) masks[remainder] |= KeyBits{1} << bit;
        return masks;
    }();

    class CenterIndex {
        std::vector<Cell> sparse_;
        std::vector<KeyBits> columns_;
        std::array<Cell, 16> probes_{};
        std::size_t probe_count_ = 0;
        std::size_t words_per_row_ = 0;
        Cell first_ = 0;
        int width_ = 0;
        bool populated_ = false;

    public:
        void reset(int height, int width, int row_parity, int col_parity, bool compact) {
            populated_ = false;
            probe_count_ = 0;
            sparse_.clear();
            width_ = width;
            first_ = (1 - row_parity) * width + 1 - col_parity;
            auto row_count = static_cast<std::size_t>((height + row_parity) / 2);
            auto col_count = static_cast<std::size_t>((width + col_parity) / 2);
            words_per_row_ = (col_count + bits_per_word - 1) / bits_per_word;
            columns_.assign(compact ? row_count * words_per_row_ : 0, 0);
        }

        void push(Cell center, Point p) {
            populated_ = true;
            if (columns_.empty()) {
                sparse_.push_back(center);
                return;
            }
            auto col = static_cast<std::size_t>(p.col - 1) / 2;
            auto row = static_cast<std::size_t>(p.row - 1) / 2;
            columns_[row * words_per_row_ + col / bits_per_word] |= KeyBits{1} << (col % bits_per_word);
        }

        bool empty() const { return !populated_; }
        bool has_bitmap() const { return !columns_.empty(); }

        void build_probes() {
            if (!populated_) return;
            if (columns_.empty()) {
                if (sparse_.size() < probes_.size() * 2) return;
                for (std::size_t i = 0; i < probes_.size(); ++i)
                    probes_[probe_count_++] = sparse_[(i + 1) * sparse_.size() / (probes_.size() + 1)];
                return;
            }
            auto rows = columns_.size() / words_per_row_;
            if (rows < 8 || width_ < 32) return;
            for (std::size_t r = 1; r <= 4; ++r) {
                auto row = r * rows / 5;
                for (std::size_t c = 1; c <= 4; ++c) {
                    auto column = c * static_cast<std::size_t>(width_) / 10;
                    auto word = column / bits_per_word;
                    auto bits = columns_[row * words_per_row_ + word];
                    if (!bits) continue;
                    auto at_or_after = bits & (~KeyBits{0} << (column % bits_per_word));
                    auto bit = at_or_after ? std::countr_zero(at_or_after) : 63 - std::countl_zero(bits);
                    probes_[probe_count_++] = first_ + static_cast<Cell>(2 * (row * width_ + word * bits_per_word + bit));
                }
            }
        }

        template<class Visit>
        bool probe(Visit&& visit) const {
            for (std::size_t i = 0; i < probe_count_; ++i)
                if (visit(probes_[i])) return true;
            return false;
        }

        template<class Visit, class Mask>
        bool each(Visit&& visit, Mask&& mask) const {
            for (Cell center : sparse_) if (visit(center)) return true;
            Cell row_start = first_;
            for (std::size_t row = 0; row < columns_.size(); row += words_per_row_, row_start += 2 * width_) {
                for (std::size_t word = 0; word < words_per_row_; ++word) {
                    auto bits = columns_[row + word];
                    if (!bits) continue;
                    auto base = row_start + static_cast<Cell>(2 * bits_per_word * word);
                    bits &= mask(base, word);
                    while (bits) {
                        auto center = base + 2 * std::countr_zero(bits);
                        bits &= bits - 1;
                        if (visit(center)) return true;
                    }
                }
            }
            return false;
        }

        template<class Visit>
        bool each(Visit&& visit) const {
            return each(visit, [](Cell, std::size_t) { return ~KeyBits{0}; });
        }
    };

    struct CellKeyMasks {
        KeyBits start = 0;       // Rule 20 and the first squarefree GCD in rule 10.
        KeyBits left = 0;        // Rule 10 using the leftmost cell.
        KeyBits end = 0;         // Both rule 10 tests using the end cell.
        KeyBits divisible = 0;   // Rule 26 distance divisible by seven.
        KeyBits column_xor = 0;  // Rule 17 using the current 270-degree address.
    };

    struct KeyMaskWord {
        std::vector<CellKeyMasks> cells;
        std::array<KeyBits, limit> center_mod{};
        std::array<KeyBits, limit> max_radius{};
        KeyBits extreme = 0;     // Rule 23.
    };

    struct Segment {
        Span cells;
        Cell end, left;
        std::uint8_t signs;
        std::uint8_t center_remainder;
    };

    struct SegmentStart {
        Cell start;
        std::size_t begin, end;
    };

    struct SegmentGroup {
        std::vector<Segment> segments;
        std::vector<SegmentStart> starts;
        std::vector<int> start_index;
        std::vector<KeyBits> available;
    };

    // Only [0,1] are allowed for the common outer sign. The middle sign is [-1,1].
    static int key_group(int axis, int radius, int row, int col, bool mirror, int outer, int middle) {
        return (((((axis * 2 + radius) * 2 + row) * 2 + col) * 2 + mirror) * 2 + outer) * 3 + middle + 1;
    }

    static int segment_group(int axis, bool left_first, int end_row, int left_row, int left_col) {
        return (((axis * 2 + left_first) * 2 + end_row) * 2 + left_row) * 2 + left_col;
    }

    static constexpr std::array<Point, 8> directions{{
        {0, 1}, {1, 1}, {1, 0}, {1, -1}, {0, -1}, {-1, -1}, {-1, 0}, {-1, 1}
    }};

    static constexpr std::array<std::array<Point, 2>, 6> segment_directions{{
        {{{0, -1}, {0, 0}}}, {{{0, 1}, {0, 0}}},
        {{{1, 0}, {0, 0}}}, {{{-1, 0}, {0, 0}}},
        {{{1, -1}, {-1, -1}}}, {{{1, 1}, {-1, 1}}}
    }};

    struct Layout {
        int height, width;
        bool full_search;
        std::unique_ptr<std::uint8_t[]> quarter_signs;
        std::vector<std::uint8_t> mu;
        std::vector<int> small_primes;
        std::array<int, rune_count> phi;
        std::array<std::int8_t, rune_count> rune_sign;
        std::vector<std::uint16_t> gcd;
        std::size_t spatial_words = 0;
        std::vector<KeyBits> rays, nearby, reflected, to_right;
        std::array<SegmentGroup, 48> segments;
        std::vector<std::uint8_t> address_flags;
        std::once_flag transitions_initialized, address_flags_initialized;

        Layout(int h, int w, bool full)
            : height(h), width(w), full_search(full),
              quarter_signs(std::make_unique_for_overwrite<std::uint8_t[]>((h * w + 3) / 4)) {}
    };

public:
    class LayoutCache {
        friend class Geometry;
        std::shared_ptr<Layout> latest_;
    };

private:
    int height_, width_, size_;
    int width_shift_;
    std::uint64_t width_multiplier_;
    std::vector<Rune> runes_;
    std::shared_ptr<Layout> layout_;
    mutable std::array<std::vector<KeyNode>, 384> keys_;
    mutable std::array<std::vector<KeyMaskWord>, 384> key_mask_words_;
    mutable std::array<CenterIndex, 12> key_centers_;
    mutable std::once_flag keys_initialized_;
    mutable bool stream_keys_ = false;

    bool contains(Point p) const {
        return p.row >= 1 && p.row <= height_ && p.col >= 1 && p.col <= width_;
    }

    Cell index(Point p) const { return (p.row - 1) * width_ + p.col - 1; }

    static int sign_at(std::uint8_t packed, int shift) { return ((packed >> shift) & 3) - 1; }

    static int coordinate_shift(unsigned width) {
        return std::has_single_bit(width) ? std::countr_zero(width) : 31 + std::bit_width(width);
    }

    static std::uint64_t coordinate_multiplier(unsigned width, int shift) {
        if (std::has_single_bit(width)) return 0;
        return ((std::uint64_t{1} << shift) - 1) / width + 1;
    }

    void build_arithmetic(const Workers& workers) {
        // Address sums, address XORs and the three rune primes use this sieve.
        // Totients are needed only for rune values and small heading rows.
        int maximum = std::max(3 * primes.back(), size_ * 2);
        auto& totient = layout_->phi;
        std::iota(totient.begin(), totient.end(), 0);
        int prime_limit = std::max(rune_count - 1, static_cast<int>(std::sqrt(maximum)));
        std::vector<bool> composite(prime_limit + 1);
        auto& small_primes = layout_->small_primes;
        for (int p = 2; p <= prime_limit; ++p) {
            if (composite[p]) continue;
            small_primes.push_back(p);
            for (int n = p * p; n <= prime_limit; n += p) composite[n] = true;
            for (int n = p; n < rune_count; n += p) totient[n] -= totient[n] / p;
        }
        auto& packed = layout_->mu;
        packed.resize((static_cast<std::size_t>(maximum) + 4) / 4);
        auto count = packed.size() * 4;
        constexpr std::size_t segment_size = 16384;
        std::vector<std::vector<int>> scratch(workers.count());
        workers.run((count + segment_size - 1) / segment_size, 1, [&](std::size_t segment, std::size_t worker) {
            auto first = segment * segment_size;
            auto end = std::min(first + segment_size, count);
            auto& products = scratch[worker];
            products.assign(end - first, 1);
            for (int p : small_primes) {
                for (auto n = (first + p - 1) / p * p; n < end; n += p) products[n - first] *= -p;
                auto square = static_cast<std::size_t>(p) * p;
                for (auto n = (first + square - 1) / square * square; n < end; n += square)
                    products[n - first] = 0;
            }
            // A square-free value can have at most one extra prime above
            // the sieve limit. Compare with its signed product to account for it.
            auto encode = [&](std::size_t i) {
                int product = products[i];
                if (!product) return 1;
                int value = static_cast<int>(first + i);
                bool extra_prime = product != value && product != -value;
                return ((product < 0) != extra_prime) ? 0 : 2;
            };
            for (std::size_t i = 0; i < products.size(); i += 4) {
                packed[(first + i) / 4] = static_cast<std::uint8_t>(encode(i) | (encode(i + 1) << 2) |
                                                                   (encode(i + 2) << 4) | (encode(i + 3) << 6));
            }
        });
        for (int i = 0; i < rune_count; ++i) layout_->rune_sign[i] = static_cast<std::int8_t>(mu(totient[i]));
    }

    static Key align(Key key, int phase) {
        return {key[phase], key[(phase + 1) % 3], key[(phase + 2) % 3]};
    }

    Key signature(const Key& key) const {
        return {layout_->rune_sign[key[0]], layout_->rune_sign[key[1]], layout_->rune_sign[key[2]]};
    }

    int axis_radius(Point center, int dr, int dc) const {
        int radius = std::max(height_, width_);
        if (dr) radius = std::min({radius, center.row - 1, height_ - center.row});
        if (dc) radius = std::min({radius, center.col - 1, width_ - center.col});
        return radius;
    }

    static int center_group(int row_parity, int col_parity, int middle_sign) {
        return (2 * row_parity + col_parity) * 3 + middle_sign + 1;
    }

    bool needs_streamed_keys() const {
        if (size_ <= indexed_cells) return false;
        std::uint64_t positions = 0;
        for (Cell center = 0; center < size_; ++center) {
            if (!runes_[center]) continue;
            Point p = point(center);
            for (int axis = 0; axis < 4; ++axis) {
                auto [dr, dc] = directions[axis];
                positions += axis_radius(p, dr, dc);
            }
            if (positions > indexed_key_positions) return true;
        }
        return false;
    }

    void index_key_centers() const {
        auto occupied = std::count_if(runes_.begin(), runes_.end(), [](Rune rune) { return rune != 0; });
        auto width = static_cast<std::size_t>(width_);
        auto even_words = (width / 2 + bits_per_word - 1) / bits_per_word;
        auto odd_words = ((width + 1) / 2 + bits_per_word - 1) / bits_per_word;
        // Each occupied cell is in at least one group. Compare its minimum
        // list cost with the bitmap footprint, including per-row padding.
        bool compact = 3 * std::size_t(height_) * (even_words + odd_words) * sizeof(KeyBits)
                            <= static_cast<std::size_t>(occupied) * sizeof(Cell);
        for (int row : {0, 1}) for (int col : {0, 1}) for (int sign : {-1, 0, 1})
            key_centers_[center_group(row, col, sign)].reset(height_, width_, row, col, compact);
        for (Cell center = 0; center < size_; ++center) {
            int h = runes_[center];
            if (!h) continue;
            auto p = point(center);
            int sign = layout_->rune_sign[h], other = layout_->rune_sign[phi(h)];
            key_centers_[center_group(p.row & 1, p.col & 1, sign)].push(center, p);
            if (other != sign)
                key_centers_[center_group(p.row & 1, p.col & 1, other)].push(center, p);
        }
        for (auto& group : key_centers_) group.build_probes();
    }

    KeyNode make_streamed_key(Node node, int radius, int a, int h, int c, int phase, int middle_sign) const {
        KeyNode result{node, {}, 0, radius};
        int transformed = phi(h);
        for (int b : {h, transformed}) {
            if (layout_->rune_sign[b] == middle_sign) {
                result.keys[result.count++] = pack_key(align({a, b, c}, phase));
                if (a != c) result.keys[result.count++] = pack_key(align({c, b, a}, phase));
            }
            if (b == transformed) break;
        }
        for (int i = 1; i < result.count; ++i)
            for (int j = i; j > 0 && result.keys[j] < result.keys[j - 1]; --j)
                std::swap(result.keys[j], result.keys[j - 1]);
        return result;
    }

    void build_keys() const {
        for (Cell middle = 0; middle < size_; ++middle) {
            if (runes_[middle] == 0) continue;
            Point p = point(middle);
            for (int axis = 0; axis < 4; ++axis) {
                auto [dr, dc] = directions[axis];
                for (int radius = 1;; ++radius) {
                    Point u{p.row - radius * dr, p.col - radius * dc};
                    Point z{p.row + radius * dr, p.col + radius * dc};
                    if (!contains(u) || !contains(z)) break;
                    Node node{index(u), middle, index(z)};
                    int a = runes_[node[0]], h = runes_[middle], c = runes_[node[2]];
                    if (a == 0 || c == 0) continue;
                    auto outer_sign = signature({a, h, c});
                    if (outer_sign[0] != outer_sign[2] || outer_sign[0] < 0) continue;
                    for (int b : {h, layout_->phi[h]}) {
                        int middle_sign = mu(layout_->phi[b]);
                        int phase = mod3(2 * outer_sign[0] + middle_sign);
                        auto& group = keys_[key_group(axis, radius & 1, p.row & 1, p.col & 1,
                                                      a == c, outer_sign[0], middle_sign)];
                        if (group.empty() || group.back().node != node)
                            group.push_back({node, {}, 0, radius});
                        auto& entry = group.back();
                        for (PackedKey aligned : {pack_key(align({a, b, c}, phase)),
                                                  pack_key(align({c, b, a}, phase))}) {
                            if (std::find(entry.keys.begin(), entry.keys.begin() + entry.count, aligned)
                                == entry.keys.begin() + entry.count)
                                entry.keys[entry.count++] = aligned;
                        }
                        for (int i = 1; i < entry.count; ++i) {
                            for (int j = i; j > 0 && entry.keys[j] < entry.keys[j - 1]; --j)
                                std::swap(entry.keys[j], entry.keys[j - 1]);
                        }
                        if (b == layout_->phi[h]) break; // h == phi(h) is possible only for 1.
                    }
                }
            }
        }
    }

    Segment make_segment(Cell start, int stride, int span, Cell end, Cell left) const {
        int negative = mu(end + 1) < 0;
        int quarter = quarter_sign(left);
        auto signs = static_cast<std::uint8_t>(((quarter >= 0) << negative) |
                                               ((quarter <= 0) << (negative + 2)));
        auto remainder = static_cast<std::uint8_t>((limit - rotations(left)[2] % limit) % limit);
        return {{start, stride, span + 1}, end, left, signs, remainder};
    }

    void build_segments() const {
        for (Cell start = 0; start < size_; ++start) {
            auto [row, col] = point(start);
            for (auto [dr, dc] : directions) {
                int axis = dr == 0 ? 0 : dc == 0 ? 1 : 2;
                int stride = width_ * dr + dc;
                for (int span = 1;; ++span) {
                    Point end{row + span * dr, col + span * dc};
                    if (!contains(end)) break;
                    Cell last = index(end), left = leftmost(start, last);
                    Point l = point(left);
                    auto& group = layout_->segments[segment_group(axis, start == left, end.row & 1,
                                                          l.row & 1, l.col & 1)];
                    if (group.starts.empty() || group.starts.back().start != start)
                        group.starts.push_back({start, group.segments.size(), 0});
                    group.segments.push_back(make_segment(start, stride, span, last, left));
                    group.starts.back().end = group.segments.size();
                }
            }
        }
    }

    void build_lookup_tables() const {
        // These quadratic tables are useful on small maps with many openings.
        // Larger maps use the same arithmetic directly, with bounded memory.
        if (size_ > indexed_cells) return;
        auto stride = size_ + 1;
        layout_->gcd.resize(stride * stride);
        for (int a = 1; a <= size_; ++a) {
            layout_->gcd[a * stride] = a;
            for (int b = 1; b <= a; ++b) {
                auto gcd = layout_->gcd[b * stride + a % b];
                layout_->gcd[a * stride + b] = layout_->gcd[b * stride + a] = gcd;
            }
        }
        layout_->spatial_words = (size_ + bits_per_word - 1) / bits_per_word;
        layout_->rays.resize(4 * size_ * layout_->spatial_words);
        layout_->nearby.resize(size_ * layout_->spatial_words);
        layout_->reflected.resize(size_ * layout_->spatial_words);
        layout_->to_right.resize(width_ * layout_->spatial_words);
        for (Cell origin = 0; origin < size_; ++origin) {
            Point anchor = point(origin);
            for (Cell start = 0; start < size_; ++start) {
                Point target = point(start);
                auto word = std::size_t(start) / bits_per_word;
                auto bit = KeyBits{1} << (start % bits_per_word);
                int offset = ray_offset(anchor, target);
                bool near = distance(anchor, target) <= limit;
                if (offset <= 1) layout_->rays[(4 * origin + 2 * offset + near) * layout_->spatial_words + word] |= bit;
                if (near) layout_->nearby[origin * layout_->spatial_words + word] |= bit;
                if (std::abs(target.col - anchor.col) <= std::abs(target.row - anchor.row) + limit)
                    layout_->reflected[origin * layout_->spatial_words + word] |= bit;
                if (anchor.row == 1 && target.col > anchor.col)
                    layout_->to_right[(anchor.col - 1) * layout_->spatial_words + word] |= bit;
            }
        }
        for (auto& group : layout_->segments) {
            group.start_index.assign(size_, -1);
            group.available.resize(layout_->spatial_words);
            for (std::size_t i = 0; i < group.starts.size(); ++i) {
                Cell start = group.starts[i].start;
                group.start_index[start] = static_cast<int>(i);
                group.available[start / bits_per_word] |= KeyBits{1} << (start % bits_per_word);
            }
        }
    }

    int gcd(int a, int b) const {
        if (layout_->gcd.empty()) return std::gcd(a, b);
        return layout_->gcd[a * (size_ + 1) + b];
    }

    bool squarefree_common(int a, int b) const {
        // A square dividing the GCD must divide both addresses.
        return mu(a) != 0 || mu(b) != 0 || mu(gcd(a, b)) != 0;
    }

    static constexpr int start_flag = 1, left_flag = 2, end_flag = 4, divisible_flag = 8;

    void build_address_flags(const Workers& workers) const {
        auto& combinations = layout_->address_flags;
        combinations.resize(size_ * size_);
        workers.run(size_, 16, [&](std::size_t center, std::size_t) {
            const auto& m = rotations(center);
            auto* flags = combinations.data() + center * size_;
            for (Cell cell = 0; cell < size_; ++cell) {
                const auto& a = rotations(cell);
                int common = gcd(m[0], a[0]);
                flags[cell] = (common <= limit && gcd(m[2], a[0]) <= limit && mu(common) != 0 ? start_flag : 0)
                    | (mu(common) != 0 ? left_flag : 0)
                    | (mu(gcd(m[1], a[3])) != 0 && mu(gcd(m[0], a[2])) != 0 ? end_flag : 0)
                    | (distance(point(static_cast<Cell>(center)), point(cell)) % limit == 0 ? divisible_flag : 0);
            }
        });
    }

    void build_key_masks(const Workers& workers) const {
        std::call_once(layout_->address_flags_initialized, [&] { build_address_flags(workers); });
        const auto& combinations = layout_->address_flags;
        workers.run(keys_.size(), 4, [&](std::size_t group, std::size_t) {
            const auto& keys = keys_[group];
            auto& words = key_mask_words_[group];
            words.resize((keys.size() + bits_per_word - 1) / bits_per_word);
            for (std::size_t j = 0; j < words.size(); ++j) {
                auto& word = words[j];
                word.cells.resize(size_);
                const auto stop = std::min(keys.size(), (j + 1) * bits_per_word);
                for (std::size_t i = j * bits_per_word; i < stop;) {
                    Cell center = keys[i].node[1];
                    KeyBits center_bits = 0;
                    // Consecutive nodes with one center share all cell masks.
                    do {
                        const auto& key = keys[i];
                        KeyBits bit = KeyBits{1} << (i % bits_per_word);
                        center_bits |= bit;
                        if (mu(size_ - key.node[0]) > 0) word.extreme |= bit;
                        for (int radius = key.radius; radius < limit; ++radius) word.max_radius[radius] |= bit;
                        ++i;
                    } while (i < stop && keys[i].node[1] == center);
                    int column = point(center).col;
                    const auto* flags = combinations.data() + center * size_;
                    for (Cell c = 0; c < size_; ++c) {
                        auto& masks = word.cells[c];
                        const auto mode = flags[c];
                        // These boolean masks compile to conditional moves or
                        // vector operations without branching on the address.
                        masks.start |= (mode & start_flag) ? center_bits : 0;
                        masks.left |= (mode & left_flag) ? center_bits : 0;
                        masks.end |= (mode & end_flag) ? center_bits : 0;
                        masks.divisible |= (mode & divisible_flag) ? center_bits : 0;
                        masks.column_xor |= mu((c + 1) ^ column) <= 0 ? center_bits : 0;
                    }
                    word.center_mod[rotations(center)[0] % limit] |= center_bits;
                }
            }
        });
    }

public:
    Geometry(Matrix matrix, bool full_search, const Workers& workers, LayoutCache& cache)
        : height_(matrix.height), width_(matrix.width), size_(static_cast<int>(matrix.runes.size())),
          width_shift_(coordinate_shift(static_cast<unsigned>(width_))),
          width_multiplier_(coordinate_multiplier(static_cast<unsigned>(width_), width_shift_)),
          runes_(std::move(matrix.runes)), layout_(cache.latest_) {
        if (!layout_ || layout_->height != height_ || layout_->width != width_ ||
            layout_->full_search != full_search) {
            layout_ = std::make_shared<Layout>(height_, width_, full_search);
            build_arithmetic(workers);
            auto set_quarter_signs = [&](std::size_t group, std::size_t) {
                auto start = static_cast<Cell>(4 * group);
                unsigned packed = 0;
                for (int i = 0; i < 4 && start + i < size_; ++i) {
                    auto [row, col] = point(start + i);
                    int quarter = height_ * col + 1 - row;
                    packed |= static_cast<unsigned>(mu(quarter) + 1) << (2 * i);
                }
                layout_->quarter_signs[group] = static_cast<std::uint8_t>(packed);
            };
            workers.run((static_cast<std::size_t>(size_) + 3) / 4, 1024, set_quarter_signs);
            cache.latest_ = layout_;
        }
    }

    void prepare_transitions(const Workers& workers) const {
        if (size_ <= indexed_cells) {
            std::call_once(layout_->transitions_initialized, [&] {
                for (auto& group : layout_->segments) group = {};
                build_segments();
                if (layout_->full_search) build_lookup_tables();
            });
        }
        std::call_once(keys_initialized_, [&] {
            stream_keys_ = needs_streamed_keys();
            if (stream_keys_) {
                index_key_centers();
            } else {
                for (auto& group : keys_) group.clear();
                build_keys();
                if (!layout_->gcd.empty() && std::any_of(keys_.begin(), keys_.end(), [](const auto& group) {
                    return !group.empty();
                })) build_key_masks(workers);
            }
        });
    }

    int size() const { return size_; }
    int height() const { return height_; }
    bool streams_keys() const { return stream_keys_; }
    Rune rune(Cell c) const { return runes_[c]; }
    const std::vector<Rune>& runes() const { return runes_; }
    std::array<int, 4> rotations(Cell c) const {
        auto [row, col] = point(c);
        int quarter = height_ * col - row + 1;
        return {c + 1, quarter, size_ - c, size_ + 1 - quarter};
    }

    Point point(Cell c) const {
        if (!width_multiplier_) return {(c >> width_shift_) + 1, (c & (width_ - 1)) + 1};
        // The input bounds cell IDs below 2^30. The rounded reciprocal's
        // quotient error is less than 1 / width throughout that range.
        auto row = static_cast<int>((static_cast<std::uint64_t>(c) * width_multiplier_) >> width_shift_);
        return {row + 1, c - row * width_ + 1};
    }
    int mu(int n) const {
        auto index = static_cast<unsigned>(n);
        return sign_at(layout_->mu[index >> 2], 2 * (index & 3));
    }
    int phi(int n) const { return layout_->phi[n]; }
    int quarter_sign(Cell c) const {
        auto index = static_cast<unsigned>(c);
        return sign_at(layout_->quarter_signs[index >> 2], 2 * (index & 3));
    }

    Cell leftmost(Cell a, Cell b) const {
        Point p = point(a), q = point(b);
        return p.col < q.col || (p.col == q.col && p.row > q.row) ? a : b;
    }

    Cell leftmost(Span block) const {
        Cell a = block.start, b = block.end();
        // A row-major block that wraps includes column 1, deepest on its last row.
        if (block.stride == 1 && point(a).row != point(b).row)
            return b - (point(b).col - 1);
        return leftmost(a, b);
    }

    void decrypt(Span cells, const Key& key, char* code) const {
        std::int64_t c = cells.start;
        int i = 0;
        for (; cells.length - i >= 3; i += 3, c += 3LL * cells.stride) {
            code[i] = static_cast<char>(mod29(runes_[c] - key[0]));
            code[i + 1] = static_cast<char>(mod29(runes_[c + cells.stride] - key[1]));
            code[i + 2] = static_cast<char>(mod29(runes_[c + 2 * cells.stride] - key[2]));
        }
        for (int tail = 0; i < cells.length; ++i, ++tail, c += cells.stride)
            code[i] = static_cast<char>(mod29(runes_[c] - key[tail]));
    }

    std::string decrypt(Span cells, const Key& key) const {
        std::string code(cells.length, '\0');
        decrypt(cells, key, code.data());
        return code;
    }

    std::optional<OpeningKey> opening_key(Cell middle, Opening mode) const {
        auto [row, col] = point(middle);
        if (col == 1 || col == width_) return {};
        if (mode == Opening::heading &&
            (row - col != 1 || row + col >= rune_count || col != layout_->phi[row] ||
             runes_[middle - 1] != row + col)) return {};
        Node node{middle - 1, middle, middle + 1};
        int a = runes_[node[0]], h = runes_[middle], c = runes_[node[2]];
        if (std::min({a, h, c}) == 0) return {};
        int center = layout_->phi[h];
        Key key{a, center, c}, sig = signature(key);
        if (sig[0] != sig[2] || sig[0] < 0) return {};
        if (mode != Opening::free && sig != Key{0, 0, 0}) return {};
        int phase = mod3(sig[0] + sig[1] + sig[2]);
        return OpeningKey{node, align(key, phase), sig[0], phase, center};
    }

    std::vector<OpeningKey> opening_keys(Opening mode) const {
        std::vector<OpeningKey> result;
        if (mode == Opening::heading) {
            // The heading rule requires col = row - 1 and row + col <= 28.
            for (int row = 3; row <= std::min(height_, rune_count / 2) && row - 1 < width_; ++row)
                if (auto key = opening_key(index({row, row - 1}), mode)) result.push_back(*key);
        } else {
            for (Cell middle = 0; middle < size_; ++middle)
                if (auto key = opening_key(middle, mode)) result.push_back(*key);
        }
        return result;
    }

    std::pair<Phase, int> next_phase(const State& s, Cell l) const {
        int mode = (s.total / limit) & 3;
        bool half_turn = mode == 1 || mode == 2;
        int sum = mode == 0 || mode == 2;
        int quarter_sum = 0;
        Cell c = s.cells.start;
        for (int i = 0; i < s.cells.length; ++i, c += s.cells.stride) {
            sum += mu(half_turn ? size_ - c : c + 1);
            quarter_sum += quarter_sign(c);
        }
        int phase = mod3(sum);
        return {{s.total + phase, (s.outer + quarter_sign(l) + 2) & 1, phase}, quarter_sum};
    }

    // Return whether at least one geometric successor existed through rule 25.
    // The visitor can stop enumeration early when only terminal status is needed.
    template<class RayLimit, class PrepareSegment, class Visit>
    bool through25(const State& s, Cell left, int quarter_sum, Phase next, bool final_divisible,
                   bool collect, bool terminal_only, const StartRows* rows, const std::atomic<bool>* continuation,
                   RayLimit&& limit_ray,
                   PrepareSegment&& prepare_segment, Visit&& visit) const {
        if (next.phase == 2 && s.total % limit == 6) return false;
        auto [u, m, z] = s.node.cells();
        Cell b = s.cells.start, e = s.cells.end(), l = left;
        const auto& U = rotations(u);
        const auto& M = rotations(m);
        const auto& Z = rotations(z);
        const auto& B = rotations(b);
        const auto& E = rotations(e);
        const auto& L = rotations(l);
        auto [br, bc] = point(b);
        auto [mr, mc] = point(m);
        auto [ur, uc] = point(u);
        auto [er, ec] = point(e);

        // 04, 07, 13, 14: predict the next key's group.
        bool group_bit = (mu(M[1] + Z[2]) < 0) == (mu(L[1] + Z[2]) < 0);
        int gp = primes[runes_[u]] + primes[runes_[m]] + primes[runes_[z]];
        bool diagonal = (mu(gcd(M[1], Z[3])) < 0) ^ (mu(gp) > 0) ^ (mu(M[0] + Z[3]) != 0);
        int axis = 2 * group_bit + diagonal;
        int radius = ((mr + mc + br + bc) & 1) ^ (mu(gcd(Z[2], L[2])) < 0) ^ (mu(B[1] + E[1]) > 0);
        int first_radius = radius ? 1 : 2;
        auto [key_dr, key_dc] = directions[axis];
        if ((key_dr && height_ <= 2 * first_radius) || (key_dc && width_ <= 2 * first_radius)) return false;
        int row = (1 + bc + er + mr + mu(B[2])) & 1;
        int col = (1 + br + er + mr) & 1;
        bool mirror = distance(point(z), point(l)) % 3 != 2;
        int middle_sign = mod3(next.phase - 2 * next.outer + 1) - 1;
        int group = key_group(axis, radius, row, col, mirror, next.outer, middle_sign);
        const auto& key_nodes = keys_[group];
        const auto& centers = key_centers_[center_group(row, col, middle_sign)];
        if (stream_keys_ ? centers.empty() : key_nodes.empty()) return false;

        // 02, 03, 05, 09: select the indexed group of ciphertext segments.
        int score = mu(B[2] + M[0]) + mu(gcd(E[1], E[2]));
        int segment_axis = score == 0 ? 0 : score > 0 ? 1 : 2;
        int left_first = (mu(E[3]) + layout_->phi[runes_[m]]) & 1;
        int end_row = (1 + s.phase + mu(M[2])) & 1;
        int left_row = (row + 1 + s.phase + mu(mr)) & 1;
        // If the end is leftmost, or the segment is horizontal, both addresses
        // necessarily have the same row parity.
        if ((!left_first || segment_axis == 0) && end_row != left_row) return false;
        constexpr std::array turn{2, 3, 0};
        int left_col = (br + quarter_sum + (runes_[u] == runes_[z]) + mu(M[turn[s.phase]])) & 1;
        const auto& segment_pool = layout_->segments[segment_group(segment_axis, left_first, end_row, left_row, left_col)];
        bool streamed = size_ > indexed_cells;
        if (!streamed && segment_pool.starts.empty()) return false;

        // 17, 23: restrict the actual key nodes in this group.
        bool bounded = distance(point(u), point(e)) <= limit;
        bool extreme_bit = (gcd(B[3], L[1]) % 3 == 0) ^ (mu(M[3] + E[3]) > 0);
        const auto& mask_words = key_mask_words_[group];
        std::array<const KeyNode*, 128> local_keys;
        std::vector<const KeyNode*> extra_keys;
        std::size_t count = 0;
        auto predicted_keys = [&](const KeyMaskWord& word) {
            return word.cells[M[3] - 1].column_xor & (extreme_bit ? word.extreme : ~word.extreme);
        };
        if (!stream_keys_ && mask_words.empty()) {
            for (const auto& key : key_nodes) {
                int x = M[3] ^ point(key.node[1]).col;
                if ((bounded && key.radius >= limit) || mu(x) > 0 ||
                    (mu(size_ - key.node[0]) > 0) != extreme_bit) continue;
                if (count < local_keys.size()) local_keys[count] = &key;
                else extra_keys.push_back(&key);
                ++count;
            }
            if (count == 0) return false;
        } else if (!stream_keys_ && std::none_of(mask_words.begin(), mask_words.end(), predicted_keys)) {
            return false;
        }

        int required_offset = mu(E[0]) == 0 && mu(E[3]) == 0 && (mu(B[0]) != 0 || mu(B[1]) != 0);
        int mode = (next.total / limit) & 3;
        bool reverse_sign = mode == 1 || mode == 2;
        bool vertical = (mu(gcd(M[2], L[3])) < 0) ^ (mu(Z[3] + B[2]) > 0)
                        ^ (mu(gcd(M[3], L[2])) < 0);
        bool negative = (mu(gcd(M[2], L[0])) == 0) ^ (mu(gcd(M[1], B[1])) == 0)
                        ^ (mu(gcd(M[2], E[0])) == 0);
        bool right = (mu(gcd(U[1], E[0])) == 0) ^ (mu(gcd(U[0], B[2])) < 0)
                     ^ bool((E[3] / 4) & 1);
        int start_xor = B[2] ^ rotations(s.previous_start)[2];
        bool near = (start_xor % limit == 0) == (mu(U[0] + E[0]) < 0);
        int reflected_col = width_ + 1 - point(z).col, reflected_row = height_ + 1 - br;
        bool mod_seven = (mu(U[2] ^ M[3]) < 0) ^ (mu(gcd(B[0], B[3])) == 0);
        // A partition is used only after the complete state has a geometric witness.
        bool found = rows != nullptr;
        bool check_words = collect || (!terminal_only && size_ >= (1 << 20));
        auto stop_after_witness = [&] {
            return found && continuation && continuation->load(std::memory_order_relaxed);
        };

        struct CenterRun {
            Cell center;
            std::size_t first, last;
        };
        struct StartCenter {
            Cell center;
            std::size_t first, last;
            bool passes_26;
        };
        auto candidate = [&](std::size_t i) {
            return i < local_keys.size() ? local_keys[i] : extra_keys[i - local_keys.size()];
        };
        std::vector<CenterRun> center_runs;
        std::vector<StartCenter> start_centers;
        std::vector<Cell> local_centers;
        const std::vector<Cell>* stream_centers = nullptr;
        std::vector<Cell> stream_start_centers;
        bool stream_centers_pass_26 = false;
        Cell last_stream_start = -1;
        Cell last_start = -1;
        int min_center_col = width_ + 1, max_center_col = 0;
        std::array<KeyBits, bits_per_word> column_words;
        KeyBits prepared_columns = 0;
        bool filter_columns = width_ <= 2 * static_cast<int>(bits_per_word * column_words.size());
        std::optional<StartAddressFilter> terminal_addresses;
        Cell checked_start = -1;
        unsigned address_checks = 0;

        unsigned segment_sign = 1u << (negative + 2 * reverse_sign);
        const auto* single_word = mask_words.size() == 1 ? &mask_words[0] : nullptr;
        KeyBits single_predicted = single_word ? predicted_keys(*single_word) : 0;
        auto visit_segment = [&](const Segment& seg, Point start_point, KeyBits single_start) {
            if (stop_after_witness()) return true;
            if (!(seg.signs & segment_sign)) return false;
            int radius_limit = limit - seg.cells.length + 1;
            if (bounded && radius_limit < first_radius) return false; // 21
            auto [end_r, end_c] = point(seg.end);
            if ((std::abs(end_r - ur) >= std::abs(end_c - uc)) != vertical) return false;
            const auto& E2 = rotations(seg.end);
            const auto& L2 = rotations(seg.left);
            int low_col = std::min(start_point.col, end_c);
            int high_col = std::max(start_point.col, end_c);
            bool outside_required = !left_first && seg.cells.length - 1 > 2 * limit;
            auto covered = [&](const Node& node) {
                int center_col = point(node[1]).col;
                if (center_col < low_col - limit || center_col > high_col + limit) return true;
                if (outside_required) return false;
                return std::any_of(node.begin(), node.end(), [&](Cell k) {
                    return distance(point(k), start_point) <= limit &&
                           distance(point(k), point(seg.left)) <= limit;
                }); // 22
            };
            if (!mask_words.empty()) {
                for (std::size_t j = 0; j < mask_words.size(); ++j) {
                    const auto& word = mask_words[j];
                    const auto& start = word.cells[seg.cells.start];
                    KeyBits candidates = (single_word ? single_start : predicted_keys(word) & start.start)
                        & word.cells[seg.left].left & word.cells[seg.end].end;
                    KeyBits matching_mod = word.center_mod[seg.center_remainder];
                    candidates &= mod_seven ? matching_mod : ~matching_mod; // 24
                    if (bounded) candidates &= word.max_radius[radius_limit];
                    KeyBits final_keys = final_divisible ? start.divisible : ~start.divisible;
                    if (found) candidates &= final_keys;
                    while (candidates) {
                        auto index = std::countr_zero(candidates);
                        candidates &= candidates - 1;
                        const auto& key = key_nodes[j * bits_per_word + index];
                        if (!covered(key.node)) continue;
                        if (!found) {
                            found = true;
                            if (visit(key.node, seg.cells, key.keys, key.count)) return true;
                            // Once the state is known to have a geometric continuation,
                            // further candidates failing rule 26 cannot affect the result.
                            candidates &= final_keys;
                        } else if (visit(key.node, seg.cells, key.keys, key.count)) return true;
                    }
                }
                return false;
            }
            int start_address = seg.cells.start + 1;
            auto fits_start = [&](Cell center) {
                const auto& M2 = rotations(center);
                int common = gcd(M2[0], start_address);
                return common <= limit && mu(common) != 0 && gcd(M2[2], start_address) <= limit; // 20 and 10
            };
            auto center_mod_matches = [&](Cell center) {
                return (((center + 1 + L2[2]) % limit == 0) == mod_seven); // 24
            };
            auto fits_rest = [&](Cell center, bool check_mod = true) {
                const auto& M2 = rotations(center);
                return (!check_mod || center_mod_matches(center)) &&
                    (left_first || squarefree_common(M2[0], L2[0])) &&
                    squarefree_common(M2[1], E2[3]) && squarefree_common(M2[0], E2[2]); // 10
            };
            if (stream_keys_) {
                const auto* lexical = found && check_words
                    ? prepare_segment(seg.cells, next.outer, middle_sign, mirror) : nullptr;
                if (lexical && !lexical->any) return false;
                bool reuse_centers = collect || (found && check_words);
                bool skip_segment = false;
                if (terminal_only && checked_start != seg.cells.start) {
                    terminal_addresses.reset();
                    checked_start = seg.cells.start;
                    address_checks = 0;
                }
                auto matches_start = [&](Cell center) {
                    if (terminal_only && !terminal_addresses && ++address_checks == 24)
                        terminal_addresses.emplace(start_address, layout_->small_primes);
                    return terminal_addresses ? terminal_addresses->allows(center + 1, size_ - center) : fits_start(center);
                };
                // Rules that depend only on the center can discard all of its
                // radii at once. Visit the remaining nodes in index order.
                auto [dr, dc] = directions[axis];
                int stride = width_ * dr + dc;
                auto passes_rule_26 = [&](Point p) {
                    return (distance(p, start_point) % limit == 0) == final_divisible;
                };
                if (reuse_centers && last_stream_start != seg.cells.start) {
                    // The column XOR and start address tests stay fixed across spans.
                    if (!stream_centers) {
                        auto fill_centers = [&](std::vector<Cell>& eligible) {
                            centers.each([&](Cell center) {
                                Point p = point(center);
                                if (mu(M[3] ^ p.col) <= 0 && axis_radius(p, dr, dc) >= first_radius)
                                    eligible.push_back(center);
                                return false;
                            });
                        };
                        if (rows) {
                            auto& shared = *rows->key_centers;
                            std::call_once(shared.ready, [&] { fill_centers(shared.cells); });
                            stream_centers = &shared.cells;
                        } else {
                            fill_centers(local_centers);
                            stream_centers = &local_centers;
                        }
                    }
                    last_stream_start = seg.cells.start;
                    stream_start_centers.clear();
                    stream_centers_pass_26 = found;
                    StartAddressFilter addresses(start_address, layout_->small_primes);
                    for (Cell center : *stream_centers) {
                        if (left_first && (((center + 1 + L2[2]) % limit == 0) != mod_seven)) continue;
                        if (!addresses.allows(center + 1, size_ - center)) continue;
                        if (stream_centers_pass_26 && !passes_rule_26(point(center))) continue;
                        stream_start_centers.push_back(center);
                    }
                }
                auto visit_center = [&](Cell center, bool modulo_known = false, bool column_known = false) {
                    int h = runes_[center];
                    if (lexical && !lexical->middle[h]) return false;
                    Point p = point(center);
                    bool near_span = p.col >= low_col - limit && p.col <= high_col + limit;
                    if (outside_required && near_span) return false;
                    bool passes_26 = terminal_only || (reuse_centers && stream_centers_pass_26) || passes_rule_26(p);
                    if ((found && !passes_26) || (!reuse_centers && !column_known && mu(M[3] ^ p.col) > 0)) return false;
                    if (!modulo_known && !(reuse_centers && left_first) && !center_mod_matches(center)) return false;
                    int max_radius = axis_radius(p, dr, dc);
                    if (bounded) max_radius = std::min(max_radius, radius_limit);
                    SpanInterval radii{first_radius, max_radius};
                    if (!radii.empty() && near_span)
                        radii = covered_radii(p, {dr, dc}, start_point, point(seg.left), radii);
                    if (radii.empty() || (!reuse_centers && !matches_start(center)) || !fits_rest(center, false)) return false;
                    for (int r = radii.first; r <= radii.last; r += 2) {
                        int displacement = r * stride;
                        Node node{center - displacement, center, center + displacement};
                        int a = runes_[node[0]], c = runes_[node[2]];
                        if (lexical) {
                            if (!(lexical->ends[h][a] & (std::uint32_t{1} << c))) continue;
                        } else if (!a || !c || (a == c) != mirror || layout_->rune_sign[a] != next.outer ||
                                   layout_->rune_sign[c] != next.outer) continue;
                        if ((mu(size_ - node[0]) > 0) != extreme_bit) continue; // 23
                        if (terminal_only) return true;
                        auto key = make_streamed_key(node, r, a, h, c, next.phase, middle_sign);
                        bool first_witness = !found;
                        found = true;
                        if (visit(key.node, seg.cells, key.keys, key.count)) return true;
                        if (!collect && check_words && first_witness) {
                            lexical = prepare_segment(seg.cells, next.outer, middle_sign, mirror);
                            if (lexical && !lexical->any) {
                                skip_segment = true;
                                return true;
                            }
                        }
                        if (!passes_26) break;
                    }
                    return false;
                };
                // A terminal check needs only a geometric witness. Interior
                // centers can offer a larger radius, with a full scan as fallback.
                if (terminal_only && centers.probe(visit_center)) return true;
                if (!reuse_centers && centers.has_bitmap()) {
                    auto mask = [&](Cell base, std::size_t word) {
                        auto matches = center_mod_masks[(base + 1 + L2[2]) % limit];
                        KeyBits bits = mod_seven ? matches : ~matches;
                        if (!filter_columns) return bits;
                        auto mark = KeyBits{1} << word;
                        if (!(prepared_columns & mark)) {
                            KeyBits allowed = 0;
                            int col = point(base).col;
                            for (std::size_t bit = 0; bit < bits_per_word && col <= width_; ++bit, col += 2)
                                if (mu(M[3] ^ col) <= 0) allowed |= KeyBits{1} << bit;
                            column_words[word] = allowed;
                            prepared_columns |= mark;
                        }
                        return bits & column_words[word];
                    };
                    return centers.each([&](Cell center) { return visit_center(center, true, filter_columns); }, mask)
                           && !skip_segment;
                }
                if (!reuse_centers) return centers.each(visit_center) && !skip_segment;
                for (Cell center : stream_start_centers) if (visit_center(center)) return true;
                return false;
            }
            if (seg.cells.start != last_start) {
                if (center_runs.empty()) {
                    for (std::size_t j = 0; j < count;) {
                        std::size_t first = j;
                        Cell center = candidate(j)->node[1];
                        do { ++j; } while (j < count && candidate(j)->node[1] == center);
                        center_runs.push_back({center, first, j});
                    }
                }
                last_start = seg.cells.start;
                start_centers.clear();
                min_center_col = width_ + 1;
                max_center_col = 0;
                for (const auto& run : center_runs) {
                    Point p = point(run.center);
                    bool passes_26 = (distance(p, start_point) % limit == 0) == final_divisible;
                    if ((found && !passes_26) || !fits_start(run.center)) continue;
                    if (left_first &&
                        (((rotations(run.center)[0] + L2[2]) % limit == 0) != mod_seven))
                        continue;
                    start_centers.push_back({run.center, run.first, run.last, passes_26});
                    min_center_col = std::min(min_center_col, p.col);
                    max_center_col = std::max(max_center_col, p.col);
                }
            }
            if (!left_first && seg.cells.length - 1 > 2 * limit &&
                min_center_col >= low_col - limit && max_center_col <= high_col + limit) return false;
            for (const auto& run : start_centers) {
                if ((found && !run.passes_26) || !fits_rest(run.center)) continue;
                for (auto i = run.first; i < run.last; ++i) {
                    const auto& key = *candidate(i);
                    if ((bounded && key.radius > radius_limit) || !covered(key.node)) continue;
                    found = true;
                    if (visit(key.node, seg.cells, key.keys, key.count)) return true;
                    if (!run.passes_26) break;
                }
            }
            return false;
        };

        auto visit_start = [&](const SegmentStart& entry) {
            Point start_point = point(entry.start);
            KeyBits single_start = single_word ? single_predicted & single_word->cells[entry.start].start : 0;
            if (single_word && !single_start) return false;
            for (std::size_t i = entry.begin; i < entry.end; ++i)
                if (visit_segment(segment_pool.segments[i], start_point, single_start)) return true;
            return false;
        };

        if (layout_->spatial_words) {
            // Intersect rules 12, 19 and 25 and the directional side in row-major order.
            auto ray = layout_->rays.data() + (4 * l + 2 * required_offset + near) * layout_->spatial_words;
            auto near_start = layout_->nearby.data() + b * layout_->spatial_words;
            auto reflect = layout_->reflected.data() + index({reflected_row, reflected_col}) * layout_->spatial_words;
            auto right_side = layout_->to_right.data() + (bc - 1) * layout_->spatial_words;
            for (std::size_t word = 0; word < layout_->spatial_words; ++word) {
                auto starts = segment_pool.available[word] & ray[word] & reflect[word] &
                    (near ? near_start[word] : ~near_start[word]) &
                    (right ? right_side[word] : ~right_side[word]);
                while (starts) {
                    Cell start = static_cast<Cell>(word * bits_per_word + std::countr_zero(starts));
                    starts &= starts - 1;
                    if (visit_start(segment_pool.starts[segment_pool.start_index[start]])) return true;
                }
            }
        } else if (streamed) {
            auto left_point = point(l);
            Point previous_start{br, bc};
            const auto& rays = segment_directions[2 * segment_axis + left_first];
            int direction_count = segment_axis == 2 ? 2 : 1;
            auto matches_quarter = [&](Cell cell) {
                int quarter = quarter_sign(cell);
                return reverse_sign ? quarter <= 0 : quarter >= 0;
            };
            auto visit_streamed = [&](Point p) {
                if (stop_after_witness()) return true;
                if (!near && (distance(previous_start, p) <= limit || distance(left_point, p) <= limit))
                    return false;
                Cell start = index(p);
                // When the start is leftmost, a quarter-sign mismatch rejects its entire ray.
                if (left_first && !matches_quarter(start)) return false;
                for (int direction = 0; direction < direction_count; ++direction) {
                    auto [dr, dc] = rays[direction];
                    int capacity = std::max(height_, width_);
                    if (dr) capacity = std::min(capacity, dr > 0 ? height_ - p.row : p.row - 1);
                    if (dc) capacity = std::min(capacity, dc > 0 ? width_ - p.col : p.col - 1);
                    if (bounded) capacity = std::min(capacity, limit - first_radius);
                    int first_span = 1, step = 1;
                    auto restrict_parity = [&](int parity, int coordinate, int delta) {
                        int required = parity ^ (coordinate & 1);
                        if (!delta) return required == 0;
                        if (step == 2) return (first_span & 1) == required;
                        first_span = required ? 1 : 2;
                        step = 2;
                        return true;
                    };
                    if (!restrict_parity(end_row, p.row, dr) ||
                        (!left_first && !restrict_parity(left_col, p.col, dc))) continue;
                    int stride = width_ * dr + dc;
                    bool limited = false;
                    auto spans = capacity >= 24
                        ? sector_spans({ur, uc}, p, {dr, dc}, vertical, first_span, capacity)
                        : std::array{SpanInterval{first_span, capacity}, SpanInterval{1, 0}};
                    if (spans[0].empty()) continue;
                    capacity = spans[1].empty() ? spans[0].last : spans[1].last;
                    for (auto interval : spans) {
                        if (interval.empty()) break;
                        if (step == 2 && ((interval.first ^ first_span) & 1)) ++interval.first;
                        for (int span = interval.first; span <= std::min(interval.last, capacity); span += step) {
                            if (found && !limited) {
                                // Geometry has established that the current state is
                                // nonterminal. A dictionary upper bound can now omit
                                // longer spans without affecting terminal counts.
                                capacity = std::min(capacity, limit_ray({start, stride, capacity + 1},
                                                    next.outer, middle_sign, mirror) - 1);
                                limited = true;
                                if (span > capacity) break;
                            }
                            Cell end = start + span * stride;
                            Cell left_cell = left_first ? start : end;
                            if ((mu(end + 1) < 0) != negative ||
                                (!left_first && !matches_quarter(end))) continue;
                            // These packed signs have already been checked.
                            // The remainder is needed only by the indexed key masks.
                            auto remainder = mask_words.empty() ? 0 : (limit - (size_ - left_cell) % limit) % limit;
                            Segment segment{{start, stride, span + 1}, end, left_cell,
                                            static_cast<std::uint8_t>(segment_sign), static_cast<std::uint8_t>(remainder)};
                            if (visit_segment(segment, p, 0)) return true;
                            if (last_stream_start == start && stream_start_centers.empty()) return false;
                            if (last_start == start) {
                                if (start_centers.empty()) return false;
                                if (!left_first && span > 2 * limit &&
                                    min_center_col >= std::min(p.col, p.col + dc * span) - limit &&
                                    max_center_col <= std::max(p.col, p.col + dc * span) + limit) {
                                    capacity = span;
                                    break;
                                }
                            }
                        }
                    }
                }
                return false;
            };

            // A ray offset of 0 or 1 gives a row interval or at most six
            // columns per row. Intersect the ranges before visiting starts.
            int first_row = rows ? rows->first : 1, last_row = rows ? rows->last : height_;
            int min_col = right ? bc + 1 : 1, max_col = right ? width_ : bc;
            if (min_col > max_col) return found;
            int row_parity = left_first ? left_row : segment_axis == 0 ? end_row : -1;
            auto col_parity = [&](int r) {
                if (left_first || segment_axis == 1) return left_col;
                if (segment_axis == 2) return (r ^ end_row ^ left_col) & 1;
                return -1;
            };
            if (near) {
                first_row = std::max({first_row, br - limit, left_point.row - limit});
                last_row = std::min({last_row, br + limit, left_point.row + limit});
            }
            auto visit_wide_row = [&](int r, int first, int last) {
                if (r < first_row || r > last_row || (row_parity >= 0 && (r & 1) != row_parity))
                    return false;
                int reach = std::abs(r - reflected_row) + limit;
                first = std::max({first, min_col, reflected_col - reach});
                last = std::min({last, max_col, reflected_col + reach});
                int parity = col_parity(r);
                if (parity >= 0) first += (first ^ parity) & 1;
                for (int c = first; c <= last; c += parity < 0 ? 1 : 2)
                    if (visit_streamed({r, c})) return true;
                return false;
            };
            if (terminal_only && !near && height_ >= 128) {
                // A terminal check only needs a witness. Visit each straight
                // line of starts over the row intervals that can satisfy 25.
                auto visit_line = [&](int first, int last, int intercept, int slope) {
                    bool even = (row_parity != 1) && (col_parity(0) < 0 || (intercept & 1) == col_parity(0));
                    bool odd = (row_parity != 0) && (col_parity(1) < 0 || ((intercept + slope) & 1) == col_parity(1));
                    if (first > last || (!even && !odd)) return false;
                    SpanInterval line{first, last};
                    line.require_at_least(intercept, slope, min_col);
                    line.require_at_least(-intercept, -slope, -max_col);
                    if (line.empty()) return false;
                    for (int side : {-1, 1}) {
                        auto span = line;
                        if (side < 0) span.last = std::min(span.last, reflected_row);
                        else span.first = std::max(span.first, reflected_row + 1);
                        span.require_at_least(intercept - reflected_col - side * reflected_row, slope + side, -limit);
                        span.require_at_least(reflected_col - intercept - side * reflected_row, side - slope, -limit);
                        int step = even && odd ? 1 : 2;
                        if (step == 2) span.first += (span.first ^ int(odd)) & 1;
                        for (int r = span.first; r <= span.last; r += step)
                            if (visit_streamed({r, intercept + slope * r})) return true;
                    }
                    return false;
                };
                int lrow = left_point.row, lcol = left_point.col;
                if (!required_offset && visit_wide_row(lrow, min_col, max_col)) return true;
                if (required_offset) {
                    for (int r : {lrow - 1, lrow + 1})
                        if (visit_wide_row(r, min_col, lcol - 2) || visit_wide_row(r, lcol + 2, max_col))
                            return true;
                }
                int gap = required_offset + 1;
                for (int shift = -required_offset; shift <= required_offset; shift += 2) {
                    int c = lcol + shift;
                    if (visit_line(first_row, std::min(last_row, lrow - gap), c, 0) ||
                        visit_line(std::max(first_row, lrow + gap), last_row, c, 0)) return true;
                    for (int slope : {-1, 1}) {
                        if (visit_line(first_row, std::min(last_row, lrow - gap), c - slope * lrow, slope) ||
                            visit_line(std::max(first_row, lrow + gap), last_row, c - slope * lrow, slope)) return true;
                    }
                }
                return found;
            }
            int row_step = row_parity < 0 ? 1 : 2;
            if (row_step == 2) first_row += (first_row ^ row_parity) & 1;
            for (int r = first_row; r <= last_row; r += row_step) {
                int reflect_distance = std::abs(r - reflected_row) + limit;
                int first_col = std::max(min_col, reflected_col - reflect_distance);
                int last_col = std::min(max_col, reflected_col + reflect_distance);
                if (near) {
                    first_col = std::max({first_col, bc - limit, left_point.col - limit});
                    last_col = std::min({last_col, bc + limit, left_point.col + limit});
                }
                if (first_col > last_col) continue;
                int delta = std::abs(r - left_point.row);
                int parity = col_parity(r);
                auto consider = [&](int c) {
                    return c >= first_col && c <= last_col &&
                        (parity < 0 || (c & 1) == parity) && visit_streamed({r, c});
                };
                if (delta == required_offset) {
                    if (!required_offset) {
                        for (int c = first_col; c <= last_col; ++c)
                            if (consider(c)) return true;
                    } else {
                        for (int c = first_col; c <= std::min(last_col, left_point.col - 2); ++c)
                            if (consider(c)) return true;
                        for (int c = std::max(first_col, left_point.col + 2); c <= last_col; ++c)
                            if (consider(c)) return true;
                    }
                } else if (delta > required_offset) {
                    int col = left_point.col;
                    if (!required_offset) {
                        if (consider(col - delta) || consider(col) || consider(col + delta)) return true;
                    } else {
                        // For delta >= 2 the six columns are already sorted.
                        std::array candidates{col - delta - 1, col - delta + 1, col - 1,
                                              col + 1, col + delta - 1, col + delta + 1};
                        for (std::size_t i = 0; i < candidates.size(); ++i)
                            if ((i == 0 || candidates[i] != candidates[i - 1]) && consider(candidates[i])) return true;
                    }
                }
            }
        } else {
            for (const auto& entry : segment_pool.starts) {
                Point start_point = point(entry.start);
                if ((start_point.col > bc) != right || ray_offset(point(l), start_point) != required_offset) continue;
                if ((distance(point(b), start_point) <= limit) != near ||
                    (distance(point(l), start_point) <= limit) != near) continue;
                if (std::abs(start_point.col - reflected_col) > std::abs(start_point.row - reflected_row) + limit) continue;
                if (visit_start(entry)) return true;
            }
        }
        return found;
    }

    struct FinalForecast { bool mod_seven, use_a, use_b; };

    FinalForecast final_forecast(const State& s) const {
        auto [u, m, z] = s.node.cells();
        Point U = point(u), M = point(m), E = point(s.cells.end());
        int manhattan = std::abs(U.row - M.row) + std::abs(U.col - M.col);
        return {bool((manhattan <= 13) ^ (std::abs(M.col - E.col) <= 13)),
                distance(point(z), point(s.cells.start)) % 3 != 0,
                gcd(rotations(u)[2], rotations(m)[0]) > 1};
    }

    bool final_geometry(FinalForecast f, const Node& node, Span cells) const {
        return (distance(point(node[1]), point(cells.start)) % limit == 0) == f.mod_seven;
    }

    bool final_alignment(FinalForecast f, Span cells, const Key& key) const {
        int last = runes_[cells.end()];
        return (!f.use_a || std::abs(last - key[(cells.length - 1) % 3]) % 3 != 1)
            && (!f.use_b || std::abs(key[0] - last) > limit);
    }
};

} // namespace lp
