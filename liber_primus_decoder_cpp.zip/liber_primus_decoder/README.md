# Finding Liber Primus routes in rune matrices

Extract the archive, open a terminal in the folder containing `decode_cpp`, and run the command below. All required input data for the included example is in the archive.

```bash
./decode_cpp matrix.txt
```

The decoder starts the full opening search (`free`) by default. Pass `--opening` to select another mode.

The C++ launcher compiles `decode.cpp` for the local CPU on the first run and reuses the executable on later runs. It needs a C++20 compiler and zlib development headers. On macOS, use the Xcode Command Line Tools (`xcode-select --install` if needed). On Debian or Ubuntu, install `g++` and `zlib1g-dev`. On Windows, the launcher can be run under WSL. If the extracted launcher has no executable permission, run `sh ./decode_cpp matrix.txt`.

For a direct full search with trace and per-layer progress, run:

```bash
./decode_cpp matrix.txt --opening free --trace --progress
```

The C++ search checks whether a decrypted block can be covered entirely by words before ranking it. Full searches on maps of up to 1,024 cells use precomputed masks to combine key filters and select segment starts. Readings that share a prefix reuse that prefix and its trace.

The C++ decoder defaults to the logical CPUs available to the process. On Linux, it checks CPU affinity and visible cgroup CPU quotas. Use `LP_CPP_THREADS=max` to request automatic maximum parallelism explicitly or a positive number to cap it. The decoder starts workers when there is enough independent work and reuses them across layers and matrices.

```bash
./decode_cpp --cpu-info
LP_CPP_THREADS=max ./decode_cpp large.json --opening scan --max-depth 1 --by-depth --progress
```

### Searching a series of matrices

Pass multiple paths to the C++ launcher with `--batch`:

```bash
./decode_cpp --batch --opening free matrix.txt variants/*.txt
./decode_cpp --batch --opening short variants/*.txt
```

The batch loads the dictionary once and reuses the geometry tables while matrix dimensions stay the same. Short, scan, and heading batches can search separate files in parallel. The results appear in input order under a header for each path. Batch mode defaults to `free` if no opening is specified. A dash can read one matrix from stdin. The batch exits with status 4 if any search reaches its depth cap with active branches, or 3 if at least one search has no completed reading and none is incomplete. Invalid input stops the batch with status 2.

The program prints the highest-scoring English reading among the longest completed routes first. The next line shows the same reading with `|` marking the boundaries between independently decrypted blocks. A block can contain several words. The formulas do not determine punctuation.

| Task | Command |
| --- | --- |
| Show the source cells, aligned keys, and plaintext rune indices for the highest-scoring route | `./decode_cpp matrix.txt --top 1 --trace` |
| Show more English readings in frequency-score order | `./decode_cpp matrix.txt --top 100` |
| Show the number of states at each step | `./decode_cpp matrix.txt --progress` |
| Run the full opening search directly | `./decode_cpp matrix.txt --opening free` |
| Run the short search with both totient offsets directly | `./decode_cpp matrix.txt --opening short` |
| Reproduce the original offset and initial signature | `./decode_cpp matrix.txt --opening scan` |
| Compare completed routes of all lengths, including single-block routes, using the same frequency score | `./decode_cpp matrix.txt --all-lengths` |
| Check completed routes of a specified length | `./decode_cpp matrix.txt --blocks 12` |
| Show up to three best readings at every reached depth | `./decode_cpp matrix.txt --by-depth` |
| Change the number of readings per depth | `./decode_cpp matrix.txt --by-depth --top 5` |

With `--by-depth`, each depth gets its own ranking of readings that reach that many blocks, including intermediate routes. The included matrix produces rankings for depths 1 through 39 in one search. Use `--top K` to change the default of three readings per depth. Use `--trace` to trace the first-ranked reading in each group.

## Using your own matrix

Pass your file in place of `matrix.txt`. The decoder infers the height from the number of rows and the width from the number of cells in the first row. Supply at least one row and one cell per row, with the same number of cells on every row. Separate cells with spaces in a TXT file or commas in a CSV file. You can also use a JSON array of rows or pass `-` to read from stdin. The included 27×27 example contains the 729 runes extracted from the project map, with no route annotations.

### Large matrices

For maps above 1,024 cells, C++ generates segments along the rays that can satisfy the current state and reuses the key-center checks shared by segments with the same start. On tall maps, terminal checks intersect the permitted start lines with the reflection bounds before scanning their rows. When the estimated key index would exceed four million candidate positions, the decoder generates keys on demand from eligible centers. JSON rows are processed incrementally. A dictionary bound can cut a long ray once the current state is known to have a geometric continuation.

In `free` mode, long uniform runs share the same initial word test for each key. On maps of at least 65,536 cells, `--max-depth 1` or `--blocks 1` lets the decoder process openings immediately in `free`, `scan` and `short` and keep only the rankings and counters. The first-layer count is printed once that layer has been processed. Expansion on large maps feeds a bounded queue. Workers can start later transitions as earlier results are merged in their original order. All search rules still apply to every eligible transition.

For `free` openings, each worker keeps a fixed-size cache of dictionary word ends and decrypts runes on demand. Start ranges can run in parallel when only a few distinct opening keys are present. A word that starts inside a range may still end beyond it. For multiple layers, the decoder counts centers per opening key and revisits the matrix in order after finding readable blocks. For first-layer-only runs it stores consecutive centers with the same key as ranges. Dictionaries with words longer than 64 letters use the same exact on-demand search without the word-end cache.

Coordinates and rotations are calculated from the cell index. Other widths use exact multiplication by a precomputed reciprocal, and powers of two use shifts. The Möbius table stores each sign in two bits. The search shares dictionary readings between opening states and builds their paths when a reading reaches the ranking or yields a continuation. It stores single-reading rankings inline and releases processed rankings as each layer advances. Peak memory depends on how many distinct states and ranked routes the matrix and dictionary produce.

Large regular files containing numeric JSON matrices are read in fixed-size chunks directly into rune storage. The general parser handles named runes, Unicode and detailed input diagnostics. The Möbius table is built in parallel ranges using bounded worker scratch space. The cached quarter-turn signs use two bits per cell. The other signs are read from the Möbius table. The ranking of a dictionary reading shares suffixes until the final list of words is produced.

On dense maps with at least 1,048,576 cells, the search tests which keys admit a complete dictionary reading before visiting their key nodes, once a geometric continuation is known. This also applies when checking for an active branch at the depth limit. For long blocks, it checks whether the end of the block is reachable through dictionary words and scores the readings when it encounters a matching key node. Dense key-center groups use parity bitmaps that can reject groups of centers by residue and column together. On sparse grids, the decoder uses lists when those take less space. Long scans of key centers reuse the divisors of the ciphertext start address. When a key must touch the neighborhood of a ciphertext span, the search intersects that neighborhood with the key axis and visits only the resulting radius interval. Parallel ranges of starting rows share the eligible centers of their source state. Completed state blocks are released during the ordered merge.

For a bounded first run, use `--max-depth` with `--by-depth` to see the rankings that reach the requested depth.

```bash
./decode_cpp large.json --opening scan --max-depth 1 --by-depth --progress
```

Use `--opening free` to try all allowed opening locations. The work at a single depth still depends on how many routes the input and dictionary admit. Exit status 4 means a verified continuation exists past the requested depth.

Coordinate addresses, rotations, reflected positions, and the opening block's row wrap use the input dimensions. A quarter-turn of a rectangular grid swaps its height and width for address calculations. The numerical filters from Reports 00–27 retain their original thresholds, including the distance cutoff of 13 in Report 26. The reports' recorded results apply to the supplied map.

A cell can contain an index from 0 to 28, a Latin rune label, or a runic character. For example, `TH` occupies one cell, and `C/K`, `C`, and `K` all denote the same index. The J rune can also be entered as `ᛂ` for transcriptions that use that glyph. Zero is valid in the ciphertext. Report 00 requires positive indices for all three original key runes.

## Search assumptions

Reports 00–27 define how routes continue. The default opening mode, `free`, pairs every eligible opening key with every starting cell from which at least two runes can be read. It considers all six signatures supported by Report 01. Each signature determines the initial phase and the shared outer value. The key is aligned by that phase, and the phase is added to the running sum in accordance with Report 11.

Opening keys come from three adjacent horizontal cells, read left to right, with positive rune indices and φ applied to the center rune. The ciphertext of the first block is read in row-major order, wrapping at the right edge. The search tries all lengths from two runes through the end of the matrix that can be segmented into complete words. It applies the initial Direct-mode sign from Report 02. The default search takes no opening coordinates, key-to-ciphertext offset, first-block length, target block count, intermediate nodes, or reference words as input.

The short search (`--opening short`) uses signature (0, 0, 0) and tests two possible starts for each opening key. The starting positions are φ(h) and φ(h) + φ(φ(h)) cells from the left key cell in row-major order, where h is the original center rune index. Both starting positions feed into the same search for subsequent blocks.

The original `--opening scan` mode uses the same signature and the φ(h) + φ(φ(h)) offset. The optional `--opening heading` mode also requires key centers of the form (r, φ(r)), with radius r − φ(r) = 1 and left rune index r + φ(r).

For each subsequent block, the search considers all four key-node axes, every positive radius for which both outer cells fit, both orders of the outer runes, and both treatments of the center. It enumerates straight ciphertext segments of at least two cells in eight directions, stopping at the matrix edge. On the supplied 27×27 map, the largest possible key radius is 13 and the longest straight segment contains 27 cells. The opening block has its own reading order.

## Transitions and stopping conditions

| Reports | Calculations |
| --- | --- |
| 00–03 | Derived key, signature, phase, alignment, subtraction modulo 29, leftmost-cell mode, reading direction and axis |
| 04–10 | Center and ciphertext parities, ray offset, node mirror status, minimum length, four GCD checks |
| 11–16 | Cyclic phase modes, threshold-skipping check, exact offset, axis group and exact node axis using the GP primes from Report 14, radius parity, whole words within a block |
| 17–20 | XOR for the center column, three bits for the start and end positions, two distances accounting for the previous start, GCDs in two orientations |
| 21–25 | Conditional bound on radius and length, coverage by a single key cell, Möbius forecast for the extreme cell, alignment modulo 7, reflected bound |
| 26–27 | Forecast of whether the distance is divisible by 7 and both final-rune checks on the same key alignment |

The search proceeds one layer at a time. Each path carries its cumulative S, current phase, outer signature value, and previous start. States merge only when every input to future calculations matches. The dictionary check covers the entire decrypted block. Words can start and end only at rune boundaries. The search admits the U/V, C/K, S/Z, NG/ING and IA/IO alternatives. Within a word, the pair C/K followed by W can also be read as QU, as in QUESTION on LP1 scan 16.

Under the definition of a complete route in Report 27, a terminal block must have zero geometric successors under 00–25 **before the dictionary check**. If geometry allows a continuation but none yields words and passes 26–27, the branch is discarded. The default command has no target answer length. If any branches remain active at the `--max-depth` limit (default 128), the program marks the result as incomplete and returns exit code 4. You can raise the limit. Exit code 3 means that an exhaustive search under the specified conditions found no completed reading.

## Frequency score

The dictionary contains 112,799 admitted forms. The base list uses occurrence counts from FrequencyWords / OpenSubtitles 2018. Forms outside the first 50,000 entries receive a raw count of 0. The five LP1 forms TOTIENT, PRIMALITY, DONT, WIDSOM and BELEIVE were added with a raw count of 0. After matching the list against the dictionary, 31,966 forms have a nonzero count. The allowed single-letter words are A and I.

For a word with count c, the program uses p(w) = (c + 1) / (sum of all counts + dictionary size). A reading's score is the sum of log₁₀ p(w) over all its words. A negative score closer to zero ranks higher. Individual word frequencies allow different segmentations of the same rune sequence to be compared. The model does not score context, grammar, or punctuation. The logarithmic scale often favors shorter readings, so the default output compares completed readings at the greatest depth reached by a completed route.

The `--top K` option sets the number of distinct texts to display. The number of geometric states in each layer is unrestricted by K. Prefixes from different geometries compete only when their states match exactly. For each discarded prefix, K distinct higher-ranked prefixes admit the same continuation. This yields the exact top readings for the specified score. Use `--lexicon` to supply another two-column UTF-8 table, either plain or gzip-compressed. Use one lowercase ASCII word and one nonnegative integer count per line, separated by whitespace. List each word once. Changing the table changes both word admission and ranking.

## Verification on the supplied matrix

The full search finds 87,115 admissible opening states. An opening state represents a key node and a first ciphertext block with a dictionary reading. Several states can use the same starting cell. The short search finds 64 states, and the original `--opening scan` mode finds 36. All three modes reach a greatest completed depth of 39 blocks and give the same ranking at that depth. The two routes share their first 38 blocks and each contains 118 runes. One ends in DIE and the other in WINGING (W · ING · ING). Each route admits 96 English readings. Use `--top 192` to display the full ranking at depth 39. The top reading ends in DIE and scores −117.143145. The highest-ranked WINGING reading places fourth at −119.992244.

Across the 38 transitions of the DIE route, the local pools contain 1,348 geometries, 2,414 aligned-key assignments and 209 dictionary readings in total. The QU convention adds one local reading after SEE (block 14). Comparing only successors of the published lengths gives 92 readings. Report 27 uses Hunspell and single-rune emissions, giving 208 local readings and 92 at the recorded lengths. Shuffling the matrix with Python’s `random.Random(27).shuffle` reaches one block with `scan` and 14 blocks with `free`.

## Data sources

- The formulas and matrix come from the supplied archive of the [Liber Primus 27×27 Map project](https://github.com/2retooz270703/Liber-Primus-27x27-Map-3-Rune-Nodes-Totient-Decryption).
- The English word list was built from en_US Hunspell/SCOWL by expanding affixes and checking lowercase forms with Hunspell. See [SCOWL-LICENSE.txt](data/SCOWL-LICENSE.txt) for the terms and attribution.
- The counts come from the [FrequencyWords English list](https://github.com/hermitdave/FrequencyWords/blob/master/content/2018/en/en_50k.txt). See [FREQUENCIES.txt](data/FREQUENCIES.txt) for the table's provenance and license.
