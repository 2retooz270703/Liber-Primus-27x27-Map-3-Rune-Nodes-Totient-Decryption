#include "cpp/search.hpp"
#include "cpp/cpu.hpp"

#include <cstdlib>
#include <locale>
#include <span>

#if defined(__APPLE__)
#include <mach-o/dyld.h>
#endif
#if defined(_WIN32)
#include <windows.h>
#endif

namespace {

constexpr std::string_view usage = R"(usage: decode_cpp [-h] [--top TOP] [--opening {free,short,scan,heading}]
                 [--max-depth MAX_DEPTH]
                 [--blocks BLOCKS | --all-lengths | --by-depth] [--trace]
                 [--progress] [--lexicon LEXICON]
                 matrix
)";
constexpr std::string_view help = R"(
Search routes under rules 00–27 and print the English readings with the
highest frequency scores.

positional arguments:
  matrix                rectangular matrix in TXT, CSV, JSON, or "-" for stdin

options:
  -h, --help            show this help message and exit
  --top TOP             maximum readings per ranking (5 by default, 3 with
                        --by-depth)
  --opening {free,short,scan,heading}
                        choose free (full, default), short (both totient
                        offsets), scan (original offset), or heading
  --max-depth MAX_DEPTH
                        depth limit to prevent an endless search (128)
  --blocks BLOCKS       search only for geometrically complete routes of
                        exactly N blocks
  --all-lengths         compare completed routes of all lengths using the same
                        frequency score
  --by-depth            rank all readings separately at each reached depth
  --trace               show coordinates, keys, and runes for the top reading
                        in each ranking
  --progress            print the number of states in each layer to stderr
  --lexicon LEXICON     English words and frequency counts in TXT/TSV or GZIP
                        format
)";

struct ArgumentError : std::runtime_error { using std::runtime_error::runtime_error; };

struct Options {
    std::vector<std::string_view> matrices;
    std::filesystem::path lexicon;
    lp::Opening opening = lp::Opening::free;
    bool show_help = false, progress = false, trace = false;
    bool all_lengths = false, by_depth = false, batch = false;
    std::int64_t top = 5, max_depth = 128, blocks = 0;
};

std::filesystem::path executable_path(const char* argv0) {
#if defined(__linux__)
    std::error_code error;
    auto path = std::filesystem::read_symlink("/proc/self/exe", error);
    if (!error) return path;
#elif defined(__APPLE__)
    std::uint32_t length = 0;
    _NSGetExecutablePath(nullptr, &length);
    std::vector<char> path(length);
    if (_NSGetExecutablePath(path.data(), &length) == 0)
        return std::filesystem::weakly_canonical(path.data());
#elif defined(_WIN32)
    std::wstring path(32768, L'\0');
    auto length = GetModuleFileNameW(nullptr, path.data(), static_cast<DWORD>(path.size()));
    if (length && length < path.size()) { path.resize(length); return path; }
#endif
    return std::filesystem::weakly_canonical(std::filesystem::absolute(argv0));
}

std::int64_t number(std::string_view text, std::string_view name) {
    std::string digits;
    bool negative;
    if (!lp::integer_digits(lp::strip(text), digits, negative))
        throw ArgumentError("argument " + std::string(name) + ": invalid int value: " + lp::repr(text));
    std::int64_t value = 0;
    for (char c : digits) {
        if (value > (std::numeric_limits<std::int64_t>::max() - c + '0') / 10)
            return negative ? -std::numeric_limits<std::int64_t>::max() : std::numeric_limits<std::int64_t>::max();
        value = 10 * value + (c - '0');
    }
    return negative ? -value : value;
}

bool negative_number(std::string_view arg) {
    if (!arg.starts_with('-') || arg.size() < 2) return false;
    arg.remove_prefix(1);
    auto dot = arg.find('.');
    if (dot == arg.size() - 1) return false;
    for (std::size_t i = 0; i < arg.size(); ++i)
        if (i != dot && (arg[i] < '0' || arg[i] > '9')) return false;
    return true;
}

Options parse(int argc, char** argv) {
    Options options;
    constexpr std::array<std::string_view, 10> flags{
        "--help", "--top", "--opening", "--max-depth", "--blocks", "--all-lengths",
        "--by-depth", "--trace", "--progress", "--lexicon"
    };
    constexpr std::array<std::string_view, 4> openings{"free", "short", "scan", "heading"};
    struct Extra { std::string_view value; bool positional; };
    std::vector<Extra> extras;
    bool top_set = false, positional = false;
    std::string_view exclusive;
    for (int i = 1; i < argc; ++i) {
        std::string_view arg = argv[i];
        if (!positional && arg == "--") { positional = true; continue; }
        if (!positional && arg == "--batch") { options.batch = true; continue; }
        if (positional || arg.size() < 2 || arg.front() != '-' || negative_number(arg)) {
            if (options.matrices.empty()) options.matrices.push_back(arg);
            else extras.push_back({arg, true});
            continue;
        }
        auto eq = arg.find('=');
        auto name = arg.substr(0, eq);
        std::string_view flag;
        if (name == "-h" || (arg.starts_with("-h") && !arg.starts_with("--"))) flag = "--help";
        else if (name.starts_with("--")) {
            std::vector<std::string_view> matches;
            for (auto option : flags) {
                if (option == name) { matches = {option}; break; }
                if (option.starts_with(name)) matches.push_back(option);
            }
            if (matches.size() > 1) {
                std::string list;
                for (auto option : matches) { if (!list.empty()) list += ", "; list += option; }
                throw ArgumentError("ambiguous option: " + std::string(arg) + " could match " + list);
            }
            if (matches.size() == 1) flag = matches.front();
        }
        if (flag.empty()) { extras.push_back({arg, false}); continue; }
        bool takes_value = flag == "--top" || flag == "--max-depth" || flag == "--blocks" ||
                           flag == "--opening" || flag == "--lexicon";
        std::string_view value;
        if (takes_value) {
            if (eq != arg.npos) value = arg.substr(eq + 1);
            else if (i + 1 == argc ||
                     (std::string_view(argv[i + 1]).starts_with('-') && std::string_view(argv[i + 1]) != "-" &&
                      !negative_number(argv[i + 1]))) {
                throw ArgumentError("argument " + std::string(flag) + ": expected one argument");
            } else value = argv[++i];
        } else if (eq != arg.npos || (flag == "--help" && arg.starts_with("-h") && arg != "-h")) {
            auto rejected = eq == arg.npos ? arg.substr(2) : arg.substr(eq + 1);
            auto display = flag == "--help" ? "-h/--help" : flag;
            throw ArgumentError("argument " + std::string(display) + ": ignored explicit argument " + lp::repr(rejected));
        }
        if (flag == "--help") { options.show_help = true; return options; }
        if (flag == "--blocks" || flag == "--all-lengths" || flag == "--by-depth") {
            if (!exclusive.empty() && flag != exclusive)
                throw ArgumentError("argument " + std::string(flag) + ": not allowed with argument " +
                                    std::string(exclusive));
            exclusive = flag;
        }
        if (flag == "--top") { options.top = number(value, flag); top_set = true; }
        if (flag == "--max-depth") options.max_depth = number(value, flag);
        if (flag == "--blocks") options.blocks = number(value, flag);
        if (flag == "--all-lengths") options.all_lengths = true;
        if (flag == "--by-depth") options.by_depth = true;
        if (flag == "--trace") options.trace = true;
        if (flag == "--progress") options.progress = true;
        if (flag == "--lexicon") options.lexicon = value.empty() ? "." : value;
        if (flag == "--opening") {
            auto found = std::find(openings.begin(), openings.end(), value);
            if (found == openings.end())
                throw ArgumentError("argument --opening: invalid choice: " + lp::repr(value) +
                                    " (choose from free, short, scan, heading)");
            options.opening = static_cast<lp::Opening>(found - openings.begin());
        }
    }
    if (options.matrices.empty()) throw ArgumentError("the following arguments are required: matrix");
    std::string unexpected;
    for (auto extra : extras) {
        if (options.batch && extra.positional) options.matrices.push_back(extra.value);
        else { unexpected += ' '; unexpected += extra.value; }
    }
    if (!unexpected.empty()) throw ArgumentError("unrecognized arguments:" + unexpected);
    if (options.batch && std::count(options.matrices.begin(), options.matrices.end(), "-") > 1)
        throw ArgumentError("--batch can read stdin only once.");
    if (!top_set && options.by_depth) options.top = 3;
    if (options.top < 1 || options.max_depth < 1 || (exclusive == "--blocks" && options.blocks < 1))
        throw ArgumentError("top, max-depth, and blocks must be positive.");
    if (options.blocks > options.max_depth) throw ArgumentError("blocks exceeds max-depth. Increase --max-depth.");
    return options;
}

std::string capital_words(const lp::Words& words, const lp::English& english) {
    std::string out;
    for (int word : words) {
        if (!out.empty()) out += ' ';
        for (char c : english.word(word)) out += static_cast<char>(c - 'a' + 'A');
    }
    return out;
}

template<class Value>
void tuple_output(std::ostream& out, int size, Value&& value) {
    out << '(';
    for (int i = 0; i < size; ++i) {
        if (i) out << ", ";
        value(out, i);
    }
    if (size == 1) out << ',';
    out << ')';
}

std::vector<const lp::BlockReading*> path_blocks(const lp::Path& path) {
    std::vector<const lp::BlockReading*> blocks(path.size);
    for (auto step = &path; step; step = step->previous.get()) blocks[step->size - 1] = &step->last;
    return blocks;
}

void print_readings(const lp::Ranking& readings, const lp::Geometry& geo,
                    const lp::English& english, bool trace, std::ostream& out) {
    for (std::size_t i = 0; i < readings.size(); ++i) {
        const auto& reading = readings[i];
        std::string plain, divided;
        std::size_t rune_total = 0;
        for (const auto* block : path_blocks(*reading.path)) {
            rune_total += block->step.cells.length;
            auto text = capital_words(*block->words, english);
            if (!plain.empty()) { plain += ' '; divided += " | "; }
            plain += text;
            divided += text;
        }
        out << '#' << i + 1 << "  score=" << std::fixed << std::setprecision(6) << reading.score
                  << "  blocks=" << reading.path->size << "  runes=" << rune_total << '\n'
                  << plain << '\n' << divided << "\n\n";
    }
    if (!trace || readings.empty()) return;
    const auto& reading = readings.front();
    auto coordinate = [&](std::ostream& out, lp::Cell id) {
        auto [r, c] = geo.point(id);
        out << '(' << r << ", " << c << ')';
    };
    auto blocks = path_blocks(*reading.path);
    for (std::size_t i = 0; i < blocks.size(); ++i) {
        const auto& block = *blocks[i];
        const auto& step = block.step;
        out << std::setw(2) << std::setfill('0') << i + 1 << std::setfill(' ') << "  "
                  << std::left << std::setw(14) << capital_words(*block.words, english) << std::right << "  node=";
        auto node_cells = step.node.cells();
        tuple_output(out, 3, [&](auto& out, int j) { coordinate(out, node_cells[j]); });
        out << "  cells=";
        tuple_output(out, step.cells.length, [&](auto& out, int j) {
            coordinate(out, step.cells.start + step.cells.stride * j);
        });
        out << "  key=";
        auto key = lp::unpack_key(step.key);
        tuple_output(out, 3, [&](auto& out, int j) { out << key[j]; });
        out << "  runes=";
        auto code = geo.decrypt(step.cells, key);
        tuple_output(out, step.cells.length, [&](auto& out, int j) { out << int(code[j]); });
        out << '\n';
    }
}

unsigned thread_count(lp::CpuBudget budget) {
    unsigned count = budget.available();
    if (const char* setting = std::getenv("LP_CPP_THREADS")) {
        auto value = lp::strip(setting);
        if (value == "auto" || value == "max") return count;
        try {
            count = static_cast<unsigned>(std::clamp<std::int64_t>(number(value, "LP_CPP_THREADS"), 1, count));
        } catch (const ArgumentError&) {
            throw std::runtime_error("LP_CPP_THREADS must be auto, max or an integer.");
        }
    }
    return count;
}

int decode_matrix(const Options& options, const lp::Geometry& geo, const lp::English& english,
                  const lp::Workers& workers, std::vector<lp::ReadingCache>& cache,
                  std::ostream& out, std::ostream& error) {
    lp::Search search(geo, english, workers, cache);
    auto result = search.solve(options.opening, options.max_depth, options.blocks, options.all_lengths,
                               options.progress ? &error : nullptr, options.by_depth, [&](auto depth, const auto& readings) {
        out << "Depth " << depth << '\n';
        print_readings(readings, geo, english, options.trace, out);
    });
    if (!result.exhausted)
        error << "Depth limit " << options.max_depth << " reached with active branches remaining. "
                  << "Search incomplete. Increase --max-depth.\n";
    bool found = options.by_depth ? result.seeds > 0 : !result.readings.empty();
    if (!found) {
        out << "No " << (options.by_depth ? "readings" : "completed readings")
                  << " found under the specified conditions.\n";
        return result.exhausted ? 3 : 4;
    }
    if (!options.by_depth) print_readings(result.readings, geo, english, options.trace, out);
    out << "Admissible openings with words: " << result.seeds
              << ". Last layer explored: " << result.depth
              << ".\nTerminal states by length (blocks → states): ";
    bool first = true;
    for (auto [depth, count] : result.terminal_counts) {
        if (!first) out << ", ";
        first = false;
        out << depth << " → " << count;
    }
    out << '\n';
    return result.exhausted ? 0 : 4;
}

lp::Matrix load_matrix(std::string_view path) {
    if (path != "-")
        if (auto numeric = lp::read_numeric_matrix_file(path)) return std::move(*numeric);
    auto data = path == "-" ?
        std::string(std::istreambuf_iterator<char>(std::cin), std::istreambuf_iterator<char>()) :
        lp::read_file(path);
    lp::universal_newlines(data);
    return lp::read_matrix(data);
}

void batch_header(const Options& options, std::string_view path) {
    if (!options.batch) return;
    std::cout << "=== " << path << " ===\n";
    if (options.progress) std::cerr << "=== " << path << " ===\n";
}

std::vector<lp::ReadingCache> make_word_caches(const lp::English& english, unsigned count) {
    std::vector<lp::ReadingCache> caches;
    caches.reserve(count);
    for (unsigned i = 0; i < count; ++i) caches.emplace_back(english);
    return caches;
}

int decode_parallel_batch(const Options& options, const lp::English& english,
                          const lp::Workers& workers, const lp::Geometry::LayoutCache& layout) {
    struct Workspace {
        lp::Geometry::LayoutCache layout;
        std::vector<lp::ReadingCache> cache;
    };
    struct Completed {
        int status = 0;
        std::string out, error;
        std::exception_ptr failed;
    };
    lp::Workers single(1);
    std::vector<Workspace> workspaces;
    workspaces.reserve(workers.count());
    for (unsigned i = 0; i < workers.count(); ++i)
        workspaces.push_back({layout, make_word_caches(english, single.count())});

    // Short single-matrix searches rarely fill the CPU. Share the lexicon and
    // execute different matrices concurrently, with bounded, ordered output.
    int status = 0;
    auto paths = std::span(options.matrices).subspan(1);
    auto batch_size = std::size_t(workers.count()) * 2;
    for (std::size_t begin = 0; begin < paths.size(); begin += batch_size) {
        auto batch = paths.subspan(begin, std::min(batch_size, paths.size() - begin));
        std::vector<Completed> completed(batch.size());
        workers.run(batch.size(), 1, [&](std::size_t i, std::size_t worker) {
            auto& workspace = workspaces[worker];
            auto& result = completed[i];
            try {
                lp::Geometry geo(load_matrix(batch[i]), false, single, workspace.layout);
                std::ostringstream out, error;
                result.status = decode_matrix(options, geo, english, single, workspace.cache, out, error);
                result.out = std::move(out).str();
                result.error = std::move(error).str();
            } catch (...) {
                result.failed = std::current_exception();
            }
        });
        for (std::size_t i = 0; i < batch.size(); ++i) {
            batch_header(options, batch[i]);
            auto& result = completed[i];
            if (result.failed) std::rethrow_exception(result.failed);
            std::cout << result.out;
            std::cerr << result.error;
            status = std::max(status, result.status);
        }
    }
    return status;
}

} // namespace

int main(int argc, char** argv) {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    try {
        if (argc == 2 && std::string_view(argv[1]) == "--cpu-info") {
            auto budget = lp::cpu_budget();
            std::cout << "Available logical CPUs: " << budget.affinity << '\n';
            if (budget.quota != std::numeric_limits<unsigned>::max())
                std::cout << "CPU quota worker limit: " << budget.quota << '\n';
            std::cout << "Decoder worker limit: " << thread_count(budget) << '\n';
            return 0;
        }
        auto options = parse(argc, argv);
        if (options.show_help) {
            std::cout << usage << help;
            if (options.batch) std::cout << "\nUse --batch followed by one or more matrix paths to reuse the lexicon.\n";
            return 0;
        }
        const lp::Workers workers(thread_count(lp::cpu_budget()));
        lp::Geometry::LayoutCache layout;
        bool full = options.opening == lp::Opening::free;
        auto first_path = options.matrices.front();
        batch_header(options, first_path);
        if (options.lexicon.empty())
            options.lexicon = executable_path(argv[0]).parent_path() / "data" / "english.tsv.gz";
        auto initial = std::make_unique<lp::Geometry>(load_matrix(first_path), full, workers, layout);
        lp::English english(options.lexicon, static_cast<std::size_t>(options.top));
        auto word_caches = make_word_caches(english, workers.count());
        int exit_status = decode_matrix(options, *initial, english, workers, word_caches, std::cout, std::cerr);
        initial.reset();
        if (options.matrices.size() == 1) return exit_status;
        if (!full && options.matrices.size() > 2 && workers.count() > 1 &&
            std::find(options.matrices.begin(), options.matrices.end(), "-") == options.matrices.end()) {
            return std::max(exit_status, decode_parallel_batch(options, english, workers, layout));
        }
        for (auto path : std::span(options.matrices).subspan(1)) {
            batch_header(options, path);
            lp::Geometry geo(load_matrix(path), full, workers, layout);
            exit_status = std::max(exit_status, decode_matrix(options, geo, english, workers, word_caches,
                                                              std::cout, std::cerr));
        }
        return exit_status;
    } catch (const ArgumentError& error) {
        std::cerr << usage << "decode_cpp: error: " << error.what() << '\n';
        return 2;
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 2;
    }
}
