# Finding Liber Primus routes in a 27×27 matrix

Extract the archive, open a terminal in the folder containing `decode.py`, and run the command below. Use Python 3.9 or later. All required data is included alongside the script. You can run it offline without installing any packages.

```bash
python3 decode.py matrix.txt
```

The program prints the highest-scoring English reading among the longest completed routes first. The next line shows the same reading with `|` marking the boundaries between independently decrypted blocks. A block can contain several words. The formulas do not determine punctuation.

| Task | Command |
| --- | --- |
| Show the source cells, aligned keys, and plaintext rune indices for the highest-scoring route | `python3 decode.py matrix.txt --top 1 --trace` |
| Show more English readings in frequency-score order | `python3 decode.py matrix.txt --top 100` |
| Show the number of states at each step | `python3 decode.py matrix.txt --progress` |
| Compare completed routes of all lengths, including single-block routes, using the same frequency score | `python3 decode.py matrix.txt --all-lengths` |
| Check completed routes of a specified length | `python3 decode.py matrix.txt --blocks 12` |
| Show up to three best readings at every reached depth | `python3 decode.py matrix.txt --by-depth` |
| Change the number of readings per depth | `python3 decode.py matrix.txt --by-depth --top 5` |
| Run the tests | `python3 -m unittest -v` |

With `--by-depth`, each depth gets its own ranking of readings that reach that many blocks, including intermediate routes. The included matrix produces rankings for depths 1 through 39 in one search. Use `--top K` to change the default of three readings per depth. Use `--trace` to trace the first-ranked reading in each group.

## Using your own matrix

Pass your file in place of `matrix.txt`. It must contain 27 rows of 27 cells. Separate cells with spaces in a TXT file or commas in a CSV file. You can also use a JSON array of 27 arrays or pass `-` to read from stdin. The example matrix contains only the 729 runes extracted from the project map, with no route annotations.

A cell can contain an index from 0 to 28, a Latin rune label, or a runic character. For example, `TH` occupies one cell, and `C/K`, `C`, and `K` all denote the same index. The J rune can also be entered as `ᛂ` for transcriptions that use that glyph. Zero is valid in the ciphertext. Report 00 requires positive indices for all three original key runes.

## Search assumptions

Reports 00–27 define the transitions between blocks. For the first block, the program uses the movement rule from the project's separate description of the opening. In `scan` mode it examines every triple of adjacent horizontal cells from left to right. For a center rune with original index h, it uses φ(h) in the key and checks the initial signature (0, 0, 0) from Report 01. Starting at the left cell, it counts φ(h) + φ(φ(h)) positions to the right. Reading proceeds in row-major order, wrapping at the right edge, up to the end of the matrix. The program tries every length of at least two runes that can be segmented into words. It also checks the Direct-mode sign for the first block under Report 02.

The search takes no opening coordinates, first-block length, target block count, intermediate nodes, or reference words as input. Its opening hypotheses are limited to the horizontal movement rule described above. The optional `--opening heading` mode keeps triples whose centers are (r, φ(r)), whose radius is r − φ(r) = 1, and whose left rune has index r + φ(r).

For each subsequent block, the search considers all four key-node axes, every radius from 1 to 13 that fits, both orders of the outer runes, and both treatments of the center. It enumerates ciphertext segments of 2–27 cells in eight directions, stopping at the matrix edge. The opening block has its own reading order.

## Transitions and stopping conditions

| Reports | Calculations |
| --- | --- |
| 00–03 | Derived key, signature, phase, alignment, subtraction modulo 29, leftmost-cell mode, reading direction and axis |
| 04–10 | Center and ciphertext parities, ray offset, node mirror status, minimum length, four GCD checks |
| 11–16 | Cyclic phase modes, threshold-skipping check, exact offset, axis group and exact node axis using the GP primes from Report 14, radius parity, whole words within a block |
| 17–20 | XOR for the center column, three bits for the start and end positions, two distances accounting for the previous start, GCDs in two orientations |
| 21–25 | Conditional bound on radius and length, coverage by a single key cell, Möbius forecast for the extreme cell, alignment modulo 7, reflected bound |
| 26–27 | Forecast of whether the distance is divisible by 7 and both final-rune checks on the same key alignment |

The search proceeds one layer at a time. Each path carries its cumulative S, current phase, outer signature value, and previous start. States merge only when every input to future calculations matches. The dictionary check covers the entire decrypted block. Words can start and end only at rune boundaries. The search admits the U/V, C/K, S/Z, NG/ING and IA/IO alternatives. Within a word, the pair C/K followed by W can also be read as QU, as in QUESTION on LP1 scan 16.

Under the definition of a complete route in Report 27, a terminal block must have zero geometric successors under 00–25 **before the dictionary check**. If geometry allows a continuation but none yields words and passes 26–27, the branch is discarded. The default command has no target answer length. If any branches remain active at the `--max-depth` limit (default 128), the program marks the result as incomplete and returns exit code 4. You can raise the limit. Exit code 3 means that an exhaustive search under the specified conditions found no completed reading.

## Frequency score

The dictionary contains 112,799 admitted forms. The base list uses occurrence counts from FrequencyWords / OpenSubtitles 2018. Forms outside the first 50,000 entries receive a raw count of 0. The five LP1 forms TOTIENT, PRIMALITY, DONT, WIDSOM and BELEIVE were added with a raw count of 0. After matching the list against the dictionary, 31,966 forms have a nonzero count. The allowed single-letter words are A and I.

For a word with count c, the program uses p(w) = (c + 1) / (sum of all counts + dictionary size). A reading's score is the sum of log₁₀ p(w) over all its words. A negative score closer to zero ranks higher. Individual word frequencies allow different segmentations of the same rune sequence to be compared. The model does not score context, grammar, or punctuation. The logarithmic scale often favors shorter readings, so the default output compares completed readings at the greatest depth reached by a completed route.

The `--top K` option sets the number of distinct texts to display. The number of geometric states in each layer is unrestricted by K. Prefixes from different geometries compete only when their states match exactly. For each discarded prefix, K distinct higher-ranked prefixes admit the same continuation. This yields the exact top readings for the specified score. Use `--lexicon` to supply another two-column UTF-8 table, either plain or gzip-compressed. Use one lowercase ASCII word and one nonnegative integer count per line, separated by whitespace. List each word once. Changing the table changes both word admission and ranking.

## Verification on the supplied matrix

The full run finds 36 admissible opening states. Two geometric routes reach the greatest completed depth of 39 blocks. They share their first 38 blocks and each contains 118 runes. One ends in DIE and the other in WINGING (W · ING · ING). Each route admits 96 English readings. Use `--top 192` to display the full ranking at depth 39. The top reading ends in DIE and scores −117.143145. The highest-ranked WINGING reading places fourth at −119.992244.

Across the 38 transitions of the DIE route, the local pools contain 1,348 geometries, 2,414 aligned-key assignments and 209 dictionary readings in total. The QU convention adds one local reading after SEE (block 14). Comparing only successors of the published lengths gives 92 readings. Report 27 uses Hunspell and single-rune emissions, giving 208 local readings and 92 at the recorded lengths. Shuffling the matrix with Python’s `random.Random(27).shuffle` ends the search at the first layer.

## Data sources

- The formulas and matrix come from the supplied archive of the [Liber Primus 27×27 Map project](https://github.com/2retooz270703/Liber-Primus-27x27-Map-3-Rune-Nodes-Totient-Decryption).
- The English word list was built from en_US Hunspell/SCOWL by expanding affixes and checking lowercase forms with Hunspell. See [SCOWL-LICENSE.txt](data/SCOWL-LICENSE.txt) for the terms and attribution.
- The counts come from the [FrequencyWords English list](https://github.com/hermitdave/FrequencyWords/blob/master/content/2018/en/en_50k.txt). See [FREQUENCIES.txt](data/FREQUENCIES.txt) for the table's provenance and license.
