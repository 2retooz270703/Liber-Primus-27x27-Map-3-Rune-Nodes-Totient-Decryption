#!/usr/bin/env python3
"""Search rectangular rune matrices using the Liber Primus 27×27 rules. Python >=3.9.

Numbered comments refer to Start-reading-here/00..27 of the project.
Geometry uses 1-based (row, column); the four address slots are 0/90/180/270°.
No documents, route coordinates, example words or expected lengths are read.
"""
import argparse
import gzip
import json
import math
import re
import sys
import zlib
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache
from itertools import chain, count
from pathlib import Path

LIMIT = 7
RUNES = "F U/V TH O R C/K G W H N I J EO P X S/Z T B E M L NG/ING OE D A AE Y IA/IO EA".split()
LABELS = tuple(tuple(r.lower().split('/')) for r in RUNES)
PRIMES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47,
          53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109)
AXES = ((0, 1), (1, 1), (1, 0), (1, -1))  # H, NW-SE, V, NE-SW
DIRECTIONS = AXES + tuple((-r, -c) for r, c in AXES)
GLYPHS = "ᚠᚢᚦᚩᚱᚳᚷᚹᚻᚾᛁᛄᛇᛈᛉᛋᛏᛒᛖᛗᛚᛝᛟᛞᚪᚫᚣᛡᛠ"
RUNE_INDEX = {str(i): i for i in range(29)}
for i, label in enumerate(RUNES):
    for token in (label, *label.split('/'), GLYPHS[i]):
        RUNE_INDEX[token] = i
RUNE_INDEX.update({'ᛄ': 11, 'ᛃ': 11, 'ᛂ': 11, 'ᛊ': 15, 'ᛜ': 21})


def read_matrix(data):
    """Read a nonempty rectangular grid of rune indices or labels."""
    data = data.lstrip('\ufeff').strip()
    if data.startswith('['):
        rows = json.loads(data)
    else:
        rows = []
        for line in data.splitlines():
            line = line.strip()
            if not line:
                continue
            if re.search(r'(^|[,;])\s*[,;]|[,;]$', line):
                raise ValueError(f'Row {len(rows) + 1} contains an empty cell.')
            tokens = re.split(r'[\s,;]+', line)
            if len(tokens) == 1 and all(c in RUNE_INDEX and ord(c) > 127 for c in tokens[0]):
                tokens = list(tokens[0])
            rows.append(tokens)
    if not rows:
        raise ValueError('The matrix must contain at least one row.')
    if not isinstance(rows[0], list) or not rows[0]:
        raise ValueError('Row 1 must be a nonempty list of rune cells.')
    width = len(rows[0])
    grid = {}
    for row, entries in enumerate(rows, 1):
        if not isinstance(entries, list) or len(entries) != width:
            raise ValueError(f'Row {row} must contain {width} cells, like row 1.')
        for col, entry in enumerate(entries, 1):
            token = str(entry).strip().upper()
            if token not in RUNE_INDEX:
                raise ValueError(f'Cell ({row},{col}) contains an unknown rune {entry!r}.')
            grid[row, col] = RUNE_INDEX[token]
    return grid


def factors(n):
    if n <= 0:
        raise ValueError('The argument must be positive.')
    p = 2
    while p * p <= n:
        if n % p == 0:
            exponent = 0
            while n % p == 0:
                n //= p
                exponent += 1
            yield p, exponent
        p += 1
    if n > 1:
        yield n, 1


@lru_cache(None)
def phi(n):
    result = n
    for prime, _ in factors(n):
        result -= result // prime
    return result


@lru_cache(None)
def mu(n):
    sign = 1
    for _, exponent in factors(n):
        if exponent > 1:
            return 0
        sign = -sign
    return sign


def rotations(cell, height, width):
    row, col = cell
    flat = width * (row - 1) + col
    quarter = height * (col - 1) + height + 1 - row
    # A further half-turn reverses either orientation's row-major order.
    reverse = height * width + 1
    return flat, quarter, reverse - flat, reverse - quarter


def distance(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def leftmost(cells):
    return min(cells, key=lambda point: (point[1], -point[0]))


def ray_offset(a, b):
    dr, dc = abs(a[0] - b[0]), abs(a[1] - b[1])
    return min(dr, dc, abs(dr - dc))


def signature(key):
    return tuple(mu(phi(i)) for i in key)


def aligned(key, phase):
    return key[phase:] + key[:phase]


def decrypt(grid, cells, key):
    return tuple((grid[c] - key[i % 3]) % 29 for i, c in enumerate(cells))


@dataclass(frozen=True)
class State:
    node: tuple
    cells: tuple
    previous_start: tuple
    total: int
    outer: int
    phase: int


def key_index(grid):
    """00, 01, 07, 13–15. Both source directions and center operations."""
    groups = defaultdict(lambda: defaultdict(set))
    for row, col in grid:
        for axis, (dr, dc) in enumerate(AXES):
            for radius in count(1):
                u = row - radius * dr, col - radius * dc
                z = row + radius * dr, col + radius * dc
                if u not in grid or z not in grid:
                    break
                node = (u, (row, col), z)
                first, middle, last = (grid[c] for c in node)
                if min(first, middle, last) == 0:
                    continue
                for a, c in {(first, last), (last, first)}:
                    for b in {middle, phi(middle)}:
                        key = a, b, c
                        sig = signature(key)
                        if sig[0] != sig[2] or sig[0] < 0:
                            continue
                        group = axis, radius % 2, row % 2, col % 2, a == c, sig
                        groups[group][node].add(aligned(key, sum(sig) % 3))
    return {g: [(n, tuple(sorted(keys))) for n, keys in entries.items()]
            for g, entries in groups.items()}


def segment_index(grid):
    """02, 03, 05, 08, 09. All eight directions, stopping at the grid boundary."""
    groups = defaultdict(lambda: defaultdict(list))
    for start in grid:
        for dr, dc in DIRECTIONS:
            axis = 'H' if dr == 0 else 'V' if dc == 0 else 'D'
            cells = [start]
            for span in count(1):
                end = start[0] + span * dr, start[1] + span * dc
                if end not in grid:
                    break
                cells.append(end)
                left = leftmost((start, end))
                group = axis, start == left, end[0] % 2, left[0] % 2, left[1] % 2
                groups[group][start].append((tuple(cells), end, left))
    return groups


class Geometry:
    def __init__(self, grid):
        self.grid = grid
        self.height = max((row for row, _ in grid), default=0)
        self.width = max((col for _, col in grid), default=0)
        self.rot = {c: rotations(c, self.height, self.width) for c in grid}
        self.keys = key_index(grid)
        self.segments = segment_index(grid)

    def openings(self, mode, english):
        """Pair adjacent horizontal keys with first blocks read in row-major order."""
        cells = tuple(sorted(self.grid))

        @lru_cache(maxsize=128)
        def free_prefixes(key):
            # Each start uses key slot 0. All starts with the same residue
            # share one decrypted row-major stream.
            prefixes = [()] * len(cells)
            for residue in range(3):
                stream = decrypt(self.grid, cells, aligned(key, -residue % 3))
                for start, ends in english.prefix_ends_by_start(stream, residue, 3):
                    prefixes[start] = ends
            return tuple(prefixes)

        for row, col in self.grid:
            node = (row, col - 1), (row, col), (row, col + 1)
            if node[0] not in self.grid or node[2] not in self.grid:
                continue
            if mode == 'heading' and (col != phi(row) or row - col != 1
                                      or self.grid[node[0]] != row + col):
                continue
            a, h, c = (self.grid[point] for point in node)
            if min(a, h, c) == 0:
                continue
            center = phi(h)
            unrotated = a, center, c
            sig = signature(unrotated)
            if sig[0] != sig[2] or sig[0] not in (0, 1):  # Report 01 state format
                continue
            phase = sum(sig) % 3
            key = aligned(unrotated, phase)
            if mode == 'free':
                starts = enumerate(free_prefixes(key))
            else:
                if sig != (0, 0, 0):
                    continue
                left = self.rot[node[0]][0] - 1
                single = left + center
                double = single + phi(center)
                positions = (single, double) if mode == 'short' else (double,)
                starts = []
                for start in positions:
                    lengths = english.prefix_lengths(decrypt(self.grid, cells[start:], key))
                    starts.append((start, [start + length for length in lengths]))
            for start, ends in starts:
                for end in ends:
                    if end - start < 2:
                        continue
                    ordered = cells[start:end]
                    if mu(self.rot[leftmost(ordered)][1]) >= 0:  # Initial Direct mode
                        # Report 11 starts S at zero before adding the first phase.
                        yield State(node, ordered, ordered[0], phase, sig[0], phase), key

    def next_phase(self, state):
        # 01 and 11. Mode and offset use S before this transition.
        mode = (state.total // LIMIT) % 4
        slot = 2 if mode in (1, 2) else 0
        phase = (int(mode in (0, 2)) + sum(mu(self.rot[c][slot]) for c in state.cells)) % 3
        outer = (state.outer + mu(self.rot[leftmost(state.cells)][1])) % 2
        return state.total + phase, outer, phase

    def key_forecast(self, state, phase_state):
        # Physical extremes are always in row, then column, order.
        u, m, z = state.node
        b, e, l = state.cells[0], state.cells[-1], leftmost(state.cells)
        M, Z, B, E, L = (self.rot[c] for c in (m, z, b, e, l))
        _, outer, phase = phase_state
        group_bit = (mu(M[1] + Z[2]) < 0) == (mu(L[1] + Z[2]) < 0)  # 13
        gp = sum(PRIMES[self.grid[c]] for c in state.node)
        diagonal = (mu(math.gcd(M[1], Z[3])) < 0) ^ (mu(gp) > 0) ^ (mu(M[0] + Z[3]) != 0)
        axis = 2 * group_bit + diagonal  # 14
        radius = ((sum(m) + sum(b)) % 2) ^ (mu(math.gcd(Z[2], L[2])) < 0) ^ (mu(B[1] + E[1]) > 0)
        row = (1 + b[1] + e[0] + m[0] + mu(B[2])) % 2  # 04
        col = (1 + b[0] + e[0] + m[0]) % 2
        mirror = distance(z, l) % 3 != 2  # 07
        sig = (outer, (phase - 2 * outer + 1) % 3 - 1, outer)
        return (axis, radius, row, col, mirror, sig)

    def segments_after(self, state, center_row, next_total):
        u, m, z = state.node
        b, e, l = state.cells[0], state.cells[-1], leftmost(state.cells)
        U, M, Z, B, E, L = (self.rot[c] for c in (u, m, z, b, e, l))
        score = mu(B[2] + M[0]) + mu(math.gcd(E[1], E[2]))  # 03
        axis = 'H' if score == 0 else 'V' if score > 0 else 'D'
        left_first = (mu(E[3]) + phi(self.grid[m])) % 2  # 02
        end_row = (1 + state.phase + mu(M[2])) % 2  # 05
        left_row = (center_row + 1 + state.phase + mu(m[0])) % 2
        turn = (2, 3, 0)[state.phase]
        mirror = self.grid[u] == self.grid[z]
        left_col = (b[0] + sum(mu(self.rot[c][1]) for c in state.cells) + mirror + mu(M[turn])) % 2  # 09
        group = axis, bool(left_first), end_row, left_row, left_col
        q = mu(E[0]) == mu(E[3]) == 0  # 06
        required_offset = int(q and not (mu(B[0]) == mu(B[1]) == 0))  # 12
        sign = -1 if (next_total // LIMIT) % 4 in (1, 2) else 1  # 02 next block's mode
        # 18. The predicted endpoint sector, endpoint sign and start side.
        vertical = (mu(math.gcd(M[2], L[3])) < 0) ^ (mu(Z[3] + B[2]) > 0) ^ (mu(math.gcd(M[3], L[2])) < 0)
        negative = (mu(math.gcd(M[2], L[0])) == 0) ^ (mu(math.gcd(M[1], B[1])) == 0) ^ (mu(math.gcd(M[2], E[0])) == 0)
        right = (mu(math.gcd(U[1], E[0])) == 0) ^ (mu(math.gcd(U[0], B[2])) < 0) ^ bool((E[3] // 4) % 2)
        # 19. First block uses its own start as its predecessor.
        start_xor = B[2] ^ self.rot[state.previous_start][2]
        near = (start_xor % LIMIT == 0) == (mu(U[0] + E[0]) < 0)
        reflected_col = self.width + 1 - z[1]
        reflected_row = self.height + 1 - b[0]
        for start, segments in self.segments.get(group, {}).items():
            if (start[1] > b[1]) != right or ray_offset(l, start) != required_offset:
                continue
            if (distance(b, start) <= LIMIT) != near or (distance(l, start) <= LIMIT) != near:
                continue
            if abs(start[1] - reflected_col) > abs(start[0] - reflected_row) + LIMIT:  # 25
                continue
            for cells, end, left in segments:
                if (mu(self.rot[end][0]) < 0) != negative or mu(self.rot[left][1]) * sign < 0:
                    continue
                if (abs(end[0] - u[0]) >= abs(end[1] - u[1])) == vertical:
                    yield cells, start, end, left

    def through25(self, state, next_phase):
        """Yield all legal geometric successors through 25, before the word test."""
        next_total, _, phase = next_phase
        if phase == 2 and state.total % LIMIT == 6:  # 11, no skipped multiple of 7
            return
        u, m, _ = state.node
        b, e, l = state.cells[0], state.cells[-1], leftmost(state.cells)
        U, M, B, E, L = (self.rot[c] for c in (u, m, b, e, l))
        group = self.key_forecast(state, next_phase)
        extreme_bit = (math.gcd(B[3], L[1]) % 3 == 0) ^ (mu(M[3] + E[3]) > 0)  # 23
        keys = []
        for node, aligned_keys in self.keys.get(group, ()):
            xor = M[3] ^ node[1][1]  # 17. Zero is admitted explicitly.
            if xor and mu(xor) > 0:
                continue
            if (mu(self.rot[node[0]][2]) > 0) == extreme_bit:
                keys.append((node, aligned_keys))
        if not keys:
            return
        xor = U[2] ^ M[3]
        mod_seven = bool(xor and mu(xor) < 0) ^ (mu(math.gcd(B[0], B[3])) == 0)  # 24
        bounded = distance(u, e) <= LIMIT  # 21
        for cells, start, end, left in self.segments_after(state, group[2], next_total):
            B2, E2, L2 = (self.rot[c] for c in (start, end, left))
            for node, aligned_keys in keys:
                center = node[1]
                M2 = self.rot[center]
                if ((M2[0] + L2[2]) % LIMIT == 0) != mod_seven:
                    continue
                if bounded and distance(node[0], center) + len(cells) - 1 > LIMIT:
                    continue
                if max(math.gcd(M2[0], B2[0]), math.gcd(M2[2], B2[0])) > LIMIT:  # 20
                    continue
                if any(mu(math.gcd(x, y)) == 0 for x, y in (
                    (M2[0], B2[0]), (M2[0], L2[0]), (M2[1], E2[3]), (M2[0], E2[2])
                )):  # 10, all four squarefree-GCD clauses
                    continue
                if min(abs(c[1] - center[1]) for c in cells) <= LIMIT:
                    if not any(max(distance(k, start), distance(k, left)) <= LIMIT for k in node):
                        continue   # 22, one and the same key cell must cover both points
                yield node, cells, aligned_keys

    def final_keys(self, state, node, cells, keys):
        """26 and both implications in 27, on the very same key alignment."""
        u, m, z = state.node
        b, e = state.cells[0], state.cells[-1]
        manhattan = abs(u[0] - m[0]) + abs(u[1] - m[1])
        forecast = (manhattan <= 13) ^ (abs(m[1] - e[1]) <= 13)
        if (distance(node[1], cells[0]) % LIMIT == 0) != forecast:
            return ()
        use_a = distance(z, b) % 3 != 0
        use_b = math.gcd(self.rot[u][2], self.rot[m][0]) > 1
        last_cipher = self.grid[cells[-1]]
        last_slot = (len(cells) - 1) % 3
        return tuple(key for key in keys
                     if (not use_a or abs(last_cipher - key[last_slot]) % 3 != 1)
                     and (not use_b or abs(key[0] - last_cipher) > LIMIT))


class English:
    """Exact top-K within each block. A trie advances one complete rune at a time."""
    def __init__(self, counts, top):
        if not counts or top < 1:
            raise ValueError('The dictionary must be nonempty and top must be positive.')
        self.top = top
        norm = sum(counts.values()) + len(counts)  # add-one smoothing on admitted vocabulary
        self.logp = {w: math.log10((count + 1) / norm) for w, count in counts.items()}
        self.trie = {}
        for word in counts:
            branch = self.trie
            for ch in word:
                branch = branch.setdefault(ch, {})
            branch[''] = word
        self.readings = lru_cache(maxsize=32768)(self._readings)

    @classmethod
    def from_file(cls, filename, top):
        counts = {}
        opener = gzip.open if filename.suffix == '.gz' else open
        with opener(filename, 'rt', encoding='utf-8') as file:
            for lineno, line in enumerate(file, 1):
                try:
                    word, count_text = line.split()
                    count = int(count_text)
                except ValueError:
                    raise ValueError(f'Invalid frequency dictionary entry on line {lineno}.') from None
                if not re.fullmatch('[a-z]+', word) or count < 0 or word in counts:
                    raise ValueError(f'Invalid frequency dictionary entry on line {lineno}.')
                counts[word] = count
        return cls({word: count for word, count in counts.items()
                    if len(word) > 1 or word in ('i', 'a')}, top)

    def _matches(self, code, start):
        pending = defaultdict(list, {start: [self.trie]})

        for pos in range(start, len(code)):
            branches = pending.pop(pos, ())
            if not branches:
                if not pending:
                    break
                continue

            choices = [(pos + 1, label) for label in LABELS[code[pos]]]
            # LP1 page 16 spells QU with the two runes C/K and W.
            if code[pos:pos + 2] == (5, 7):
                choices.append((pos + 2, 'qu'))

            for branch in branches:
                for stop, label in choices:
                    child = branch
                    for char in label:
                        child = child.get(char)
                        if child is None:
                            break
                    if child is not None:
                        pending[stop].append(child)
                        if '' in child:
                            yield stop, child['']

    def prefix_lengths(self, code):
        """Every prefix coverable by complete words, including after a row wrap."""
        reachable = {0}
        for start in range(len(code)):
            if start in reachable:
                reachable.update(stop for stop, _ in self._matches(code, start))
        return sorted(reachable - {0})

    def prefix_ends_by_start(self, code, first, stride):
        """Yield whole-word endpoints at each start on one key alignment."""
        word_ends = [tuple(stop for stop, _ in self._matches(code, pos))
                     for pos in range(len(code))]
        word_ends.append(())
        for start in range(first, len(code) - 1, stride):
            reachable = set()
            pending = [start]
            while pending:
                for end in word_ends[pending.pop()]:
                    if end not in reachable:
                        reachable.add(end)
                        pending.append(end)
            yield start, tuple(sorted(reachable))

    def _readings(self, code):
        # 16. best[i] covers every rune from i to the end; no cross-block words.
        best = [()] * (len(code) + 1)
        best[-1] = ((0.0, ()),)
        for start in range(len(code) - 1, -1, -1):
            candidates = {}
            for stop, word in self._matches(code, start):
                for tail_score, tail in best[stop]:
                    score = self.logp[word] + tail_score
                    words = (word,) + tail
                    if words not in candidates or score > candidates[words]:
                        candidates[words] = score
            order = sorted(candidates, key=lambda w: (-candidates[w], w))[:self.top]
            best[start] = tuple((candidates[w], w) for w in order)
        return best[0]


@dataclass(frozen=True)
class Step:
    node: tuple
    cells: tuple
    key: tuple
    runes: tuple


@dataclass(frozen=True)
class Reading:
    score: float
    blocks: tuple
    steps: tuple


def best_distinct(items, top):
    """Keep K distinct block-text sequences with one witness per sequence."""
    by_text = {}
    for item in items:
        prev = by_text.get(item.blocks)
        if prev is None or item.score > prev.score:
            by_text[item.blocks] = item
    return sorted(by_text.values(), key=lambda x: (-x.score, x.blocks))[:top]


def add_paths(target, parents, choices, top):
    variants = (Reading(p.score + s, p.blocks + (words,), p.steps + (step,))
                for p in parents for s, words, step in choices)
    target[:] = best_distinct((*target, *variants), top)


def block_choices(grid, english, node, cells, keys):
    # Distinct histories may share future geometry. Carry the exact alignment
    # as an output witness, never as a substitute for the physical source node.
    seen = set()
    for key in keys:
        code = decrypt(grid, cells, key)
        if code not in seen:
            seen.add(code)
            step = Step(node, cells, key, code)
            for score, words in english.readings(code):
                yield score, words, step


@dataclass
class Result:
    readings: list
    terminal_states: Counter
    last_depth: int
    exhausted: bool
    seeds: int


def solve(geometry, english, opening='free', max_depth=128, blocks=None,
          all_lengths=False, progress=False, *, on_depth=None):
    """Layered, exhaustive geometry search. K limits text copies, never states.

    Future constraints depend only on State. For identical states a discarded
    (K+1)-st distinct text prefix has K better distinct competitors to which
    every legal suffix can also be appended. The same argument applies to the
    rune-boundary word segmentation. No beam width or early score pruning.

    When provided, on_depth receives the top K readings at each reached layer.
    """
    grid = geometry.grid
    top = english.top
    frontier = defaultdict(list)
    empty = [Reading(0.0, (), ())]
    for state, key in geometry.openings(opening, english):
        choices = list(block_choices(grid, english, state.node, state.cells, (key,)))
        if choices:
            add_paths(frontier[state], empty, choices, top)
    seed_count = len(frontier)
    best, terminal_counts = [], Counter()
    deepest_terminal = 0
    depth = 0
    while frontier:
        depth += 1
        if progress:
            print(f'Block {depth}: {len(frontier)} states.', file=sys.stderr, flush=True)
        if on_depth is not None:
            readings = chain.from_iterable(frontier.values())
            on_depth(depth, best_distinct(readings, top))
        following = defaultdict(list)
        for current, histories in frontier.items():
            phase = geometry.next_phase(current)
            candidates = geometry.through25(current, phase)
            if blocks == depth:  # Exact requested depth; still enforce the geometric stop.
                is_terminal = next(candidates, None) is None
            else:
                is_terminal = True
                for node, cells, keys in candidates:
                    is_terminal = False
                    keys = geometry.final_keys(current, node, cells, keys)
                    if not keys:
                        continue
                    choices = list(block_choices(grid, english, node, cells, keys))
                    if choices:
                        child = State(node, cells, current.cells[0], *phase)
                        add_paths(following[child], histories, choices, top)
            if is_terminal:
                terminal_counts[depth] += 1
                if blocks is not None and depth != blocks:
                    continue
                if depth > deepest_terminal and not all_lengths:
                    best = []
                deepest_terminal = depth
                best = best_distinct((*best, *histories), top)
        if blocks == depth or not following:
            return Result(best, terminal_counts, depth, True, seed_count)
        if depth == max_depth:
            return Result(best, terminal_counts, depth, False, seed_count)
        frontier = following
    return Result(best, terminal_counts, depth, True, seed_count)


def print_readings(readings, trace):
    for rank, reading in enumerate(readings, 1):
        print(f'#{rank}  score={reading.score:.6f}  blocks={len(reading.blocks)}  '
              f'runes={sum(len(s.runes) for s in reading.steps)}')
        print(' '.join(' '.join(w) for w in reading.blocks).upper())
        print(' | '.join(' '.join(w) for w in reading.blocks).upper(), end='\n\n')
    if trace:
        reading = readings[0]
        for i, (step, words) in enumerate(zip(reading.steps, reading.blocks), 1):
            print(f'{i:02}  {" ".join(words).upper():14}  node={step.node}  '
                  f'cells={step.cells}  key={step.key}  runes={step.runes}')


def choose_opening():
    print('Opening search mode', file=sys.stderr)
    print('  1. Full search (about 2 minutes on 27x27)', file=sys.stderr)
    print('  2. Short search with phi(h) or phi(h) + phi(phi(h)) '
          '(about 1 second on 27x27)', file=sys.stderr)
    print('  0. Exit', file=sys.stderr)
    while True:
        print('Type 1 or 2 to start, or 0 to exit, then press Enter: ',
              end='', file=sys.stderr, flush=True)
        choice = input().strip()
        if choice in ('1', '2'):
            return 'short' if choice == '2' else 'free'
        if choice == '0':
            return None
        print('Error: Invalid choice. Please enter 1, 2, or 0.', file=sys.stderr)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Search routes under rules 00–27 and print the English readings with the highest frequency scores.')
    parser.add_argument('matrix', help='rectangular matrix in TXT, CSV, JSON, or "-" for stdin')
    parser.add_argument('--top', type=int, help='maximum readings per ranking (5 by default, 3 with --by-depth)')
    parser.add_argument('--opening', choices=('free', 'short', 'scan', 'heading'),
                        help='skip the menu and choose free (full), short (both totient offsets), '
                             'scan (original offset), or heading; non-interactive default is free')
    parser.add_argument('--max-depth', type=int, default=128, help='depth limit to prevent an endless search (128)')
    choice = parser.add_mutually_exclusive_group()
    choice.add_argument('--blocks', type=int, help='search only for geometrically complete routes of exactly N blocks')
    choice.add_argument('--all-lengths', action='store_true', help='compare completed routes of all lengths using the same frequency score')
    choice.add_argument('--by-depth', action='store_true', help='rank all readings separately at each reached depth')
    parser.add_argument('--trace', action='store_true', help='show coordinates, keys, and runes for the top reading in each ranking')
    parser.add_argument('--progress', action='store_true', help='print the number of states in each layer to stderr')
    parser.add_argument('--lexicon', type=Path, default=Path(__file__).resolve().parent / 'data/english.tsv.gz',
                        help='English words and frequency counts in TXT/TSV or GZIP format')
    args = parser.parse_args(argv)
    top = args.top if args.top is not None else (3 if args.by_depth else 5)
    if top < 1 or args.max_depth < 1 or (args.blocks is not None and args.blocks < 1):
        parser.error('top, max-depth, and blocks must be positive.')
    if args.blocks is not None and args.blocks > args.max_depth:
        parser.error('blocks exceeds max-depth. Increase --max-depth.')

    opening = args.opening
    if opening is None:
        opening = 'free'
        if args.matrix != '-' and sys.stdin.isatty():
            try:
                opening = choose_opening()
            except EOFError:
                parser.exit(2, '\nError: no opening mode selected.\n')
            except KeyboardInterrupt:
                parser.exit(130, '\n')
            if opening is None:
                return 0

    def show_depth(depth, readings):
        print(f'Depth {depth}')
        print_readings(readings, args.trace)

    try:
        data = sys.stdin.read() if args.matrix == '-' else Path(args.matrix).read_text(encoding='utf-8-sig')
        geo = Geometry(read_matrix(data))
        english = English.from_file(args.lexicon, top)
        result = solve(geo, english, opening, args.max_depth, args.blocks,
                       args.all_lengths, args.progress, on_depth=show_depth if args.by_depth else None)
    except (OSError, EOFError, ValueError, zlib.error) as error:
        parser.exit(2, f'Error: {error}\n')
    if not result.exhausted:
        print(f'Depth limit {args.max_depth} reached with active branches remaining. Search incomplete. '
              'Increase --max-depth.', file=sys.stderr)
    found_readings = result.seeds > 0 if args.by_depth else bool(result.readings)
    if not found_readings:
        kind = 'readings' if args.by_depth else 'completed readings'
        print(f'No {kind} found under the specified conditions.')
        return 3 if result.exhausted else 4
    if not args.by_depth:
        print_readings(result.readings, args.trace)
    print(f'Admissible openings with words: {result.seeds}. '
          f'Last layer explored: {result.last_depth}.')
    print('Terminal states by length (blocks → states): ' +
          ', '.join(f'{d} → {n}' for d, n in sorted(result.terminal_states.items())))
    return 0 if result.exhausted else 4


if __name__ == '__main__':
    sys.exit(main())
