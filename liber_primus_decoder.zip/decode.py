#!/usr/bin/env python3
"""Matrix-only search for the Liber Primus 27×27 project. Python >=3.9.

Numbered comments refer to Start-reading-here/00..27 of the project.
Geometry uses 1-based (row, column); the four address slots are 0/90/180/270°.
No documents, route coordinates, example words or expected lengths are read.
"""
import argparse
import gzip
import json
import math
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

SIZE = 27
LIMIT = 7
RUNES = "F U/V TH O R C/K G W H N I J EO P X S/Z T B E M L NG/ING OE D A AE Y IA/IO EA".split()
LABELS = tuple(tuple(r.lower().split('/')) for r in RUNES)
PRIMES = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47,
          53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109)
AXES = ((0, 1), (1, 1), (1, 0), (1, -1))  # H, NW-SE, V, NE-SW
DIRECTIONS = AXES + tuple((-r, -c) for r, c in AXES)
GLYPHS = "ᚠᚢᚦᚩᚱᚳᚷᚹᚻᚾᛁᛄᛇᛈᛉᛋᛏᛒᛖᛗᛚᛝᛟᛞᚪᚫᚣᛡᛠ"
RUNE_INDEX = {str(i): i for i in range(29)}
for i, label in enumerate(RUNES):
    for token in (label, *label.split('/'), GLYPHS[i]):
        RUNE_INDEX[token] = i
RUNE_INDEX.update({'ᛄ': 11, 'ᛃ': 11, 'ᛂ': 11, 'ᛊ': 15, 'ᛜ': 21})


def read_matrix(data):
    """Read 27 rows of 27 integers or rune labels, in plain text, CSV or JSON."""
    data = data.lstrip('\ufeff').strip()
    if data.startswith('['):
        rows = json.loads(data)
    else:
        rows = []
        for line in data.splitlines():
            line = line.strip()
            if not line:
                continue
            if re.search(r'(^|[,;])\s*[,;]|[,;]$', line):
                raise ValueError(f'Row {len(rows) + 1} contains an empty cell.')
            tokens = re.split(r'[\s,;]+', line)
            if len(tokens) == 1 and all(c in RUNE_INDEX and ord(c) > 127 for c in tokens[0]):
                tokens = list(tokens[0])
            rows.append(tokens)
    if not isinstance(rows, list) or len(rows) != SIZE:
        raise ValueError('The matrix must contain exactly 27 rows.')
    grid = {}
    for row, entries in enumerate(rows, 1):
        if not isinstance(entries, list) or len(entries) != SIZE:
            raise ValueError(f'Row {row} must contain 27 cells.')
        for col, entry in enumerate(entries, 1):
            token = str(entry).strip().upper()
            if token not in RUNE_INDEX:
                raise ValueError(f'Cell ({row},{col}) contains an unknown rune {entry!r}.')
            grid[row, col] = RUNE_INDEX[token]
    return grid


def factors(n):
    if n <= 0:
        raise ValueError('The argument must be positive.')
    p = 2
    while p * p <= n:
        if n % p == 0:
            exponent = 0
            while n % p == 0:
                n //= p
                exponent += 1
            yield p, exponent
        p += 1
    if n > 1:
        yield n, 1


@lru_cache(None)
def phi(n):
    result = n
    for prime, _ in factors(n):
        result -= result // prime
    return result


@lru_cache(None)
def mu(n):
    sign = 1
    for _, exponent in factors(n):
        if exponent > 1:
            return 0
        sign = -sign
    return sign


def rotations(cell):
    row, col = cell
    flat = SIZE * (row - 1) + col
    quarter = SIZE * (col - 1) + 28 - row
    return flat, quarter, 730 - flat, 730 - quarter


def distance(a, b):
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def leftmost(cells):
    return min(cells, key=lambda point: (point[1], -point[0]))


def ray_offset(a, b):
    dr, dc = abs(a[0] - b[0]), abs(a[1] - b[1])
    return min(dr, dc, abs(dr - dc))


def signature(key):
    return tuple(mu(phi(i)) for i in key)


def aligned(key, phase):
    return key[phase:] + key[:phase]


def decrypt(grid, cells, key):
    return tuple((grid[c] - key[i % 3]) % 29 for i, c in enumerate(cells))


@dataclass(frozen=True)
class State:
    node: tuple
    cells: tuple
    previous_start: tuple
    total: int
    outer: int
    phase: int


def key_index(grid):
    """00, 01, 07, 13–15. Both source directions and center operations."""
    groups = defaultdict(lambda: defaultdict(set))
    for row, col in grid:
        for axis, (dr, dc) in enumerate(AXES):
            for radius in range(1, 14):
                u = row - radius * dr, col - radius * dc
                z = row + radius * dr, col + radius * dc
                if u not in grid or z not in grid:
                    break
                node = (u, (row, col), z)
                first, middle, last = (grid[c] for c in node)
                if min(first, middle, last) == 0:
                    continue
                for a, c in {(first, last), (last, first)}:
                    for b in {middle, phi(middle)}:
                        key = a, b, c
                        sig = signature(key)
                        if sig[0] != sig[2] or sig[0] < 0:
                            continue
                        group = axis, radius % 2, row % 2, col % 2, a == c, sig
                        groups[group][node].add(aligned(key, sum(sig) % 3))
    return {g: [(n, tuple(sorted(keys))) for n, keys in entries.items()]
            for g, entries in groups.items()}


def segment_index(grid):
    """02, 03, 05, 08, 09. All eight directions and lengths 2 through 27."""
    groups = defaultdict(lambda: defaultdict(list))
    for start in grid:
        for dr, dc in DIRECTIONS:
            axis = 'H' if dr == 0 else 'V' if dc == 0 else 'D'
            cells = [start]
            for span in range(1, SIZE):
                end = start[0] + span * dr, start[1] + span * dc
                if end not in grid:
                    break
                cells.append(end)
                left = leftmost((start, end))
                group = axis, start == left, end[0] % 2, left[0] % 2, left[1] % 2
                groups[group][start].append((tuple(cells), end, left))
    return groups


class Geometry:
    def __init__(self, grid):
        self.grid = grid
        self.rot = {c: rotations(c) for c in grid}
        self.keys = key_index(grid)
        self.segments = segment_index(grid)

    def openings(self, mode, english):
        """Opening convention external to 00–27. Discover, decrypt, then segment.

        Scan all positive adjacent horizontal triples in left-to-right order;
        apply the documented double-totient offset and allow row-major carry.
        Try all whole-word lengths through the last matrix cell.
        Optional heading mode narrows the origins.
        """
        for row, col in self.grid:
            node = (row, col - 1), (row, col), (row, col + 1)
            if node[0] not in self.grid or node[2] not in self.grid:
                continue
            if mode == 'heading' and (col != phi(row) or row - col != 1
                                      or self.grid[node[0]] != row + col):
                continue
            a, h, c = (self.grid[point] for point in node)
            if min(a, h, c) == 0:
                continue
            key = a, phi(h), c
            if signature(key) != (0, 0, 0):   # Report 01 initial state
                continue
            first = self.rot[node[0]][0] + phi(h) + phi(phi(h))
            cells = tuple((pos // SIZE + 1, pos % SIZE + 1)
                          for pos in range(first - 1, SIZE**2))
            for length in english.prefix_lengths(decrypt(self.grid, cells, key)):
                ordered = cells[:length]
                if length >= 2 and mu(self.rot[leftmost(ordered)][1]) >= 0:
                    yield State(node, ordered, ordered[0], 0, 0, 0), key

    def next_phase(self, state):
        # 01 and 11. Mode and offset use S before this transition.
        mode = (state.total // LIMIT) % 4
        slot = 2 if mode in (1, 2) else 0
        phase = (int(mode in (0, 2)) + sum(mu(self.rot[c][slot]) for c in state.cells)) % 3
        outer = (state.outer + mu(self.rot[leftmost(state.cells)][1])) % 2
        return state.total + phase, outer, phase

    def key_forecast(self, state, phase_state):
        # Physical extremes are always in row, then column, order.
        u, m, z = state.node
        b, e, l = state.cells[0], state.cells[-1], leftmost(state.cells)
        M, Z, B, E, L = (self.rot[c] for c in (m, z, b, e, l))
        _, outer, phase = phase_state
        group_bit = (mu(M[1] + Z[2]) < 0) == (mu(L[1] + Z[2]) < 0)  # 13
        gp = sum(PRIMES[self.grid[c]] for c in state.node)
        diagonal = (mu(math.gcd(M[1], Z[3])) < 0) ^ (mu(gp) > 0) ^ (mu(M[0] + Z[3]) != 0)
        axis = 2 * group_bit + diagonal  # 14
        radius = ((sum(m) + sum(b)) % 2) ^ (mu(math.gcd(Z[2], L[2])) < 0) ^ (mu(B[1] + E[1]) > 0)
        row = (1 + b[1] + e[0] + m[0] + mu(B[2])) % 2  # 04
        col = (1 + b[0] + e[0] + m[0]) % 2
        mirror = distance(z, l) % 3 != 2  # 07
        sig = (outer, (phase - 2 * outer + 1) % 3 - 1, outer)
        return (axis, radius, row, col, mirror, sig)

    def segments_after(self, state, center_row, next_total):
        u, m, z = state.node
        b, e, l = state.cells[0], state.cells[-1], leftmost(state.cells)
        U, M, Z, B, E, L = (self.rot[c] for c in (u, m, z, b, e, l))
        score = mu(B[2] + M[0]) + mu(math.gcd(E[1], E[2]))  # 03
        axis = 'H' if score == 0 else 'V' if score > 0 else 'D'
        left_first = (mu(E[3]) + phi(self.grid[m])) % 2  # 02
        end_row = (1 + state.phase + mu(M[2])) % 2  # 05
        left_row = (center_row + 1 + state.phase + mu(m[0])) % 2
        turn = (2, 3, 0)[state.phase]
        mirror = self.grid[u] == self.grid[z]
        left_col = (b[0] + sum(mu(self.rot[c][1]) for c in state.cells) + mirror + mu(M[turn])) % 2  # 09
        group = axis, bool(left_first), end_row, left_row, left_col
        q = mu(E[0]) == mu(E[3]) == 0  # 06
        required_offset = int(q and not (mu(B[0]) == mu(B[1]) == 0))  # 12
        sign = -1 if (next_total // LIMIT) % 4 in (1, 2) else 1  # 02 next block's mode
        # 18. The predicted endpoint sector, endpoint sign and start side.
        vertical = (mu(math.gcd(M[2], L[3])) < 0) ^ (mu(Z[3] + B[2]) > 0) ^ (mu(math.gcd(M[3], L[2])) < 0)
        negative = (mu(math.gcd(M[2], L[0])) == 0) ^ (mu(math.gcd(M[1], B[1])) == 0) ^ (mu(math.gcd(M[2], E[0])) == 0)
        right = (mu(math.gcd(U[1], E[0])) == 0) ^ (mu(math.gcd(U[0], B[2])) < 0) ^ bool((E[3] // 4) % 2)
        # 19. First block uses its own start as its predecessor.
        start_xor = B[2] ^ self.rot[state.previous_start][2]
        near = (start_xor % LIMIT == 0) == (mu(U[0] + E[0]) < 0)
        for start, segments in self.segments.get(group, {}).items():
            if (start[1] > b[1]) != right or ray_offset(l, start) != required_offset:
                continue
            if (distance(b, start) <= LIMIT) != near or (distance(l, start) <= LIMIT) != near:
                continue
            if abs(start[1] - (28 - z[1])) > abs(start[0] - (28 - b[0])) + LIMIT:  # 25
                continue
            for cells, end, left in segments:
                if (mu(self.rot[end][0]) < 0) != negative or mu(self.rot[left][1]) * sign < 0:
                    continue
                if (abs(end[0] - u[0]) >= abs(end[1] - u[1])) == vertical:
                    yield cells, start, end, left

    def through25(self, state, next_phase):
        """Yield all legal geometric successors through 25, before the word test."""
        next_total, _, phase = next_phase
        if phase == 2 and state.total % LIMIT == 6:  # 11, no skipped multiple of 7
            return
        u, m, _ = state.node
        b, e, l = state.cells[0], state.cells[-1], leftmost(state.cells)
        U, M, B, E, L = (self.rot[c] for c in (u, m, b, e, l))
        group = self.key_forecast(state, next_phase)
        extreme_bit = (math.gcd(B[3], L[1]) % 3 == 0) ^ (mu(M[3] + E[3]) > 0)  # 23
        keys = []
        for node, aligned_keys in self.keys.get(group, ()):
            xor = M[3] ^ node[1][1]  # 17. Zero is admitted explicitly.
            if xor and mu(xor) > 0:
                continue
            if (mu(self.rot[node[0]][2]) > 0) == extreme_bit:
                keys.append((node, aligned_keys))
        if not keys:
            return
        xor = U[2] ^ M[3]
        mod_seven = bool(xor and mu(xor) < 0) ^ (mu(math.gcd(B[0], B[3])) == 0)  # 24
        bounded = distance(u, e) <= LIMIT  # 21
        for cells, start, end, left in self.segments_after(state, group[2], next_total):
            B2, E2, L2 = (self.rot[c] for c in (start, end, left))
            for node, aligned_keys in keys:
                center = node[1]
                M2 = self.rot[center]
                if ((M2[0] + L2[2]) % LIMIT == 0) != mod_seven:
                    continue
                if bounded and distance(node[0], center) + len(cells) - 1 > LIMIT:
                    continue
                if max(math.gcd(M2[0], B2[0]), math.gcd(M2[2], B2[0])) > LIMIT:  # 20
                    continue
                if any(mu(math.gcd(x, y)) == 0 for x, y in (
                    (M2[0], B2[0]), (M2[0], L2[0]), (M2[1], E2[3]), (M2[0], E2[2])
                )):  # 10, all four squarefree-GCD clauses
                    continue
                if min(abs(c[1] - center[1]) for c in cells) <= LIMIT:
                    if not any(max(distance(k, start), distance(k, left)) <= LIMIT for k in node):
                        continue   # 22, one and the same key cell must cover both points
                yield node, cells, aligned_keys

    def final_keys(self, state, node, cells, keys):
        """26 and both implications in 27, on the very same key alignment."""
        u, m, z = state.node
        b, e = state.cells[0], state.cells[-1]
        manhattan = abs(u[0] - m[0]) + abs(u[1] - m[1])
        forecast = (manhattan <= 13) ^ (abs(m[1] - e[1]) <= 13)
        if (distance(node[1], cells[0]) % LIMIT == 0) != forecast:
            return ()
        use_a = distance(z, b) % 3 != 0
        use_b = math.gcd(self.rot[u][2], self.rot[m][0]) > 1
        last_cipher = self.grid[cells[-1]]
        last_slot = (len(cells) - 1) % 3
        return tuple(key for key in keys
                     if (not use_a or abs(last_cipher - key[last_slot]) % 3 != 1)
                     and (not use_b or abs(key[0] - last_cipher) > LIMIT))


class English:
    """Exact top-K within each block. A trie advances one complete rune at a time."""
    def __init__(self, counts, top):
        if not counts or top < 1:
            raise ValueError('The dictionary must be nonempty and top must be positive.')
        self.top = top
        norm = sum(counts.values()) + len(counts)  # add-one smoothing on admitted vocabulary
        self.logp = {w: math.log10((count + 1) / norm) for w, count in counts.items()}
        self.trie = {}
        for word in counts:
            branch = self.trie
            for ch in word:
                branch = branch.setdefault(ch, {})
            branch[''] = word
        self.readings = lru_cache(maxsize=32768)(self._readings)

    @classmethod
    def from_file(cls, filename, top):
        counts = {}
        opener = gzip.open if filename.suffix == '.gz' else open
        with opener(filename, 'rt', encoding='utf-8') as file:
            for lineno, line in enumerate(file, 1):
                word, count = line.split()
                if not re.fullmatch('[a-z]+', word) or int(count) < 0 or word in counts:
                    raise ValueError(f'Invalid frequency dictionary entry on line {lineno}.')
                if len(word) > 1 or word in ('i', 'a'):
                    counts[word] = int(count)
        return cls(counts, top)

    def _matches(self, code, start):
        pending = defaultdict(list, {start: [self.trie]})

        for pos in range(start, len(code)):
            branches = pending.pop(pos, ())
            if not branches:
                if not pending:
                    break
                continue

            choices = [(pos + 1, label) for label in LABELS[code[pos]]]
            # LP1 page 16 spells QU with the two runes C/K and W.
            if code[pos:pos + 2] == (5, 7):
                choices.append((pos + 2, 'qu'))

            for branch in branches:
                for stop, label in choices:
                    child = branch
                    for char in label:
                        child = child.get(char)
                        if child is None:
                            break
                    if child is not None:
                        pending[stop].append(child)
                        if '' in child:
                            yield stop, child['']

    def prefix_lengths(self, code):
        """Every prefix coverable by complete words, including after a row wrap."""
        reachable = {0}
        for start in range(len(code)):
            if start in reachable:
                reachable.update(stop for stop, _ in self._matches(code, start))
        return sorted(reachable - {0})

    def _readings(self, code):
        # 16. best[i] covers every rune from i to the end; no cross-block words.
        best = [()] * (len(code) + 1)
        best[-1] = ((0.0, ()),)
        for start in range(len(code) - 1, -1, -1):
            candidates = {}
            for stop, word in self._matches(code, start):
                for tail_score, tail in best[stop]:
                    score = self.logp[word] + tail_score
                    words = (word,) + tail
                    if words not in candidates or score > candidates[words]:
                        candidates[words] = score
            order = sorted(candidates, key=lambda w: (-candidates[w], w))[:self.top]
            best[start] = tuple((candidates[w], w) for w in order)
        return best[0]


@dataclass(frozen=True)
class Step:
    node: tuple
    cells: tuple
    key: tuple
    runes: tuple


@dataclass(frozen=True)
class Reading:
    score: float
    blocks: tuple
    steps: tuple


def best_distinct(items, top):
    """Keep K distinct block-text sequences with one witness per sequence."""
    by_text = {}
    for item in items:
        prev = by_text.get(item.blocks)
        if prev is None or item.score > prev.score:
            by_text[item.blocks] = item
    return sorted(by_text.values(), key=lambda x: (-x.score, x.blocks))[:top]


def add_paths(target, parents, choices, top):
    variants = (Reading(p.score + s, p.blocks + (words,), p.steps + (step,))
                for p in parents for s, words, step in choices)
    target[:] = best_distinct((*target, *variants), top)


def block_choices(grid, english, node, cells, keys):
    # Distinct histories may share future geometry. Carry the exact alignment
    # as an output witness, never as a substitute for the physical source node.
    seen = set()
    for key in keys:
        code = decrypt(grid, cells, key)
        if code not in seen:
            seen.add(code)
            step = Step(node, cells, key, code)
            for score, words in english.readings(code):
                yield score, words, step


@dataclass
class Result:
    readings: list
    terminal_states: Counter
    last_depth: int
    exhausted: bool
    seeds: int


def solve(geometry, english, opening='scan', max_depth=128, blocks=None,
          all_lengths=False, progress=False):
    """Layered, exhaustive geometry search. K limits text copies, never states.

    Future constraints depend only on State. For identical states a discarded
    (K+1)-st distinct text prefix has K better distinct competitors to which
    every legal suffix can also be appended. The same argument applies to the
    rune-boundary word segmentation. No beam width or early score pruning.
    """
    grid = geometry.grid
    top = english.top
    frontier = defaultdict(list)
    empty = [Reading(0.0, (), ())]
    for state, key in geometry.openings(opening, english):
        choices = list(block_choices(grid, english, state.node, state.cells, (key,)))
        if choices:
            add_paths(frontier[state], empty, choices, top)
    seed_count = len(frontier)
    best, terminal_counts = [], Counter()
    deepest_terminal = 0
    depth = 0
    while frontier:
        depth += 1
        if progress:
            print(f'Block {depth}: {len(frontier)} states.', file=sys.stderr, flush=True)
        following = defaultdict(list)
        for current, histories in frontier.items():
            phase = geometry.next_phase(current)
            candidates = geometry.through25(current, phase)
            if blocks == depth:  # Exact requested depth; still enforce the geometric stop.
                is_terminal = next(candidates, None) is None
            else:
                is_terminal = True
                for node, cells, keys in candidates:
                    is_terminal = False
                    keys = geometry.final_keys(current, node, cells, keys)
                    if not keys:
                        continue
                    choices = list(block_choices(grid, english, node, cells, keys))
                    if choices:
                        child = State(node, cells, current.cells[0], *phase)
                        add_paths(following[child], histories, choices, top)
            if is_terminal:
                terminal_counts[depth] += 1
                if blocks is not None and depth != blocks:
                    continue
                if depth > deepest_terminal and not all_lengths:
                    best = []
                deepest_terminal = depth
                best = best_distinct((*best, *histories), top)
        if blocks == depth or not following:
            return Result(best, terminal_counts, depth, True, seed_count)
        if depth == max_depth:
            return Result(best, terminal_counts, depth, False, seed_count)
        frontier = following
    return Result(best, terminal_counts, depth, True, seed_count)


def main(argv=None):
    parser = argparse.ArgumentParser(description='Search routes under rules 00–27 and print the English readings with the highest frequency scores.')
    parser.add_argument('matrix', help='TXT, CSV, JSON, or "-" for stdin')
    parser.add_argument('--top', type=int, default=5, help='number of distinct readings to display (5)')
    parser.add_argument('--opening', choices=('scan', 'heading'), default='scan',
                        help='scan all adjacent horizontal openings or use the heading hypothesis')
    parser.add_argument('--max-depth', type=int, default=128, help='depth limit to prevent an endless search (128)')
    choice = parser.add_mutually_exclusive_group()
    choice.add_argument('--blocks', type=int, help='search only for geometrically complete routes of exactly N blocks')
    choice.add_argument('--all-lengths', action='store_true', help='compare completed routes of all lengths using the same frequency score')
    parser.add_argument('--trace', action='store_true', help='show every coordinate, key, and rune of the highest-scoring route')
    parser.add_argument('--progress', action='store_true', help='print the number of states in each layer to stderr')
    parser.add_argument('--lexicon', type=Path, default=Path(__file__).resolve().parent / 'data/english.tsv.gz',
                        help='English words and frequency counts in TXT/TSV or GZIP format')
    args = parser.parse_args(argv)
    if args.top < 1 or args.max_depth < 1 or (args.blocks is not None and args.blocks < 1):
        parser.error('top, max-depth, and blocks must be positive.')
    if args.blocks is not None and args.blocks > args.max_depth:
        parser.error('blocks exceeds max-depth. Increase --max-depth.')
    try:
        data = sys.stdin.read() if args.matrix == '-' else Path(args.matrix).read_text(encoding='utf-8-sig')
        geo = Geometry(read_matrix(data))
        english = English.from_file(args.lexicon, args.top)
        result = solve(geo, english, args.opening, args.max_depth, args.blocks, args.all_lengths, args.progress)
    except (OSError, UnicodeError, ValueError) as error:
        parser.exit(2, f'Error: {error}\n')
    if not result.exhausted:
        print(f'Depth limit {args.max_depth} reached with active branches remaining. Search incomplete. '
              'Increase --max-depth.', file=sys.stderr)
    if not result.readings:
        print('No completed readings found under the specified conditions.')
        return 3 if result.exhausted else 4
    for rank, reading in enumerate(result.readings, 1):
        print(f'#{rank}  score={reading.score:.6f}  blocks={len(reading.blocks)}  '
              f'runes={sum(len(s.runes) for s in reading.steps)}')
        print(' '.join(' '.join(w) for w in reading.blocks).upper())
        print(' | '.join(' '.join(w) for w in reading.blocks).upper(), end='\n\n')
    if args.trace:
        reading = result.readings[0]
        for i, (step, words) in enumerate(zip(reading.steps, reading.blocks), 1):
            print(f'{i:02}  {" ".join(words).upper():14}  node={step.node}  '
                  f'cells={step.cells}  key={step.key}  runes={step.runes}')
    print(f'Admissible openings with words: {result.seeds}. '
          f'Last layer explored: {result.last_depth}.')
    print('Terminal states by length (blocks → states): ' +
          ', '.join(f'{d} → {n}' for d, n in sorted(result.terminal_states.items())))
    return 0 if result.exhausted else 4


if __name__ == '__main__':
    sys.exit(main())
