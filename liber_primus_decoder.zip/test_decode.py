"""Run with python3 -m unittest -v in the extracted directory."""
import gzip
import io
import itertools
import json
import math
import re
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from decode import (English, Geometry, GLYPHS, LABELS, RUNES, State, aligned,
                    decrypt, main, mu, phi, read_matrix, rotations, signature, solve)

HERE = Path(__file__).resolve().parent


class ArithmeticTests(unittest.TestCase):
    def test_arithmetic_independent_definitions(self):
        for n in range(1, 1459):
            self.assertEqual(phi(n), sum(math.gcd(n, a) == 1 for a in range(1, n + 1)))
            self.assertEqual(sum(mu(d) for d in range(1, n + 1) if n % d == 0), int(n == 1))
        for f in (mu, phi):
            with self.assertRaises(ValueError):
                f(0)

    def test_addresses_and_decryption(self):
        for r, c in itertools.product(range(1, 28), repeat=2):
            turns = [(r, c), (c, 28-r), (28-r, 28-c), (28-c, r)]
            self.assertEqual(rotations((r, c), 27, 27), tuple(27*(i-1)+j for i, j in turns))
        key = (14, phi(22), 14)
        sig = signature(key)
        self.assertEqual(sig, (1, 0, 1))
        key = aligned(key, sum(sig) % 3)
        vector = (21, 13, 12, 3, 18)
        self.assertEqual(decrypt(dict(enumerate(vector)), range(5), key), (7, 28, 2, 18, 4))

    def test_input_forms_and_validation(self):
        rows = [[(r*27+c) % 29 for c in range(27)] for r in range(27)]
        expected = read_matrix(json.dumps(rows))
        csv = '\n'.join(','.join(RUNES[i] for i in row) for row in rows)
        glyphs = '\n'.join(''.join(GLYPHS[i] for i in row) for row in rows)
        self.assertEqual(read_matrix(csv), expected)
        self.assertEqual(read_matrix(glyphs), expected)
        for malformed in ([], [[]], [1, 2], [rows[0], rows[1][:-1]],
                          [[False]], [[29]]):
            with self.assertRaises(ValueError):
                read_matrix(json.dumps(malformed))

    def test_j_transcription_variant_and_empty_fields(self):
        line = 'ᛂ' + GLYPHS[0] * 26
        self.assertEqual(read_matrix('\n'.join([line] * 27))[1, 1], 11)
        valid = ','.join(['1'] * 27)
        for bad_row in (',' + valid, valid + ',',
                        ','.join(['1'] * 8 + [' '] + ['1'] * 19),
                        ';'.join(['1'] * 8 + [' '] + ['1'] * 19)):
            with self.subTest(row=bad_row):
                with self.assertRaisesRegex(ValueError, 'Row 2 contains an empty cell'):
                    read_matrix('\n'.join([valid, bad_row] + [valid] * 25))


class RectangularGeometryTests(unittest.TestCase):
    def test_nonsquare_rotations_against_rotated_rows(self):
        for height, width in ((1, 1), (1, 8), (8, 1), (3, 7), (7, 3), (20, 30)):
            with self.subTest(height=height, width=width):
                rows = [[(r, c) for c in range(1, width + 1)]
                        for r in range(1, height + 1)]
                addresses = []
                for _ in range(4):
                    addresses.append({cell: index for index, cell
                                      in enumerate(itertools.chain.from_iterable(rows), 1)})
                    rows = list(zip(*reversed(rows)))
                for cell in addresses[0]:
                    self.assertEqual(rotations(cell, height, width),
                                     tuple(turn[cell] for turn in addresses))

    def test_rectangular_opening_crosses_a_row_in_all_input_formats(self):
        rows = [[0, 17, 15, 17, 0, 0, 0],
                [0, 0, 0, 0, 0, 0, 7],
                [26, 0, 0, 0, 0, 0, 0]]
        inputs = (json.dumps(rows),
                  '\n'.join(','.join(RUNES[i] for i in row) for row in rows),
                  '\n'.join(''.join(GLYPHS[i] for i in row) for row in rows))
        for data in inputs:
            geometry = Geometry(read_matrix(data))
            self.assertEqual((geometry.height, geometry.width), (3, 7))
            result = solve(geometry, English({'me': 10}, 1), opening='scan')
            self.assertTrue(result.exhausted)
            self.assertEqual(result.seeds, 1)
            self.assertEqual(len(result.readings), 1)
            best = result.readings[0]
            self.assertEqual(best.blocks, (('me',),))
            self.assertEqual(best.steps[0].cells, ((2, 7), (3, 1)))

    def test_keys_and_segments_can_extend_past_old_limits(self):
        cases = ((3, 31, ((2, 1), (2, 16), (2, 31))),
                 (31, 3, ((1, 2), (16, 2), (31, 2))))
        for height, width, node in cases:
            with self.subTest(height=height, width=width):
                geometry = Geometry(read_matrix(json.dumps([[17] * width] * height)))
                keys = {key_node for group in geometry.keys.values() for key_node, _ in group}
                self.assertIn(node, keys)
                expected_cells = (tuple((2, c) for c in range(1, 32)) if width == 31
                                  else tuple((r, 2) for r in range(1, 32)))
                self.assertTrue(any(cells == expected_cells
                                    for group in geometry.segments.values()
                                    for cells, _, _ in group.get(node[0], ())))

    def test_free_opening_uses_its_own_phase_and_start(self):
        grid = read_matrix('[[1,5,1,0,0],[0,0,0,0,0],[0,23,19,0,0]]')
        geometry = Geometry(grid)
        english = English({'me': 10}, 1)
        node = ((1, 1), (1, 2), (1, 3))
        cells = ((3, 2), (3, 3))
        expected = (State(node, cells, cells[0], 1, 1, 1), (4, 1, 1))
        self.assertIn(expected, list(geometry.openings('free', english)))
        self.assertEqual(decrypt(grid, cells, expected[1]), (19, 18))
        self.assertEqual(list(geometry.openings('scan', english)), [])
        self.assertGreater(solve(geometry, english).seeds, 0)

    def test_short_opening_checks_both_totient_offsets(self):
        grid = read_matrix('[[0,17,15,17,0,0,0],[0,0,7,26,0,0,7],[26,0,0,0,0,0,0]]')
        geometry = Geometry(grid)
        english = English({'me': 10}, 1)
        starts = {state.cells for state, _ in geometry.openings('short', english)}
        self.assertEqual(starts, {((2, 3), (2, 4)), ((2, 7), (3, 1))})
        original = {state.cells for state, _ in geometry.openings('scan', english)}
        self.assertEqual(original, {((2, 7), (3, 1))})


class LanguageTests(unittest.TestCase):
    def test_invalid_lexicon_entries_identify_the_line(self):
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'custom.tsv'
            for invalid_line in ('extra 1 2', 'word NaN', 'word -1', 'word 3', 'z 1'):
                with self.subTest(entry=invalid_line):
                    path.write_text(f'word 2\nz 0\n{invalid_line}\n', encoding='utf-8')
                    with self.assertRaisesRegex(ValueError, 'frequency dictionary entry on line 3'):
                        English.from_file(path, 1)
            path.write_text('word 2\nz 0\n', encoding='utf-8')
            self.assertEqual(set(English.from_file(path, 1).logp), {'word'})

    def test_damaged_gzip_lexicon_uses_the_cli_error_code(self):
        compressed = gzip.compress(b'die 1\n', mtime=0)
        # The payload starts after the ten-byte gzip header. BTYPE=3 is invalid.
        invalid_block = bytes([compressed[10] | 0b110])
        damaged_crc = bytes([compressed[-8] ^ 0xff])
        corruptions = {
            'truncated trailer': compressed[:-8],
            'bad header': b'not gzip',
            'invalid block': compressed[:10] + invalid_block + compressed[11:],
            'bad checksum': compressed[:-8] + damaged_crc + compressed[-7:],
        }
        with TemporaryDirectory() as directory:
            path = Path(directory) / 'custom.tsv.gz'
            for case, damaged in corruptions.items():
                with self.subTest(case=case):
                    path.write_bytes(damaged)
                    stderr = io.StringIO()
                    with redirect_stderr(stderr), self.assertRaises(SystemExit) as error:
                        main([str(HERE / 'matrix.txt'), '--lexicon', str(path)])
                    self.assertEqual(error.exception.code, 2)
                    self.assertTrue(stderr.getvalue().startswith('Error: '))

    def test_qu_from_lp1(self):
        lexicon = English({'question': 100, 'cw': 1, 'qu': 1}, 10)
        runes = (5, 7, 18, 15, 16, 27, 9)
        self.assertIn(('question',), [words for _, words in lexicon.readings(runes)])
        self.assertFalse(lexicon.readings((5,) + runes[2:]))
        self.assertEqual(lexicon.prefix_lengths((5, 7)), [2])
        self.assertIn(('cw',), [words for _, words in lexicon.readings((5, 7))])

    def test_lp1_words_in_bundled_dictionary(self):
        lexicon = English.from_file(HERE/'data/english.tsv.gz', 10)
        for word in ('totient', 'primality', 'dont', 'widsom', 'beleive'):
            with self.subTest(word=word):
                self.assertIn(word, lexicon.logp)

    def test_ng_and_ing_share_one_rune(self):
        lex = English({'wing': 10, 'winging': 5, 'ing': 2, 'ng': 1}, 10)
        single_rune = {words for _, words in lex.readings((21,))}
        self.assertEqual(single_rune, {('ng',), ('ing',)})
        self.assertIn(('winging',), [words for _, words in lex.readings((7, 21, 21))])

    def test_rune_boundaries(self):
        lex = English({'a': 30, 'i': 20, 'ate': 12, 'at': 10, 'he': 8, 'the': 40}, 10)
        # A-TH-E can yield A THE. Splitting the TH rune to obtain AT HE is invalid.
        self.assertEqual([w for _, w in lex.readings((24, 2, 18))], [('a', 'the')])
        self.assertEqual(lex.prefix_lengths((24, 2, 18)), [1, 3])
        self.assertFalse(lex.readings((2,)))  # TH needs the next rune in this block.

    def test_top_k_against_full_enumeration(self):
        # Expand all alternate labels, then enumerate every mask of word boundaries.
        code = (24, 15, 10, 24, 15, 10)
        counts = {'a': 41, 'i': 23, 'as': 29, 'az': 9, 'si': 12, 'zi': 1,
                  'sia': 41, 'asi': 20, 'azia': 3, 'ia': 1}
        norm = sum(counts.values()) + len(counts)
        brute = {}
        for labels in itertools.product(*(LABELS[i] for i in code)):
            for mask in itertools.product((False, True), repeat=len(code)-1):
                words = [labels[0]]
                for cut, label in zip(mask, labels[1:]):
                    if cut:
                        words.append(label)
                    else:
                        words[-1] += label
                if all(w in counts for w in words):
                    brute[tuple(words)] = sum(math.log10((counts[w]+1)/norm) for w in words)
        self.assertGreater(len(brute), 5)
        for k in (1, 3, 7, 100):
            got = English(counts, k).readings(code)
            target = sorted(brute.values(), reverse=True)[:k]
            self.assertEqual(len(got), len(target))
            self.assertEqual(len({w for _, w in got}), len(got))
            for (score, words), wanted in zip(got, target):
                self.assertAlmostEqual(score, brute[words])
                self.assertAlmostEqual(score, wanted)

    def test_opening_can_cross_more_than_one_row(self):
        # No fixed initial block length. One valid rune-boundary word spans 30 cells.
        lex = English({'aa'*15: 3}, 1)
        self.assertEqual(lex.prefix_lengths((24,)*32), [30])


class SearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geometry = Geometry(read_matrix((HERE/'matrix.txt').read_text(encoding='utf-8')))
        cls.english = English.from_file(HERE/'data/english.tsv.gz', 5)

    def test_full_search_and_coordinate_witness(self):
        res = solve(self.geometry, self.english, opening='scan')
        self.assertTrue(res.exhausted)
        self.assertEqual((res.seeds, res.last_depth, res.terminal_states[39]), (36, 39, 2))
        self.assertEqual(len(res.readings), 5)
        self.assertTrue(all(a.score >= b.score for a, b in zip(res.readings, res.readings[1:])))
        best = res.readings[0]
        self.assertEqual(sum(len(s.runes) for s in best.steps), 118)
        self.assertEqual(len(best.blocks), 39)
        self.assertEqual(best.blocks[-1], ('die',))
        rival = res.readings[3]
        self.assertEqual(rival.blocks[-1], ('winging',))
        self.assertEqual(rival.steps[:-1], best.steps[:-1])
        self.assertEqual(rival.steps[-1].runes, (7, 21, 21))
        for step, words in zip(best.steps, best.blocks):
            self.assertEqual(decrypt(self.geometry.grid, step.cells, step.key), step.runes)
            self.assertIn(words, [w for _, w in self.english.readings(step.runes)])

    def test_free_opening_count_on_supplied_matrix(self):
        states = {state for state, _ in self.geometry.openings('free', self.english)}
        self.assertEqual(len(states), 87115)

    def test_short_search_returns_the_same_ranked_routes_as_original_scan(self):
        short = solve(self.geometry, self.english, opening='short')
        original = solve(self.geometry, self.english, opening='scan')
        self.assertTrue(short.exhausted)
        self.assertEqual((short.seeds, short.last_depth, short.terminal_states[39]), (64, 39, 2))
        self.assertEqual(short.readings, original.readings)

    def test_depth_limit_is_not_a_stop(self):
        one = solve(self.geometry, self.english, opening='scan', max_depth=1)
        self.assertFalse(one.exhausted)
        chosen = solve(self.geometry, self.english, opening='scan', blocks=1)
        self.assertTrue(chosen.exhausted)
        for reading in chosen.readings:
            step = reading.steps[0]
            state = State(step.node, step.cells, step.cells[0], 0, 0, 0)
            self.assertFalse(list(self.geometry.through25(state, self.geometry.next_phase(state))))

    def test_by_depth_cli_ranks_every_reached_layer(self):
        output = io.StringIO()
        with redirect_stdout(output):
            status = main([str(HERE / 'matrix.txt'), '--opening', 'scan', '--by-depth'])
        self.assertEqual(status, 0)

        groups = re.split(r'^Depth (\d+)\n', output.getvalue(), flags=re.MULTILINE)
        self.assertEqual(groups[1::2], [str(depth) for depth in range(1, 40)])
        for depth, group in zip(groups[1::2], groups[2::2]):
            with self.subTest(depth=depth):
                rows = re.findall(r'^#(\d+) +score=(-?[\d.]+) +blocks=(\d+)', group, re.MULTILINE)
                self.assertTrue(1 <= len(rows) <= 3)
                self.assertEqual([int(rank) for rank, _, _ in rows], list(range(1, len(rows) + 1)))
                self.assertTrue(all(blocks == depth for _, _, blocks in rows))
                scores = [float(score) for _, score, _ in rows]
                self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertIn('#3  score=', groups[2])
        self.assertIn('blocks=4', groups[8])  # Depth 4 has no terminal route on this matrix.
        self.assertTrue(groups[-1].splitlines()[1].endswith(' DIE'))

    def test_by_depth_cli_top_override_and_depth_limit(self):
        output, stderr = io.StringIO(), io.StringIO()
        with redirect_stdout(output), redirect_stderr(stderr):
            status = main([str(HERE / 'matrix.txt'), '--opening', 'scan',
                           '--by-depth', '--top', '1', '--max-depth', '4'])
        self.assertEqual(status, 4)
        self.assertIn('Depth limit 4 reached with active branches remaining.', stderr.getvalue())
        ranks = re.findall(r'^#(\d+) +score=.*? +blocks=(\d+)', output.getvalue(), re.MULTILINE)
        self.assertEqual(ranks, [('1', str(depth)) for depth in range(1, 5)])

    def test_same_matrix_changed_to_zero(self):
        zeros = Geometry(dict.fromkeys(self.geometry.grid, 0))
        answer = solve(zeros, self.english)
        self.assertTrue(answer.exhausted)
        self.assertEqual(answer.readings, [])


class OpeningMenuTests(unittest.TestCase):
    def test_terminal_menu_reprompts_and_dispatches_both_modes(self):
        choices = (('7\ninvalid\n\n2\n', 'short', 3), ('1\n', 'free', 0))
        for keys, mode, errors in choices:
            with self.subTest(keys=keys):
                stdin, stderr = io.StringIO(keys), io.StringIO()
                with (patch('sys.stdin', stdin), patch.object(stdin, 'isatty', return_value=True),
                      patch('decode.solve') as run, redirect_stdout(io.StringIO()), redirect_stderr(stderr)):
                    run.return_value.exhausted = True
                    run.return_value.readings = []
                    self.assertEqual(main([str(HERE / 'matrix.txt')]), 3)
                    self.assertEqual(run.call_args.args[2], mode)
                menu = stderr.getvalue()
                self.assertIn('about 2 minutes on 27x27', menu)
                self.assertIn('about 1 second on 27x27', menu)
                self.assertIn('0. Exit', menu)
                self.assertEqual(menu.count('Error: Invalid choice.'), errors)
                self.assertEqual(menu.count('then press Enter'), errors + 1)

    def test_zero_exits_before_reading_matrix(self):
        stdin = io.StringIO('0\n')
        with (patch('sys.stdin', stdin), patch.object(stdin, 'isatty', return_value=True),
              patch('decode.Path.read_text') as read_file, patch('decode.solve') as run,
              redirect_stdout(io.StringIO()), redirect_stderr(io.StringIO())):
            self.assertEqual(main([str(HERE / 'matrix.txt')]), 0)
        read_file.assert_not_called()
        run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
