"""Run with python3 -m unittest -v in the extracted directory."""
import itertools
import json
import math
import unittest
from pathlib import Path

from decode import (English, Geometry, GLYPHS, LABELS, RUNES, State, aligned,
                    decrypt, mu, phi, read_matrix, rotations, signature, solve)

HERE = Path(__file__).resolve().parent


class ArithmeticTests(unittest.TestCase):
    def test_arithmetic_independent_definitions(self):
        for n in range(1, 1459):
            self.assertEqual(phi(n), sum(math.gcd(n, a) == 1 for a in range(1, n + 1)))
            self.assertEqual(sum(mu(d) for d in range(1, n + 1) if n % d == 0), int(n == 1))
        for f in (mu, phi):
            with self.assertRaises(ValueError):
                f(0)

    def test_addresses_and_decryption(self):
        for r, c in itertools.product(range(1, 28), repeat=2):
            turns = [(r, c), (c, 28-r), (28-r, 28-c), (28-c, r)]
            self.assertEqual(rotations((r, c)), tuple(27*(i-1)+j for i, j in turns))
        key = (14, phi(22), 14)
        sig = signature(key)
        self.assertEqual(sig, (1, 0, 1))
        key = aligned(key, sum(sig) % 3)
        vector = (21, 13, 12, 3, 18)
        self.assertEqual(decrypt(dict(enumerate(vector)), range(5), key), (7, 28, 2, 18, 4))

    def test_input_forms_and_validation(self):
        rows = [[(r*27+c) % 29 for c in range(27)] for r in range(27)]
        expected = read_matrix(json.dumps(rows))
        csv = '\n'.join(','.join(RUNES[i] for i in row) for row in rows)
        glyphs = '\n'.join(''.join(GLYPHS[i] for i in row) for row in rows)
        self.assertEqual(read_matrix(csv), expected)
        self.assertEqual(read_matrix(glyphs), expected)
        for malformed in (rows[1:], [row[:-1] for row in rows],
                          [[False]*27]*27, [[29]*27]*27):
            with self.assertRaises(ValueError):
                read_matrix(json.dumps(malformed))


    def test_j_transcription_variant_and_empty_fields(self):
        line = 'ᛂ' + GLYPHS[0] * 26
        self.assertEqual(read_matrix('\n'.join([line] * 27))[1, 1], 11)
        valid = ','.join(['1'] * 27)
        for bad_row in (',' + valid, valid + ',',
                        ','.join(['1'] * 8 + [' '] + ['1'] * 19),
                        ';'.join(['1'] * 8 + [' '] + ['1'] * 19)):
            with self.subTest(row=bad_row):
                with self.assertRaisesRegex(ValueError, 'Row 2 contains an empty cell'):
                    read_matrix('\n'.join([valid, bad_row] + [valid] * 25))


class LanguageTests(unittest.TestCase):
    def test_qu_from_lp1(self):
        lexicon = English({'question': 100, 'cw': 1, 'qu': 1}, 10)
        runes = (5, 7, 18, 15, 16, 27, 9)
        self.assertIn(('question',), [words for _, words in lexicon.readings(runes)])
        self.assertFalse(lexicon.readings((5,) + runes[2:]))
        self.assertEqual(lexicon.prefix_lengths((5, 7)), [2])
        self.assertIn(('cw',), [words for _, words in lexicon.readings((5, 7))])

    def test_lp1_words_in_bundled_dictionary(self):
        lexicon = English.from_file(HERE/'data/english.tsv.gz', 10)
        for word in ('totient', 'primality', 'dont', 'widsom', 'beleive'):
            with self.subTest(word=word):
                self.assertIn(word, lexicon.logp)

    def test_ng_and_ing_share_one_rune(self):
        lex = English({'wing': 10, 'winging': 5, 'ing': 2, 'ng': 1}, 10)
        single_rune = {words for _, words in lex.readings((21,))}
        self.assertEqual(single_rune, {('ng',), ('ing',)})
        self.assertIn(('winging',), [words for _, words in lex.readings((7, 21, 21))])

    def test_rune_boundaries(self):
        lex = English({'a': 30, 'i': 20, 'ate': 12, 'at': 10, 'he': 8, 'the': 40}, 10)
        # A-TH-E can yield A THE. Splitting the TH rune to obtain AT HE is invalid.
        self.assertEqual([w for _, w in lex.readings((24, 2, 18))], [('a', 'the')])
        self.assertEqual(lex.prefix_lengths((24, 2, 18)), [1, 3])
        self.assertFalse(lex.readings((2,)))  # TH needs the next rune in this block.

    def test_top_k_against_full_enumeration(self):
        # Expand all alternate labels, then enumerate every mask of word boundaries.
        code = (24, 15, 10, 24, 15, 10)
        counts = {'a': 41, 'i': 23, 'as': 29, 'az': 9, 'si': 12, 'zi': 1,
                  'sia': 41, 'asi': 20, 'azia': 3, 'ia': 1}
        norm = sum(counts.values()) + len(counts)
        brute = {}
        for labels in itertools.product(*(LABELS[i] for i in code)):
            for mask in itertools.product((False, True), repeat=len(code)-1):
                words = [labels[0]]
                for cut, label in zip(mask, labels[1:]):
                    if cut:
                        words.append(label)
                    else:
                        words[-1] += label
                if all(w in counts for w in words):
                    brute[tuple(words)] = sum(math.log10((counts[w]+1)/norm) for w in words)
        self.assertGreater(len(brute), 5)
        for k in (1, 3, 7, 100):
            got = English(counts, k).readings(code)
            target = sorted(brute.values(), reverse=True)[:k]
            self.assertEqual(len(got), len(target))
            self.assertEqual(len({w for _, w in got}), len(got))
            for (score, words), wanted in zip(got, target):
                self.assertAlmostEqual(score, brute[words])
                self.assertAlmostEqual(score, wanted)

    def test_opening_can_cross_more_than_one_row(self):
        # No fixed initial block length. One valid rune-boundary word spans 30 cells.
        lex = English({'aa'*15: 3}, 1)
        self.assertEqual(lex.prefix_lengths((24,)*32), [30])


class SearchTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.geometry = Geometry(read_matrix((HERE/'matrix.txt').read_text(encoding='utf-8')))
        cls.english = English.from_file(HERE/'data/english.tsv.gz', 5)

    def test_full_search_and_coordinate_witness(self):
        res = solve(self.geometry, self.english)
        self.assertTrue(res.exhausted)
        self.assertEqual((res.seeds, res.last_depth, res.terminal_states[39]), (36, 39, 2))
        self.assertEqual(len(res.readings), 5)
        self.assertTrue(all(a.score >= b.score for a, b in zip(res.readings, res.readings[1:])))
        best = res.readings[0]
        self.assertEqual(sum(len(s.runes) for s in best.steps), 118)
        self.assertEqual(len(best.blocks), 39)
        self.assertEqual(best.blocks[-1], ('die',))
        rival = res.readings[3]
        self.assertEqual(rival.blocks[-1], ('winging',))
        self.assertEqual(rival.steps[:-1], best.steps[:-1])
        self.assertEqual(rival.steps[-1].runes, (7, 21, 21))
        for step, words in zip(best.steps, best.blocks):
            self.assertEqual(decrypt(self.geometry.grid, step.cells, step.key), step.runes)
            self.assertIn(words, [w for _, w in self.english.readings(step.runes)])

    def test_depth_limit_is_not_a_stop(self):
        one = solve(self.geometry, self.english, max_depth=1)
        self.assertFalse(one.exhausted)
        chosen = solve(self.geometry, self.english, blocks=1)
        self.assertTrue(chosen.exhausted)
        for reading in chosen.readings:
            step = reading.steps[0]
            state = State(step.node, step.cells, step.cells[0], 0, 0, 0)
            self.assertFalse(list(self.geometry.through25(state, self.geometry.next_phase(state))))

    def test_same_matrix_changed_to_zero(self):
        zeros = Geometry(dict.fromkeys(self.geometry.grid, 0))
        answer = solve(zeros, self.english)
        self.assertTrue(answer.exhausted)
        self.assertEqual(answer.readings, [])


if __name__ == '__main__':
    unittest.main()
